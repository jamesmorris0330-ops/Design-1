# Validation of the first playable release

## Completed checks

- TypeScript checks and production client/server build passed.
- 26 engine tests passed: private projections, compatible directives, scoring, mixed votes, whole-match progress, extensions, timer/pause state, removal, finale, collapse, abort secrecy, and rematch.
- 5 real WebSocket server tests passed: private-only updates, duplicate receipts, controller fencing, restart recovery, sessions/origins, host transfer, hard-deadline enforcement, and storage-failure recovery.
- 6 complete socket matches passed: 3 / 5 / 7 / 10 / 15 / 20 total rounds, including exactly one finale. The 20-round match used eight Subjects. Checks included server timer transitions, exact personal results, complete reveal history, and dossier score accounting.
- 3 Chromium browser tests passed against development and against the compiled production service: four independent Subjects with mobile controls, refresh, spectator privacy, every finale stage, and rematch; eight Subjects with majority-approved extensions and unchanged qualification targets; synchronized custom lengths and 15/20 caps.
- Desktop landing and phone-sized secret-decision screenshots were visually inspected; no horizontal overflow was found. Mobile allocation controls provide 44px touch targets and navigation to Trial, Dossier, and Chat.
- The frozen-lockfile installation script was executed successfully, followed by a fresh production build.
- Production dependency audit reported zero known vulnerabilities for the installed dependency set.
- The release ZIP was extracted into a folder with spaces, installed with runtime dependencies only, and started using `start-local.sh`. Its built client and server worked over the cloud machine's LAN IPv4 HTTP address.
- All 3 Chromium scenarios passed against that extracted release over plain HTTP, including mobile emulation. The origin was confirmed to be an insecure context with `crypto.randomUUID` unavailable, exercising the secure-random-byte command ID fallback. This run used `PLAYWRIGHT_NO_PROXY=1` to bypass the cloud browser's proxy for local-network access.
- An independent four-player release smoke completed every phase of a three-round game, pause/restart/identity recovery/resume, and rematch. ZIP integrity, exclusions, file permissions, and Windows launcher line endings passed review. Frozen runtime installation preserved the lockfile.

The intentional persistence-failure test emits a safe structured error and verifies that health becomes unavailable until a successful retry. This is a tested failure condition, not an unresolved test failure.

## Boundaries

These checks verify the current cloud instance, built service, and extracted PC package. Windows launcher execution, independent physical-device/Wi-Fi access, public deployment, Docker image construction, and restoration after cloud publication have not been validated. The Windows launcher received static review; runtime verification used Linux and Chromium. The Dockerfile and deployment instructions are provided for a hosting target supporting the documented runtime contract.

The first playable scope is implemented. Secondary mechanics listed in the approved roadmap have not been enabled or represented as completed features.
