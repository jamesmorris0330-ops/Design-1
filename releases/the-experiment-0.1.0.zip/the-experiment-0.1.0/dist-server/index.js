// src/server/app.ts
import Fastify, { LogController } from "fastify";
import cookie from "@fastify/cookie";
import websocket from "@fastify/websocket";
import staticFiles from "@fastify/static";
import { createHash, randomBytes, randomInt as randomInt2, randomUUID as randomUUID2 } from "node:crypto";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { z as z2 } from "zod";

// src/shared/protocol.ts
import { z } from "zod";
var settingsSchema = z.object({
  rounds: z.number().int().min(3).max(20),
  roundCap: z.union([z.literal(15), z.literal(20)]),
  extensions: z.boolean(),
  allowSpectators: z.boolean()
}).strict().refine((s) => s.rounds <= s.roundCap, "Round count exceeds the room cap");
var DEFAULT_SETTINGS = { rounds: 3, roundCap: 20, extensions: true, allowSpectators: true };
var actionSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("ready"), ready: z.boolean() }).strict(),
  z.object({ type: z.literal("settings"), settings: settingsSchema }).strict(),
  z.object({ type: z.literal("start") }).strict(),
  z.object({ type: z.literal("decision"), allocation: z.object({ medical: z.number().int().min(0).max(3), security: z.number().int().min(0).max(3), reserve: z.number().int().min(0).max(3) }).strict() }).strict(),
  z.object({ type: z.literal("vote"), targetId: z.string().max(100).nullable() }).strict(),
  z.object({ type: z.literal("chat"), text: z.string().trim().min(1).max(500) }).strict(),
  z.object({ type: z.literal("statement"), text: z.string().trim().min(1).max(500) }).strict(),
  z.object({ type: z.literal("advance") }).strict(),
  z.object({ type: z.literal("pause") }).strict(),
  z.object({ type: z.literal("resume") }).strict(),
  z.object({ type: z.literal("transfer_host"), targetId: z.string().max(100) }).strict(),
  z.object({ type: z.literal("remove"), targetId: z.string().max(100) }).strict(),
  z.object({ type: z.literal("set_role"), targetId: z.string().max(100), role: z.enum(["subject", "spectator"]) }).strict(),
  z.object({ type: z.literal("mute_chat"), muted: z.boolean() }).strict(),
  z.object({ type: z.literal("end") }).strict(),
  z.object({ type: z.literal("extension"), additionalRounds: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(5)]) }).strict(),
  z.object({ type: z.literal("extension_vote"), yes: z.boolean() }).strict(),
  z.object({ type: z.literal("continue") }).strict(),
  z.object({ type: z.literal("final_choice"), choice: z.enum(["group", "self"]) }).strict(),
  z.object({ type: z.literal("rematch") }).strict()
]);
var commandSchema = z.object({
  commandId: z.string().uuid(),
  gameId: z.string().max(100).nullable(),
  phaseId: z.string().max(100).nullable(),
  action: actionSchema
}).strict();

// src/server/engine.ts
import { randomUUID, randomInt } from "node:crypto";
var EngineError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "EngineError";
  }
};
var PHASE_DURATION = { crisis: 8e3, directive: 15e3, discussion: 45e3, decision: 3e4, reveal: 12e3, vote: 3e4, consequences: 8e3, dossier: 15e3, extension_offer: 2e4, extension_vote: 3e4, final_directive: 15e3, final_choice: 3e4, final_resolution: 8e3, personal_results: 15e3 };
var CRISES = [
  { title: "Containment Breach", description: "The medical wing is losing pressure. Reinforce Medical and Security before the breach spreads." },
  { title: "Blackout Protocol", description: "Emergency power is scarce. Medical support and secure infrastructure each need the group\u2019s resources." },
  { title: "Quarantine Threshold", description: "Protect the patients and secure the perimeter. Resources held in Reserve cannot prevent this crisis." },
  { title: "Oxygen Debt", description: "Medical ventilation and Security containment compete for the remaining emergency supplies." },
  { title: "Signal Failure", description: "Restore Medical monitoring and Security relays. Both systems must reach the required threshold." },
  { title: "Pressure Test", description: "Medical and Security systems are close to failure. The Experiment is watching what you keep back." }
];
var DIRECTIVES = [
  { kind: "medical2", title: "Medical Priority", instruction: "Allocate at least 2 units to Medical.", reward: 2 },
  { kind: "security2", title: "Containment Order", instruction: "Allocate at least 2 units to Security.", reward: 2 },
  { kind: "reserve2", title: "Personal Reserve", instruction: "Keep at least 2 units in Reserve.", reward: 3 },
  { kind: "medical0", title: "Withhold Treatment", instruction: "Allocate no units to Medical.", reward: 3 },
  { kind: "security0", title: "Open Perimeter", instruction: "Allocate no units to Security.", reward: 3 },
  { kind: "reserve3", title: "Total Retention", instruction: "Keep all 3 units in Reserve.", reward: 3 },
  { kind: "balanced", title: "Equal Distribution", instruction: "Allocate exactly 1 unit to each system.", reward: 2 },
  { kind: "both", title: "Group Benchmark", instruction: "Submit an allocation and have both Medical and Security reach their thresholds.", reward: 2 }
];
function fail(code, message) {
  throw new EngineError(code, message);
}
function member(room, id) {
  return room.members.find((m) => m.id === id && !m.removed) ?? fail("NOT_MEMBER", "This membership is unavailable.");
}
function host(room, id) {
  if (room.hostId !== id) fail("HOST_ONLY", "Only the current host can do that.");
}
function game(room) {
  return room.game ?? fail("NO_GAME", "There is no current Experiment.");
}
function subject(room, id) {
  const s = game(room).subjects[id];
  if (!s || s.withdrawn) fail("SUBJECT_ONLY", "Only an active Subject can do that.");
  return s;
}
function activeIds(g) {
  return Object.values(g.subjects).filter((s) => !s.withdrawn).map((s) => s.id);
}
function publish(room, kind, text, now, data) {
  const event = { id: randomUUID(), round: room.game?.round ?? 0, kind, text, at: now, ...data ? { data } : {} };
  room.events.push({ ...event, visibility: "public" });
  room.game?.publicEvents.push(event);
}
function dossier(room, s, kind, text, now, data) {
  const entry = { id: randomUUID(), round: game(room).round, kind, text, at: now, ...data ? { data } : {} };
  s.dossier.push(entry);
  room.events.push({ ...entry, visibility: "private", ownerId: s.id });
}
function phase(room, type, now, eligibleIds = activeIds(game(room))) {
  const g = game(room);
  const duration = type === "final_interrogation" ? 2e4 : PHASE_DURATION[type];
  g.phase = { id: randomUUID(), type, openedAt: now, deadline: duration == null ? null : now + duration, eligibleIds: [...eligibleIds], remainingMs: null, speakerId: type === "final_interrogation" ? eligibleIds[0] ?? null : null };
  if (g.paused) {
    g.phase.remainingMs = duration ?? null;
    g.phase.deadline = null;
  }
}
function validSettings(settings) {
  const s = settings;
  if (!Number.isInteger(s.rounds) || s.rounds < 3 || s.rounds > 20 || ![15, 20].includes(s.roundCap) || s.rounds > s.roundCap) fail("BAD_SETTINGS", "Choose 3\u201320 rounds within a cap of 15 or 20.");
}
function createRoom(code, initial, settings, now) {
  validSettings(settings);
  return { id: randomUUID(), code, hostId: initial.id, settings: structuredClone(settings), status: "lobby", members: [{ ...initial, joinedAt: now, role: "subject", ready: false, removed: false }], game: null, pastGames: [], chat: [], events: [], chatMuted: false };
}
function addMember(room, joining, now) {
  if (room.status === "closed") fail("ROOM_CLOSED", "This room is closed.");
  const previous = room.members.find((m) => m.sessionId === joining.sessionId);
  if (previous && !previous.removed) return;
  if (previous?.removed) fail("REMOVED", "This session has been removed from the room.");
  const settings = room.settings;
  const count = room.members.filter((m) => !m.removed && m.role === "subject").length;
  const isSpectator = room.status !== "lobby" || count >= 8;
  if (isSpectator && !settings.allowSpectators) fail("SPECTATORS_DISABLED", "Spectator admission is disabled.");
  room.members.push({ ...joining, joinedAt: now, role: isSpectator ? "spectator" : "subject", ready: false, removed: false });
  publish(room, "joined", `${joining.nickname} joined as ${isSpectator ? "a spectator" : "a Subject"}.`, now);
}
function shuffle(items) {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function ballotFor(round, planned) {
  if (round === planned - 1) return "trust";
  if (planned === 3) return "exposure";
  if (planned === 5) return ["exposure", "restriction", "exposure", "trust"][round - 1];
  if (planned === 7) return ["exposure", "restriction", "trust", "restriction", "exposure", "trust"][round - 1];
  return ["exposure", "restriction", "trust"][(round - 1) % 3];
}
function startTrial(room, now) {
  const g = game(room);
  const ids = activeIds(g);
  const content = CRISES[(g.round - 1) % CRISES.length];
  g.trial = { id: randomUUID(), ...content, threshold: ids.length, voteType: ballotFor(g.round, g.plannedTotalRounds), totals: null, delta: null, met: null, votes: {}, voteWinner: null, voteTied: false, voteResolved: false, exposure: null };
  g.extension = null;
  for (const id of ids) {
    const s = g.subjects[id];
    s.medicalMinimum = s.pendingRestriction ? 1 : 0;
    s.pendingRestriction = false;
    s.directive = null;
    s.allocation = null;
    s.ballot = void 0;
  }
  phase(room, "crisis", now, ids);
  publish(room, "crisis", `Trial ${g.round}: ${content.title}`, now, { threshold: ids.length, voteType: g.trial.voteType });
}
function begin(room, now) {
  if (room.status !== "lobby") fail("BAD_STATE", "Return to the lobby before starting an Experiment.");
  validSettings(room.settings);
  const players = room.members.filter((m) => !m.removed && m.role === "subject");
  if (players.length < 4 || players.length > 8) fail("PLAYER_COUNT", "An Experiment requires 4\u20138 Subjects.");
  if (players.some((m) => !m.ready)) fail("NOT_READY", "Every Subject must be ready.");
  const settings = room.settings;
  const subjects = {};
  players.forEach((m, i) => {
    subjects[m.id] = { id: m.id, number: i + 1, compliance: 0, requirement: Math.ceil(settings.rounds * 1.5), completedDirectives: 0, trustVotes: 0, withdrawn: false, pendingRestriction: false, medicalMinimum: 0, directive: null, allocation: null, ballot: void 0, finalChoice: null, dossier: [], history: [], statement: null };
  });
  room.game = { id: randomUUID(), initialRoundCount: settings.rounds, plannedTotalRounds: settings.rounds, maxRounds: settings.roundCap, extensionsEnabled: settings.extensions, round: 1, startingSubjectCount: players.length, stabilityTicks: 60 * players.length, phase: { id: "", type: "crisis", openedAt: now, deadline: null, eligibleIds: [], remainingMs: null, speakerId: null }, paused: false, pauseReason: null, subjects, trial: null, extension: null, extensionHistory: [], outcome: null, results: [], finalCounts: null, publicEvents: [] };
  room.status = "running";
  publish(room, "started", "THE EXPERIMENT has begun. There is no designated villain.", now);
  startTrial(room, now);
}
function assignDirectives(room, now) {
  const g = game(room);
  const bundle = shuffle(DIRECTIVES);
  for (const [index, id] of shuffle(activeIds(g)).entries()) {
    const s = g.subjects[id];
    let d = bundle[index % bundle.length];
    if (s.medicalMinimum > 0 && (d.kind === "medical0" || d.kind === "reserve3")) d = DIRECTIVES.find((x) => x.kind === "security0");
    s.directive = { ...d, id: randomUUID() };
    dossier(room, s, "directive", d.instruction, now, { directive: s.directive });
  }
  phase(room, "directive", now, g.phase.eligibleIds);
}
function completes(d, a, met) {
  switch (d.kind) {
    case "medical2":
      return a.medical >= 2;
    case "security2":
      return a.security >= 2;
    case "reserve2":
      return a.reserve >= 2;
    case "medical0":
      return a.medical === 0;
    case "security0":
      return a.security === 0;
    case "reserve3":
      return a.reserve === 3;
    case "balanced":
      return a.medical === 1 && a.security === 1 && a.reserve === 1;
    case "both":
      return met.medical && met.security;
    default:
      return false;
  }
}
function finishResource(room, now) {
  const g = game(room), t = g.trial;
  const totals = { medical: 0, security: 0, reserve: 0 };
  for (const id of g.phase.eligibleIds) {
    const a = g.subjects[id].allocation;
    if (a) {
      totals.medical += a.medical;
      totals.security += a.security;
      totals.reserve += a.reserve;
    }
  }
  const met = { medical: totals.medical >= t.threshold, security: totals.security >= t.threshold };
  const delta = (met.medical ? 10 : -15) + (met.security ? 10 : -15);
  t.totals = totals;
  t.met = met;
  t.delta = delta;
  const beforeStability = g.stabilityTicks / g.startingSubjectCount;
  g.stabilityTicks = Math.max(0, Math.min(100 * g.startingSubjectCount, g.stabilityTicks + delta * g.startingSubjectCount));
  for (const id of g.phase.eligibleIds) {
    const s = g.subjects[id];
    const completed = s.allocation != null && s.directive != null && completes(s.directive, s.allocation, met);
    if (completed) {
      s.compliance += s.directive.reward;
      s.completedDirectives++;
    }
    if (s.directive) s.history.push({ round: g.round, directive: structuredClone(s.directive), allocation: s.allocation ? { ...s.allocation } : null, completed, complianceAfter: s.compliance, medicalMinimum: s.medicalMinimum });
    const responseText = s.allocation ? `Your allocation: Medical ${s.allocation.medical}, Security ${s.allocation.security}, Reserve ${s.allocation.reserve}. ${completed ? `Directive complete: +${s.directive.reward} Compliance.` : "Directive incomplete: no Compliance earned."}` : "No response: zero resources contributed, no Compliance earned.";
    dossier(room, s, "resolution", `${responseText} Group Stability: ${beforeStability} \u2192 ${g.stabilityTicks / g.startingSubjectCount} (crisis rule ${delta >= 0 ? "+" : ""}${delta}, maximum 100).`, now, { allocation: s.allocation, completed, compliance: s.compliance, stabilityDelta: delta, complianceDelta: completed ? s.directive.reward : 0 });
  }
  publish(room, "resource_resolution", `Medical ${totals.medical}/${t.threshold}; Security ${totals.security}/${t.threshold}. Stability ${delta >= 0 ? "+" : ""}${delta}.`, now, { totals, met, delta });
  if (g.stabilityTicks <= 0) {
    finishGame(room, "failed", now);
    return;
  }
  phase(room, "reveal", now);
}
function finishVote(room, now) {
  const g = game(room), t = g.trial;
  for (const voter of g.phase.eligibleIds) if (!Object.hasOwn(t.votes, voter)) t.votes[voter] = null;
  const counts = {};
  for (const target of Object.values(t.votes)) if (target) counts[target] = (counts[target] ?? 0) + 1;
  const best = Math.max(0, ...Object.values(counts));
  const leaders = Object.keys(counts).filter((id) => counts[id] === best);
  const winner = leaders.length === 1 ? leaders[0] : null;
  t.voteWinner = winner;
  t.voteTied = leaders.length > 1;
  t.voteResolved = true;
  if (t.voteType === "trust") for (const [id, count] of Object.entries(counts)) g.subjects[id].trustVotes += count;
  if (winner && !g.subjects[winner].withdrawn) {
    const s = g.subjects[winner];
    if (t.voteType === "trust") {
      s.compliance++;
      dossier(room, s, "trust", "Trust vote awarded +1 Compliance.", now, { compliance: s.compliance, complianceDelta: 1 });
    }
    if (t.voteType === "restriction") {
      s.pendingRestriction = true;
      dossier(room, s, "restriction", "Next ordinary Trial: allocate at least 1 unit to Medical.", now);
    }
  }
  if (winner && t.voteType === "exposure" && g.subjects[winner].directive) t.exposure = { playerId: winner, directive: structuredClone(g.subjects[winner].directive) };
  const outcomeText = winner ? `${t.voteType.toUpperCase()} selected Subject ${g.subjects[winner].number.toString().padStart(2, "0")}${g.subjects[winner].withdrawn ? " (removed; no future reward or restriction)" : ""}.` : "The ballot has no unique winner. No mechanical effect.";
  const ballotText = Object.entries(t.votes).map(([voter, target]) => `Subject ${g.subjects[voter].number.toString().padStart(2, "0")} \u2192 ${target ? `Subject ${g.subjects[target].number.toString().padStart(2, "0")}` : "abstain"}`).join("; ");
  const countsText = Object.entries(counts).map(([id, count]) => `Subject ${g.subjects[id].number.toString().padStart(2, "0")}: ${count}`).join("; ");
  const exposureText = t.exposure ? ` Exposed directive: ${t.exposure.directive.instruction} (${t.exposure.directive.reward} Compliance).` : "";
  publish(room, "vote_resolution", `${outcomeText}${exposureText} Ballots: ${ballotText}. Totals: ${countsText || "no target received votes"}.`, now, { voteType: t.voteType, votes: { ...t.votes }, counts, winner, tied: t.voteTied, ...t.exposure ? { exposure: t.exposure } : {} });
  phase(room, "consequences", now);
}
function beginFinale(room, now) {
  const g = game(room);
  g.round = g.plannedTotalRounds;
  g.trial = null;
  g.extension = null;
  for (const s of Object.values(g.subjects)) {
    s.directive = null;
    s.finalChoice = null;
    s.statement = null;
    s.allocation = null;
    s.ballot = void 0;
    s.medicalMinimum = 0;
  }
  phase(room, "final_interrogation", now);
  publish(room, "finale", "Final Interrogation. Make your final statement before the private Final Directive.", now);
}
function assignFinalDirectives(room, now) {
  const g = game(room), shuffled = shuffle(activeIds(g));
  for (const [i, id] of shuffled.entries()) {
    const s = g.subjects[id], kind = i % 2 === 0 ? "group" : "self";
    s.directive = { id: randomUUID(), kind, title: kind === "group" ? "Final Loyalty" : "Final Self-Preservation", instruction: kind === "group" ? "Choose Protect the Group." : "Choose Protect Yourself.", reward: 3 };
    dossier(room, s, "final_directive", s.directive.instruction, now, { directive: s.directive });
  }
  phase(room, "final_directive", now);
}
function advanceInterrogation(room, now) {
  const g = game(room), old = g.phase;
  const index = old.eligibleIds.indexOf(old.speakerId ?? "");
  const next = old.eligibleIds.slice(index + 1).find((id) => !g.subjects[id].withdrawn);
  if (!next) {
    assignFinalDirectives(room, now);
    return;
  }
  phase(room, "final_interrogation", now, old.eligibleIds);
  g.phase.speakerId = next;
}
function finishFinalChoices(room, now) {
  const g = game(room);
  const protectors = Object.values(g.subjects).filter((s) => s.finalChoice === "group").length;
  const selfProtectors = Object.values(g.subjects).filter((s) => s.finalChoice === "self").length;
  const deltaTicks = 40 * protectors - 120 * selfProtectors;
  const beforeStability = g.stabilityTicks / g.startingSubjectCount;
  const afterTicks = Math.max(0, Math.min(g.startingSubjectCount * 100, g.stabilityTicks + deltaTicks));
  for (const s of Object.values(g.subjects)) {
    if (!s.finalChoice) continue;
    const completed = s.directive?.kind === s.finalChoice;
    if (completed) {
      s.compliance += 3;
      s.completedDirectives++;
    }
    if (s.directive) s.history.push({ round: g.round, directive: structuredClone(s.directive), allocation: null, completed, complianceAfter: s.compliance, medicalMinimum: 0, finalChoice: s.finalChoice });
    dossier(room, s, "final_resolution", `You chose ${s.finalChoice === "group" ? "Protect the Group" : "Protect Yourself"}. ${completed ? "+3 Compliance." : "Final Directive incomplete."} Group Stability: ${beforeStability} \u2192 ${afterTicks / g.startingSubjectCount}.`, now, { finalChoice: s.finalChoice, completed, compliance: s.compliance, complianceDelta: completed ? 3 : 0 });
  }
  g.stabilityTicks = afterTicks;
  g.finalCounts = { group: protectors, self: selfProtectors, delta: deltaTicks / g.startingSubjectCount };
  g.outcome = g.stabilityTicks > 0 ? "survived" : "failed";
  makeResults(g);
  publish(room, "final_resolution", `Protect the Group: ${protectors}. Protect Yourself: ${selfProtectors}. Group ${g.outcome.toUpperCase()}.`, now, { ...g.finalCounts, outcome: g.outcome });
  phase(room, "final_resolution", now);
}
function makeResults(g) {
  const scores = Object.values(g.subjects).map((s) => s.trustVotes);
  g.results = Object.values(g.subjects).map((s) => ({ playerId: s.id, subjectNumber: s.number, compliance: s.compliance, requirement: s.requirement, qualified: g.outcome === "survived" && !s.withdrawn && s.compliance >= s.requirement, completedDirectives: s.completedDirectives, trustVotes: s.trustVotes, trustRank: 1 + scores.filter((n) => n > s.trustVotes).length, classification: s.withdrawn ? "WITHDRAWN" : s.finalChoice === "self" && s.trustVotes > 0 ? "LOYAL OPPORTUNIST" : s.finalChoice === "self" ? "SELF-PRESERVATIONIST" : s.trustVotes > 0 ? "TRUSTED GUARDIAN" : "GROUP PROTECTOR", withdrawn: s.withdrawn }));
}
function finishGame(room, outcome, now) {
  const g = game(room);
  g.outcome = outcome;
  g.paused = false;
  g.pauseReason = null;
  makeResults(g);
  publish(room, outcome, outcome === "aborted" ? "The host ended this Experiment. No winners; unrevealed secrets remain private." : "Group Stability has collapsed. No Subject qualifies.", now);
  if (outcome === "aborted") {
    phase(room, "aborted", now);
    room.status = "postgame";
  } else phase(room, "personal_results", now);
}
function checkpoint(room, now) {
  const g = game(room);
  if (g.extensionsEnabled && g.plannedTotalRounds < g.maxRounds) phase(room, "extension_offer", now);
  else beginFinale(room, now);
}
function finishExtension(room, now) {
  const g = game(room), ext = g.extension;
  const yes = Object.values(ext.ballots).filter(Boolean).length;
  const no = ext.eligibleIds.length - yes;
  const accepted = yes > ext.eligibleIds.length / 2;
  ext.yes = yes;
  ext.no = no;
  ext.accepted = accepted;
  g.extensionHistory.push(structuredClone(ext));
  publish(room, "extension_resolution", `Extra Trials ${accepted ? "approved" : "declined"}: ${yes} yes, ${no} no.`, now, { yes, no, accepted, addedRounds: ext.addedRounds });
  if (accepted) {
    g.plannedTotalRounds = ext.toRounds;
    g.round++;
    startTrial(room, now);
  } else beginFinale(room, now);
}
function advance(room, now) {
  const g = game(room);
  switch (g.phase.type) {
    case "crisis":
      assignDirectives(room, now);
      break;
    case "directive":
      phase(room, "discussion", now, g.phase.eligibleIds);
      break;
    case "discussion":
      phase(room, "decision", now, g.phase.eligibleIds);
      break;
    case "decision":
      finishResource(room, now);
      break;
    case "reveal":
      phase(room, "vote", now);
      break;
    case "vote":
      finishVote(room, now);
      break;
    case "consequences":
      phase(room, "dossier", now);
      break;
    case "dossier":
      if (g.round < g.plannedTotalRounds - 1) {
        g.round++;
        startTrial(room, now);
      } else checkpoint(room, now);
      break;
    case "extension_offer":
      beginFinale(room, now);
      break;
    case "extension_vote":
      finishExtension(room, now);
      break;
    case "final_interrogation":
      advanceInterrogation(room, now);
      break;
    case "final_directive":
      phase(room, "final_choice", now);
      break;
    case "final_choice": {
      if (g.phase.eligibleIds.every((id) => g.subjects[id].finalChoice !== null || g.subjects[id].withdrawn)) finishFinalChoices(room, now);
      else fail("FINALE_WAITING", "Final choices require every eligible Subject to lock in. Reconnect, pause, remove an absent Subject, or end the Experiment.");
      break;
    }
    case "final_resolution":
      phase(room, "personal_results", now);
      break;
    case "personal_results":
      phase(room, "full_reveal", now);
      room.status = "postgame";
      publish(room, "full_reveal", "The Experiment\u2019s hidden record is now open.", now);
      break;
    case "aborted":
    case "full_reveal":
      fail("FINISHED", "This Experiment has finished.");
  }
}
function tick(room, now) {
  const g = room.game;
  if (room.status !== "running" || !g || g.paused || g.phase.deadline === null || now < g.phase.deadline || g.phase.type === "final_choice") return false;
  advance(room, now);
  return true;
}
function applyCommand(room, actorId, command, now) {
  const actor = member(room, actorId);
  const envelope = { gameId: command.gameId, phaseId: command.phaseId, type: command.action.type };
  const payload = command.action;
  const g = room.game;
  const gameCommands = ["decision", "vote", "final_choice", "statement", "extension", "extension_vote", "continue", "pause", "resume", "advance", "end"];
  if (gameCommands.includes(envelope.type)) {
    if (!g || room.status !== "running") fail("BAD_STATE", "There is no active Experiment.");
    if (envelope.gameId !== g.id || envelope.phaseId !== g.phase.id) fail("STALE_PHASE", "This action belongs to an earlier game or phase. Refresh your room state.");
  }
  if (room.status === "running" && g && ["transfer_host", "remove", "mute_chat"].includes(envelope.type) && (envelope.gameId !== g.id || envelope.phaseId !== g.phase.id)) fail("STALE_PHASE", "This host action belongs to an earlier game or phase.");
  const actions = ["decision", "vote", "final_choice", "statement", "extension", "extension_vote", "continue", "advance"];
  if (g?.paused && actions.includes(envelope.type)) fail("PAUSED", "The Experiment is paused.");
  switch (envelope.type) {
    case "ready": {
      if (room.status !== "lobby" || actor.role !== "subject") fail("BAD_STATE", "Ready is available to Subjects in the lobby.");
      actor.ready = Boolean(payload.ready);
      break;
    }
    case "settings": {
      host(room, actorId);
      if (room.status !== "lobby" && room.status !== "postgame") fail("BAD_STATE", "Settings cannot change during an Experiment.");
      const next = payload.settings;
      validSettings(next);
      room.settings = structuredClone(next);
      room.members.forEach((m) => {
        m.ready = false;
      });
      break;
    }
    case "start":
      host(room, actorId);
      begin(room, now);
      break;
    case "rematch": {
      host(room, actorId);
      if (room.status !== "postgame") fail("BAD_STATE", "Finish the current Experiment before a rematch.");
      if (room.game) (room.pastGames ??= []).push(structuredClone(room.game));
      room.game = null;
      room.status = "lobby";
      room.members.forEach((m) => {
        m.ready = false;
      });
      publish(room, "rematch", "The room is ready for a fresh Experiment.", now);
      break;
    }
    case "set_role": {
      host(room, actorId);
      if (room.status !== "lobby" && room.status !== "postgame") fail("BAD_STATE", "Membership roles can change between games.");
      const target = member(room, String(payload.targetId));
      if (payload.role !== "subject" && payload.role !== "spectator") fail("BAD_ROLE", "Unknown membership role.");
      if (payload.role === "subject" && target.role !== "subject" && room.members.filter((m) => !m.removed && m.role === "subject").length >= 8) fail("ROOM_FULL", "At most 8 Subjects can participate.");
      target.role = payload.role;
      target.ready = false;
      break;
    }
    case "chat": {
      if (room.chatMuted && actorId !== room.hostId) fail("CHAT_MUTED", "The host has muted public chat.");
      const text = String(payload.text ?? "").trim();
      if (!text || text.length > 500) fail("BAD_CHAT", "Chat messages must contain 1\u2013500 characters.");
      room.chat.push({ id: randomUUID(), senderId: actorId, text, at: now, type: "chat" });
      if (room.chat.length > 200) room.chat.shift();
      break;
    }
    case "transfer_host": {
      host(room, actorId);
      const target = member(room, String(payload.targetId));
      room.hostId = target.id;
      publish(room, "host_transfer", `${target.nickname} is now the host.`, now);
      break;
    }
    case "mute_chat":
      host(room, actorId);
      room.chatMuted = Boolean(payload.muted);
      break;
    case "remove": {
      host(room, actorId);
      const target = member(room, String(payload.targetId));
      if (target.id === actorId) fail("SELF_REMOVE", "Transfer host before leaving your room.");
      target.removed = true;
      target.ready = false;
      if (g?.subjects[target.id] && !g.outcome) g.subjects[target.id].withdrawn = true;
      publish(room, "removed", `${target.nickname} was removed by the host. Committed history is retained.`, now);
      if (room.status === "running" && g && !g.outcome) {
        if (activeIds(g).length < 4) {
          if (!g.paused) pauseGame(g, now);
          g.pauseReason = "Fewer than four Subjects remain. End this Experiment and restart with a full group.";
        } else if (g.phase.type === "final_interrogation" && g.phase.speakerId === target.id) advanceInterrogation(room, now);
        else checkAllLocked(room, now);
      }
      break;
    }
    case "pause":
      host(room, actorId);
      if (g.paused) fail("ALREADY_PAUSED", "The Experiment is already paused.");
      pauseGame(g, now);
      break;
    case "resume": {
      host(room, actorId);
      if (!g.paused) fail("NOT_PAUSED", "The Experiment is not paused.");
      if (activeIds(g).length < 4) fail("PLAYER_COUNT", "Fewer than four Subjects remain. End and restart the Experiment.");
      g.paused = false;
      g.pauseReason = null;
      g.phase.deadline = g.phase.remainingMs === null ? null : now + g.phase.remainingMs;
      g.phase.remainingMs = null;
      break;
    }
    case "advance": {
      host(room, actorId);
      const priorPhase = g.phase.type;
      advance(room, now);
      publish(room, "host_advance", `The host advanced ${priorPhase} using the documented timeout rules.`, now);
      break;
    }
    case "end":
      host(room, actorId);
      finishGame(room, "aborted", now);
      break;
    case "decision": {
      const s = subject(room, actorId);
      if (g.phase.type !== "decision" || !g.phase.eligibleIds.includes(actorId)) fail("BAD_PHASE", "Resource allocation is unavailable in this phase.");
      if (s.allocation) fail("ALREADY_LOCKED", "Your decision is already locked.");
      const a = payload.allocation;
      if (!a || ![a.medical, a.security, a.reserve].every((n) => Number.isInteger(n) && n >= 0 && n <= 3) || a.medical + a.security + a.reserve !== 3 || a.medical < s.medicalMinimum) fail("BAD_ALLOCATION", `Allocate exactly 3 units, including at least ${s.medicalMinimum} Medical.`);
      s.allocation = { medical: a.medical, security: a.security, reserve: a.reserve };
      checkAllLocked(room, now);
      break;
    }
    case "vote": {
      const s = subject(room, actorId);
      if (g.phase.type !== "vote" || !g.phase.eligibleIds.includes(actorId)) fail("BAD_PHASE", "Voting is unavailable in this phase.");
      if (s.ballot !== void 0) fail("ALREADY_LOCKED", "Your ballot is already locked.");
      const target = payload.targetId == null ? null : String(payload.targetId);
      if (target === actorId || target && !g.phase.eligibleIds.includes(target)) fail("BAD_TARGET", "Select another eligible Subject or abstain.");
      s.ballot = target;
      g.trial.votes[actorId] = target;
      checkAllLocked(room, now);
      break;
    }
    case "statement": {
      const s = subject(room, actorId);
      if (g.phase.type !== "final_interrogation") fail("BAD_PHASE", "Final statements are unavailable in this phase.");
      if (g.phase.speakerId !== actorId) fail("NOT_YOUR_TURN", "Wait for your 20-second final statement turn.");
      if (s.statement !== null) fail("ALREADY_LOCKED", "Your final statement is already recorded.");
      const text = String(payload.text ?? "").trim();
      if (!text || text.length > 500) fail("BAD_STATEMENT", "A final statement must contain 1\u2013500 characters.");
      s.statement = text;
      room.chat.push({ id: randomUUID(), senderId: actorId, text, at: now, type: "statement" });
      if (room.chat.length > 200) room.chat.shift();
      publish(room, "final_statement", text, now, { playerId: actorId });
      advanceInterrogation(room, now);
      break;
    }
    case "final_choice": {
      const s = subject(room, actorId);
      if (g.phase.type !== "final_choice" || !g.phase.eligibleIds.includes(actorId)) fail("BAD_PHASE", "Final choices are unavailable in this phase.");
      if (s.finalChoice !== null) fail("ALREADY_LOCKED", "Your final choice is already locked.");
      if (payload.choice !== "group" && payload.choice !== "self") fail("BAD_CHOICE", "Choose Protect the Group or Protect Yourself.");
      s.finalChoice = payload.choice;
      checkAllLocked(room, now);
      break;
    }
    case "extension": {
      host(room, actorId);
      if (g.phase.type !== "extension_offer") fail("BAD_PHASE", "Additional rounds can only be proposed before the finale.");
      const added = Number(payload.additionalRounds);
      if (![1, 2, 3, 5].includes(added) || g.plannedTotalRounds + added > g.maxRounds) fail("BAD_EXTENSION", "Choose an allowed addition within this game\u2019s cap.");
      const ids = activeIds(g);
      g.extension = { id: randomUUID(), addedRounds: added, fromRounds: g.plannedTotalRounds, toRounds: g.plannedTotalRounds + added, eligibleIds: [...ids], ballots: {}, yes: null, no: null, accepted: null };
      phase(room, "extension_vote", now, ids);
      publish(room, "extension_proposal", `The host proposes ${added} additional ordinary Trial${added === 1 ? "" : "s"}, for ${g.extension.toRounds} total rounds including the finale.`, now);
      break;
    }
    case "extension_vote": {
      subject(room, actorId);
      if (g.phase.type !== "extension_vote" || !g.extension.eligibleIds.includes(actorId)) fail("BAD_PHASE", "Continuation voting is unavailable.");
      if (Object.hasOwn(g.extension.ballots, actorId)) fail("ALREADY_LOCKED", "Your consent ballot is already locked.");
      if (typeof payload.yes !== "boolean") fail("BAD_BALLOT", "Choose yes or no.");
      g.extension.ballots[actorId] = payload.yes;
      checkAllLocked(room, now);
      break;
    }
    case "continue":
      host(room, actorId);
      if (g.phase.type !== "extension_offer") fail("BAD_PHASE", "This checkpoint has already closed.");
      beginFinale(room, now);
      break;
    default:
      fail("UNKNOWN_COMMAND", "Unknown command.");
  }
}
function pauseGame(g, now) {
  g.paused = true;
  g.pauseReason = "Paused by the host.";
  g.phase.remainingMs = g.phase.deadline === null ? null : Math.max(0, g.phase.deadline - now);
  g.phase.deadline = null;
}
function checkAllLocked(room, now) {
  const g = game(room);
  if (g.paused) return;
  const ids = g.phase.eligibleIds;
  if (g.phase.type === "decision" && ids.every((id) => g.subjects[id].allocation !== null || g.subjects[id].withdrawn)) finishResource(room, now);
  else if (g.phase.type === "vote" && ids.every((id) => g.subjects[id].ballot !== void 0 || g.subjects[id].withdrawn)) finishVote(room, now);
  else if (g.phase.type === "extension_vote" && g.extension.eligibleIds.every((id) => Object.hasOwn(g.extension.ballots, id) || g.subjects[id].withdrawn)) finishExtension(room, now);
  else if (g.phase.type === "final_choice" && ids.every((id) => g.subjects[id].finalChoice !== null || g.subjects[id].withdrawn)) finishFinalChoices(room, now);
}
function resultView(room, result) {
  return { memberId: result.playerId, nickname: room.members.find((m) => m.id === result.playerId)?.nickname ?? "Removed Subject", subjectNumber: result.subjectNumber, compliance: result.compliance, requirement: result.requirement, qualified: result.qualified, directivesCompleted: result.completedDirectives, trustVotes: result.trustVotes, trustRank: result.trustRank, classification: result.classification, removed: result.withdrawn };
}
function directiveView(d) {
  return d ? { id: d.id, text: d.instruction, reward: d.reward } : null;
}
function titleOf(kind) {
  return kind.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
function projectRoom(room, viewerId, onlineIds = /* @__PURE__ */ new Set()) {
  member(room, viewerId);
  if (room.status === "closed") fail("ROOM_CLOSED", "This room is closed.");
  const g = room.game;
  const self = g?.subjects[viewerId];
  const showFull = g?.phase.type === "full_reveal" && g.outcome !== "aborted";
  const showPersonal = g && ["personal_results", "full_reveal", "aborted"].includes(g.phase.type);
  const ownResult = showPersonal ? g.results.find((r) => r.playerId === viewerId) ?? null : null;
  const fullReveal = [];
  if (g && showFull) {
    for (const s of Object.values(g.subjects)) {
      for (const h of s.history) {
        const choice = h.finalChoice ? h.finalChoice === "group" ? "Protect the Group" : "Protect Yourself" : h.allocation ? `Medical ${h.allocation.medical}, Security ${h.allocation.security}, Reserve ${h.allocation.reserve}` : "No response";
        fullReveal.push({ id: `${s.id}:${h.round}`, round: h.round, memberId: s.id, title: `Subject ${s.number.toString().padStart(2, "0")} \u2014 ${h.directive.title}`, detail: `Directive: ${h.directive.instruction} (${h.directive.reward} Compliance). Decision: ${choice}. ${h.completed ? "Completed" : "Not completed"}. Compliance after decision: ${h.complianceAfter}.` });
      }
      if (s.directive && !s.history.some((h) => h.directive.id === s.directive.id)) fullReveal.push({ id: `${s.id}:unfinished`, round: g.round, memberId: s.id, title: `Subject ${s.number.toString().padStart(2, "0")} \u2014 unfinished directive`, detail: s.directive.instruction });
    }
  }
  const privateDirective = self?.directive ?? null;
  const isFinal = privateDirective?.kind === "group" || privateDirective?.kind === "self";
  return {
    id: room.id,
    code: room.code,
    hostId: room.hostId,
    settings: { ...room.settings },
    status: room.status,
    chatMuted: room.chatMuted,
    selfId: viewerId,
    members: room.members.map((m) => ({ id: m.id, nickname: m.nickname, role: m.role, ready: m.ready, removed: m.removed, connected: onlineIds.has(m.id), subjectNumber: g?.subjects[m.id]?.number ?? null })),
    chat: room.chat.map((m) => ({ id: m.id, senderId: m.senderId, nickname: room.members.find((p) => p.id === m.senderId)?.nickname ?? "Removed Subject", text: m.text, at: m.at, type: m.type ?? "chat" })),
    events: (g ? g.publicEvents : room.events.filter((e) => e.visibility === "public")).map((e) => ({ id: e.id, at: e.at, round: e.round, type: e.kind, title: titleOf(e.kind), detail: e.text })),
    game: g ? {
      id: g.id,
      round: g.round,
      initialRounds: g.initialRoundCount,
      totalRounds: g.plannedTotalRounds,
      roundCap: g.maxRounds,
      stability: g.stabilityTicks / g.startingSubjectCount,
      maxStability: 100,
      outcome: g.outcome ?? "active",
      phase: { id: g.phase.id, type: g.phase.type, deadline: g.phase.deadline, paused: g.paused, pauseReason: g.pauseReason, remainingMs: g.phase.remainingMs, eligibleIds: [...g.phase.eligibleIds], speakerId: g.phase.speakerId },
      trial: g.trial ? { id: g.trial.id, title: g.trial.title, narrative: g.trial.description, medicalTarget: g.trial.threshold, securityTarget: g.trial.threshold } : null,
      voteType: g.trial?.voteType ?? null,
      voteTargets: g.phase.type === "vote" ? [...g.phase.eligibleIds] : [],
      allocationTotals: g.trial?.totals ? { ...g.trial.totals } : null,
      extension: g.extension ? { additionalRounds: g.extension.addedRounds, proposedTotal: g.extension.toRounds } : null,
      results: showFull ? g.results.map((r) => resultView(room, r)) : [],
      fullReveal
    } : null,
    me: self ? {
      compliance: self.compliance,
      requirement: self.requirement,
      directive: !isFinal ? directiveView(privateDirective) : null,
      finalDirective: isFinal ? directiveView(privateDirective) : null,
      restriction: self.medicalMinimum > 0 || self.pendingRestriction,
      decision: self.allocation ? { ...self.allocation } : null,
      decisionSubmitted: self.allocation !== null,
      voteSubmitted: self.ballot !== void 0,
      finalChoice: self.finalChoice,
      extensionVote: g?.extension && Object.hasOwn(g.extension.ballots, viewerId) ? g.extension.ballots[viewerId] : null,
      dossier: self.dossier.map((e) => ({ id: e.id, round: e.round, title: titleOf(e.kind), text: e.text, complianceDelta: Number(e.data?.complianceDelta ?? 0), at: e.at })),
      result: ownResult ? resultView(room, ownResult) : null
    } : null
  };
}

// src/server/store.ts
import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
var Store = class {
  database;
  constructor(path) {
    if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
    this.database = new DatabaseSync(path);
    this.database.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = FULL;
      PRAGMA foreign_keys = ON;
      PRAGMA busy_timeout = 5000;
      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        token_digest TEXT NOT NULL UNIQUE,
        expires_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS rooms (
        code TEXT PRIMARY KEY,
        snapshot TEXT NOT NULL,
        updated_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS room_events (
        sequence INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT NOT NULL REFERENCES rooms(code),
        at INTEGER NOT NULL,
        event TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS command_receipts (
        actor_id TEXT NOT NULL,
        command_id TEXT NOT NULL,
        payload_hash TEXT NOT NULL,
        ack TEXT NOT NULL,
        room_code TEXT NOT NULL REFERENCES rooms(code),
        at INTEGER NOT NULL,
        PRIMARY KEY (actor_id, command_id)
      );
      CREATE TABLE IF NOT EXISTS host_presence (
        room_code TEXT PRIMARY KEY REFERENCES rooms(code),
        host_id TEXT NOT NULL,
        disconnected_at INTEGER
      );
    `);
  }
  loadRooms() {
    return this.database.prepare("SELECT snapshot FROM rooms").all().map((row) => JSON.parse(String(row.snapshot)));
  }
  sessionId(tokenDigest, now) {
    const row = this.database.prepare("SELECT id FROM sessions WHERE token_digest = ? AND expires_at > ?").get(tokenDigest, now);
    return row ? String(row.id) : null;
  }
  createSession(id, tokenDigest, expiresAt) {
    this.database.prepare("INSERT INTO sessions(id, token_digest, expires_at) VALUES (?, ?, ?)").run(id, tokenDigest, expiresAt);
  }
  receipt(actorId, commandId) {
    const row = this.database.prepare("SELECT payload_hash, ack FROM command_receipts WHERE actor_id = ? AND command_id = ?").get(actorId, commandId);
    return row ? { actorId, commandId, payloadHash: String(row.payload_hash), ack: JSON.parse(String(row.ack)) } : null;
  }
  /** Snapshot, audit event, and receipt commit together before acknowledgement. */
  commit(room, at, event, receipt) {
    this.database.exec("BEGIN IMMEDIATE");
    try {
      this.database.prepare("INSERT INTO rooms(code, snapshot, updated_at) VALUES (?, ?, ?) ON CONFLICT(code) DO UPDATE SET snapshot = excluded.snapshot, updated_at = excluded.updated_at").run(room.code, JSON.stringify(room), at);
      this.database.prepare("INSERT INTO room_events(room_code, at, event) VALUES (?, ?, ?)").run(room.code, at, JSON.stringify(event));
      if (receipt) {
        this.database.prepare("INSERT INTO command_receipts(actor_id, command_id, payload_hash, ack, room_code, at) VALUES (?, ?, ?, ?, ?, ?)").run(receipt.actorId, receipt.commandId, receipt.payloadHash, JSON.stringify(receipt.ack), room.code, at);
      }
      this.database.exec("COMMIT");
    } catch (error) {
      this.database.exec("ROLLBACK");
      throw error;
    }
  }
  hostPresence(code) {
    const row = this.database.prepare("SELECT host_id, disconnected_at FROM host_presence WHERE room_code = ?").get(code);
    return row ? { hostId: String(row.host_id), disconnectedAt: row.disconnected_at === null ? null : Number(row.disconnected_at) } : null;
  }
  setHostPresence(code, hostId, disconnectedAt) {
    this.database.prepare("INSERT INTO host_presence(room_code, host_id, disconnected_at) VALUES (?, ?, ?) ON CONFLICT(room_code) DO UPDATE SET host_id = excluded.host_id, disconnected_at = excluded.disconnected_at").run(code, hostId, disconnectedAt);
  }
  close() {
    this.database.close();
  }
};

// src/server/app.ts
var SESSION_COOKIE = "experiment_session";
var SESSION_AGE_MS = 30 * 24 * 60 * 60 * 1e3;
var HOST_GRACE_MS = 6e4;
var nicknameSchema = z2.string().trim().min(1).max(24).refine((value) => !/[\p{Cc}\p{Cf}]/u.test(value));
var createSchema = z2.object({ nickname: nicknameSchema, settings: settingsSchema.optional() }).strict();
var joinSchema = z2.object({ nickname: nicknameSchema }).strict();
var HttpError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
function digest(value) {
  return createHash("sha256").update(value).digest("hex");
}
function stableJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(",")}}`;
}
async function createApp(options = {}) {
  const now = options.now ?? Date.now;
  const app2 = Fastify({ logger: { level: "error" }, logController: new LogController({ disableRequestLogging: true }), bodyLimit: 16384, trustProxy: process.env.TRUST_PROXY === "true" });
  const store = new Store(options.databasePath ?? process.env.DATABASE_PATH ?? resolve("data/experiment.sqlite"));
  const degradedRooms = /* @__PURE__ */ new Set();
  const commit = (room, at, event, receipt) => {
    try {
      store.commit(room, at, event, receipt);
      degradedRooms.delete(room.code);
    } catch (error) {
      if (!degradedRooms.has(room.code)) app2.log.error({ event: "persistence_failure", room: room.code }, "Room state could not be committed.");
      degradedRooms.add(room.code);
      throw error;
    }
  };
  const rooms = new Map(store.loadRooms().map((room) => [room.code, room]));
  const connections = /* @__PURE__ */ new Map();
  const queues = /* @__PURE__ */ new Map();
  const rateWindows = /* @__PURE__ */ new Map();
  const websocketContext = /* @__PURE__ */ new WeakMap();
  let shuttingDown = false;
  const publicOrigin = options.publicOrigin ?? process.env.PUBLIC_ORIGIN;
  if (publicOrigin && new URL(publicOrigin).origin !== publicOrigin) throw new Error("PUBLIC_ORIGIN must be an origin without a path");
  const rateLimit = (key, limit, duration) => {
    const time = now();
    const current = rateWindows.get(key);
    if (!current || time - current.start >= duration) {
      rateWindows.set(key, { start: time, count: 1 });
      return true;
    }
    current.count += 1;
    return current.count <= limit;
  };
  const enqueue = (code, work) => {
    const previous = queues.get(code) ?? Promise.resolve();
    const result = previous.then(work);
    queues.set(code, result.then(() => void 0, () => void 0));
    return result;
  };
  const online = (code) => new Set(connections.get(code)?.keys() ?? []);
  const send = (connection, message) => {
    if (connection.socket.readyState === 1) connection.socket.send(JSON.stringify(message));
  };
  const updateHostPresence = (room) => {
    const existing = store.hostPresence(room.code);
    const hostOnline = online(room.code).has(room.hostId);
    const disconnectedAt = hostOnline ? null : existing && existing.hostId === room.hostId && existing.disconnectedAt !== null ? existing.disconnectedAt : now();
    if (!existing || existing.hostId !== room.hostId || existing.disconnectedAt !== disconnectedAt) store.setHostPresence(room.code, room.hostId, disconnectedAt);
  };
  const broadcast = (code) => {
    const room = rooms.get(code);
    if (!room) return;
    const onlineIds = online(code);
    for (const connection of connections.get(code)?.values() ?? []) {
      const member2 = room.members.find((candidate) => candidate.id === connection.actorId);
      if (!member2 || member2.removed) {
        send(connection, { type: "error", message: "You have been removed from this room." });
        connection.socket.close(4003, "Membership removed");
        continue;
      }
      const view = projectRoom(room, connection.actorId, onlineIds);
      const serialized = JSON.stringify(view);
      if (connection.lastView === serialized) continue;
      connection.lastView = serialized;
      connection.viewVersion += 1;
      send(connection, { type: "snapshot", view, serverTime: now(), viewVersion: connection.viewVersion });
    }
    updateHostPresence(room);
  };
  const sessionId = (request) => {
    const token = request.cookies[SESSION_COOKIE];
    if (!token || !/^[A-Za-z0-9_-]{43}$/.test(token)) return null;
    return store.sessionId(digest(token), now());
  };
  const ensureSession = (request, reply) => {
    const existing = sessionId(request);
    if (existing) return existing;
    const token = randomBytes(32).toString("base64url");
    const id = randomUUID2();
    store.createSession(id, digest(token), now() + SESSION_AGE_MS);
    reply.setCookie(SESSION_COOKIE, token, { path: "/", httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production" || publicOrigin?.startsWith("https://") === true, maxAge: SESSION_AGE_MS / 1e3 });
    return id;
  };
  const assertOrigin = (request, required) => {
    const origin = request.headers.origin;
    if (!origin && !required) return;
    const expected = publicOrigin ?? `${request.protocol}://${request.headers.host}`;
    if (typeof origin !== "string" || origin !== expected) throw new HttpError(403, "ORIGIN", "Use the same website origin to access this room.");
  };
  const roomCode = (request) => {
    const code = request.params.code.toUpperCase();
    if (!/^[A-Z2-9]{6}$/.test(code)) throw new HttpError(404, "ROOM_NOT_FOUND", "Room not found. Check the six-character code.");
    return code;
  };
  const getRoom = (code) => {
    const room = rooms.get(code);
    if (!room) throw new HttpError(404, "ROOM_NOT_FOUND", "Room not found. Check the six-character code.");
    return room;
  };
  await app2.register(cookie);
  await app2.register(websocket, { options: { maxPayload: 16384 } });
  app2.addHook("onSend", async (request, reply) => {
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("X-Frame-Options", "DENY");
    reply.header("Referrer-Policy", "same-origin");
    reply.header("Content-Security-Policy", "frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
    if (request.url.startsWith("/api/")) reply.header("Cache-Control", "no-store");
  });
  app2.setErrorHandler((error, _request, reply) => {
    if (error instanceof HttpError) return reply.code(error.status).send({ error: { code: error.code, message: error.message } });
    if (error instanceof EngineError) return reply.code(409).send({ error: { code: error.code, message: error.message } });
    if (error instanceof z2.ZodError) return reply.code(400).send({ error: { code: "INVALID_REQUEST", message: "Check the nickname and room settings." } });
    if (typeof error === "object" && error !== null && "statusCode" in error && typeof error.statusCode === "number" && error.statusCode < 500) return reply.code(error.statusCode).send({ error: { code: "INVALID_REQUEST", message: "The request could not be accepted." } });
    return reply.code(500).send({ error: { code: "SERVER_ERROR", message: "The server could not save this action. Please try again." } });
  });
  app2.get("/api/health", async (_request, reply) => reply.code(degradedRooms.size ? 503 : 200).send({ ok: degradedRooms.size === 0 }));
  app2.get("/api/session", async (request) => {
    const id = sessionId(request);
    return { rooms: id ? [...rooms.values()].flatMap((room) => {
      const member2 = room.members.find((candidate) => candidate.sessionId === id && !candidate.removed);
      return member2 ? [{ code: room.code, nickname: member2.nickname, role: member2.role }] : [];
    }) : [] };
  });
  app2.post("/api/rooms", async (request, reply) => {
    assertOrigin(request, false);
    if (!rateLimit(`create:${request.ip}`, 12, 6e4)) throw new HttpError(429, "RATE_LIMIT", "Too many rooms created. Please wait a minute.");
    const body = createSchema.parse(request.body);
    const id = ensureSession(request, reply);
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code;
    do {
      code = Array.from({ length: 6 }, () => alphabet[randomInt2(alphabet.length)]).join("");
    } while (rooms.has(code));
    const memberId = randomUUID2();
    const room = createRoom(code, { id: memberId, sessionId: id, nickname: body.nickname }, body.settings ?? DEFAULT_SETTINGS, now());
    commit(room, now(), { type: "room_created", actorId: memberId });
    rooms.set(code, room);
    updateHostPresence(room);
    return reply.code(201).send({ code, memberId });
  });
  app2.post("/api/rooms/:code/join", async (request, reply) => {
    assertOrigin(request, false);
    if (!rateLimit(`join:${request.ip}`, 40, 6e4)) throw new HttpError(429, "RATE_LIMIT", "Too many join attempts. Please wait a minute.");
    const code = roomCode(request);
    const body = joinSchema.parse(request.body);
    getRoom(code);
    const id = ensureSession(request, reply);
    return enqueue(code, () => {
      const current = getRoom(code);
      const existing = current.members.find((member2) => member2.sessionId === id);
      if (existing?.removed) throw new HttpError(403, "REMOVED", "Your Subject has been removed from this room.");
      if (existing) return { code, memberId: existing.id };
      const memberId = randomUUID2();
      const room = structuredClone(current);
      addMember(room, { id: memberId, sessionId: id, nickname: body.nickname }, now());
      commit(room, now(), { type: "member_joined", actorId: memberId });
      rooms.set(code, room);
      broadcast(code);
      return { code, memberId };
    });
  });
  const rejectAck = (commandId, code, message) => ({ type: "ack", commandId, ok: false, error: { code, message } });
  const execute = (connection, command) => {
    if (connections.get(connection.code)?.get(connection.actorId) !== connection) {
      send(connection, { type: "superseded" });
      return;
    }
    processTimers(connection.code);
    const room = getRoom(connection.code);
    const member2 = room.members.find((candidate2) => candidate2.id === connection.actorId);
    if (!member2 || member2.removed) {
      send(connection, rejectAck(command.commandId, "REMOVED", "You no longer have access to this room."));
      return;
    }
    const payloadHash = digest(stableJson(command));
    const previous = store.receipt(connection.actorId, command.commandId);
    if (previous) {
      send(connection, previous.payloadHash === payloadHash ? previous.ack : rejectAck(command.commandId, "COMMAND_REUSED", "This command ID was already used for a different action."));
      return;
    }
    const candidate = structuredClone(room);
    let ack = { type: "ack", commandId: command.commandId, ok: true };
    try {
      applyCommand(candidate, connection.actorId, command, now());
    } catch (error) {
      if (!(error instanceof EngineError)) throw error;
      ack = rejectAck(command.commandId, error.code, error.message);
    }
    const receipt = { actorId: connection.actorId, commandId: command.commandId, payloadHash, ack };
    commit(ack.ok ? candidate : room, now(), { type: ack.ok ? "command_accepted" : "command_rejected", actorId: connection.actorId, command, errorCode: ack.error?.code ?? null }, receipt);
    if (ack.ok) rooms.set(connection.code, candidate);
    send(connection, ack);
    if (ack.ok) broadcast(connection.code);
  };
  app2.get("/api/rooms/:code/socket", {
    websocket: true,
    preValidation: async (request) => {
      assertOrigin(request, true);
      if (!rateLimit(`connect:${request.ip}`, 80, 6e4)) throw new HttpError(429, "RATE_LIMIT", "Too many connection attempts. Please wait a minute.");
      const code = roomCode(request);
      const id = sessionId(request);
      if (!id) throw new HttpError(401, "SESSION_REQUIRED", "Join the room before connecting.");
      const member2 = getRoom(code).members.find((candidate) => candidate.sessionId === id && !candidate.removed);
      if (!member2) throw new HttpError(403, "MEMBERSHIP_REQUIRED", "Join the room before connecting.");
      websocketContext.set(request, { code, actorId: member2.id });
    }
  }, (socket, request) => {
    const context = websocketContext.get(request);
    const connection = { socket, ...context, alive: true, lastView: null, viewVersion: 0 };
    const controls = connections.get(context.code) ?? /* @__PURE__ */ new Map();
    const old = controls.get(context.actorId);
    controls.set(context.actorId, connection);
    connections.set(context.code, controls);
    if (old) {
      send(old, { type: "superseded" });
      old.socket.close(4001, "Another tab controls this Subject");
    }
    socket.on("pong", () => {
      connection.alive = true;
    });
    socket.on("error", () => {
    });
    socket.on("message", (data, binary) => {
      if (shuttingDown) return;
      if (!rateLimit(`command:${connection.actorId}`, 100, 1e4)) {
        send(connection, { type: "error", message: "Too many actions. Wait a moment before trying again." });
        return;
      }
      let parsed;
      try {
        if (binary) throw new Error("Binary commands are not supported");
        parsed = JSON.parse(data.toString());
      } catch {
        send(connection, { type: "error", message: "Send a valid JSON game command." });
        return;
      }
      const result = commandSchema.safeParse(parsed);
      if (!result.success) {
        const id = typeof parsed === "object" && parsed !== null && "commandId" in parsed && typeof parsed.commandId === "string" && z2.string().uuid().safeParse(parsed.commandId).success ? parsed.commandId : null;
        send(connection, id ? rejectAck(id, "INVALID_COMMAND", "This action has an invalid format.") : { type: "error", message: "This action has an invalid format." });
        return;
      }
      void enqueue(context.code, () => execute(connection, result.data)).catch(() => {
        send(connection, rejectAck(result.data.commandId, "SERVER_ERROR", "This action could not be saved. Reconnect and retry."));
      });
    });
    socket.on("close", () => {
      if (controls.get(connection.actorId) !== connection) return;
      controls.delete(connection.actorId);
      if (!shuttingDown) void enqueue(context.code, () => broadcast(context.code)).catch(() => void 0);
    });
    void enqueue(context.code, () => broadcast(context.code)).catch(() => {
      socket.close(1011, "Room unavailable");
    });
  });
  const processTimers = (code) => {
    const current = getRoom(code);
    let room = structuredClone(current);
    let changed = tick(room, now());
    const presence = store.hostPresence(code);
    if (presence && presence.hostId === room.hostId && presence.disconnectedAt !== null && now() - presence.disconnectedAt >= HOST_GRACE_MS && !online(code).has(room.hostId)) {
      const successor = room.members.find((member2) => member2.role === "subject" && !member2.removed && online(code).has(member2.id));
      if (successor) {
        const command = { commandId: randomUUID2(), gameId: room.game?.id ?? null, phaseId: room.game?.phase.id ?? null, action: { type: "transfer_host", targetId: successor.id } };
        try {
          applyCommand(room, room.hostId, command, now());
          changed = true;
        } catch (error) {
          if (!(error instanceof EngineError)) throw error;
        }
      }
    }
    if (changed) {
      commit(room, now(), { type: "server_transition", previousHostId: current.hostId, hostId: room.hostId });
      rooms.set(code, room);
      broadcast(code);
    }
    updateHostPresence(rooms.get(code));
  };
  for (const room of rooms.values()) {
    updateHostPresence(room);
    processTimers(room.code);
  }
  const timer = setInterval(() => {
    if (shuttingDown) return;
    for (const code of rooms.keys()) void enqueue(code, () => processTimers(code)).catch(() => {
      if (!degradedRooms.has(code)) app2.log.error({ event: "timer_transition_failure", room: code }, "Room deadline could not be advanced.");
      degradedRooms.add(code);
    });
    const time = now();
    for (const [key, value] of rateWindows) if (time - value.start > 6e4) rateWindows.delete(key);
  }, options.timerIntervalMs ?? 500);
  timer.unref();
  const heartbeat = setInterval(() => {
    for (const controls of connections.values()) for (const connection of controls.values()) {
      if (!connection.alive) {
        connection.socket.terminate();
        continue;
      }
      connection.alive = false;
      if (connection.socket.readyState === 1) connection.socket.ping();
    }
  }, 15e3);
  heartbeat.unref();
  const staticRoot = options.staticRoot ?? resolve("dist");
  if (existsSync(resolve(staticRoot, "index.html"))) {
    await app2.register(staticFiles, { root: staticRoot });
    app2.setNotFoundHandler((request, reply) => {
      if (request.url.startsWith("/api/")) return reply.code(404).send({ error: { code: "NOT_FOUND", message: "API endpoint not found." } });
      if (request.method !== "GET") return reply.code(404).send();
      return reply.sendFile("index.html");
    });
  }
  app2.addHook("preClose", async () => {
    shuttingDown = true;
    clearInterval(timer);
    clearInterval(heartbeat);
    for (const controls of connections.values()) for (const connection of controls.values()) connection.socket.close(1001, "Server restarting");
    await Promise.all(queues.values());
  });
  app2.addHook("onClose", async () => {
    store.close();
  });
  await app2.ready();
  return app2;
}

// src/server/index.ts
var port = Number(process.env.PORT ?? 3e3);
var host2 = process.env.HOST ?? "0.0.0.0";
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("PORT must be an integer between 1 and 65535");
var app = await createApp();
await app.listen({ port, host: host2 });
console.info(`THE EXPERIMENT server listening on ${host2}:${port}`);
var shutdown = async () => {
  await app.close();
  process.exit(0);
};
process.once("SIGINT", () => {
  void shutdown();
});
process.once("SIGTERM", () => {
  void shutdown();
});
