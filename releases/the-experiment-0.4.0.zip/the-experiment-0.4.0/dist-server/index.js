// src/server/app.ts
import Fastify, { LogController } from "fastify";
import cookie from "@fastify/cookie";
import websocket from "@fastify/websocket";
import staticFiles from "@fastify/static";
import { createHash, randomBytes, randomInt as randomInt2, randomUUID as randomUUID6 } from "node:crypto";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { z as z3 } from "zod";

// src/shared/protocol.ts
import { z as z2 } from "zod";

// src/shared/survival.ts
import { z } from "zod";
var shelterTypes = ["farmhouse", "bunker", "warehouse", "apartment", "ranger_station"];
var itemIds = ["wood", "metal", "cloth", "electronics", "ammo", "food", "water", "medicine"];
var positions = ["captain", "defender", "scout", "medic", "engineer"];
var POSITIONS = {
  captain: { name: "Captain", duty: "Claim one completed community goal.", metric: "goals", target: 1 },
  defender: { name: "Defender", duty: "Defeat six infected.", metric: "kills", target: 6 },
  scout: { name: "Scout", duty: "Fully collect three supply caches.", metric: "loot", target: 3 },
  medic: { name: "Medic", duty: "Restore 40 health to survivors.", metric: "healing", target: 40 },
  engineer: { name: "Engineer", duty: "Complete two crafting or upgrade projects.", metric: "projects", target: 2 }
};
var survivalActions = [
  z.object({ type: z.literal("survival_election"), position: z.enum(positions) }).strict(),
  z.object({ type: z.literal("survival_ballot"), electionId: z.string().min(1).max(100), candidateId: z.string().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_deposit"), item: z.enum(itemIds), amount: z.number().int().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_withdraw"), item: z.enum(itemIds), amount: z.number().int().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_heal"), targetId: z.string().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_start"), shelterType: z.enum(shelterTypes), dayLengthMinutes: z.union([z.literal(60), z.literal(120), z.literal(240)]) }).strict(),
  z.object({ type: z.literal("survival_input"), moveX: z.number().finite().min(-1).max(1), moveY: z.number().finite().min(-1).max(1), aim: z.number().finite().min(-20).max(20), fire: z.boolean() }).strict(),
  z.object({ type: z.literal("survival_interact"), targetId: z.string().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_craft"), recipeId: z.string().min(1).max(80) }).strict(),
  z.object({ type: z.literal("survival_upgrade"), kind: z.enum(["weapon", "gear", "survivor", "facility", "shelter"]), targetId: z.string().max(100) }).strict(),
  z.object({ type: z.literal("survival_equip"), kind: z.enum(["weapon", "gear"]), targetId: z.string().max(100) }).strict(),
  z.object({ type: z.literal("survival_consume"), item: z.enum(["food", "water", "medicine"]) }).strict(),
  z.object({ type: z.literal("survival_shelter"), siteId: z.string().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_claim"), goalId: z.string().min(1).max(100) }).strict(),
  z.object({ type: z.literal("survival_pause"), paused: z.boolean() }).strict(),
  z.object({ type: z.literal("survival_reload") }).strict(),
  z.object({ type: z.literal("survival_respawn") }).strict()
];
var SHELTERS = {
  farmhouse: { name: "Farmhouse", description: "Open farmland, sturdy walls, room for a growing crew.", health: 1100, defense: 16, capacity: 6 },
  bunker: { name: "Bunker", description: "Heavy protection and limited space underground.", health: 1600, defense: 32, capacity: 4 },
  warehouse: { name: "Warehouse", description: "Large storage floor; reinforce its broad entrances.", health: 1300, defense: 12, capacity: 10 },
  apartment: { name: "Apartment", description: "Urban shelter with room for a larger community.", health: 950, defense: 20, capacity: 8 },
  ranger_station: { name: "Ranger Station", description: "A balanced outpost near scavenging routes.", health: 1200, defense: 23, capacity: 6 }
};
var WEAPONS = {
  pistol: { name: "Pistol", damage: 26, range: 360, cooldownMs: 340, magazine: 12, spread: 0.07 },
  rifle: { name: "Rifle", damage: 22, range: 470, cooldownMs: 170, magazine: 24, spread: 0.05 },
  shotgun: { name: "Shotgun", damage: 65, range: 240, cooldownMs: 800, magazine: 6, spread: 0.24 }
};
var emptyInventory = () => ({ wood: 0, metal: 0, cloth: 0, electronics: 0, ammo: 0, food: 0, water: 0, medicine: 0 });
var RECIPES = [
  { id: "repair", name: "Repair shelter", description: "Restore 250 shelter health", cost: { wood: 4, metal: 2 }, durationMs: 12e3, repairShelterHp: 250 },
  { id: "ammo", name: "Ammunition", description: "12 rounds", cost: { metal: 2, cloth: 1 }, durationMs: 5e3, output: { item: "ammo", amount: 12 } },
  { id: "medicine", name: "Medicine", description: "A field dressing", cost: { cloth: 2, water: 1 }, durationMs: 1e4, output: { item: "medicine", amount: 1 } },
  { id: "rifle", name: "Rifle", description: "Rapid fire, greater range", cost: { metal: 12, wood: 4, electronics: 3 }, durationMs: 3e4, weapon: "rifle" },
  { id: "shotgun", name: "Shotgun", description: "Powerful close defense", cost: { metal: 10, wood: 6 }, durationMs: 25e3, weapon: "shotgun" },
  { id: "armor", name: "Body armor", description: "Reduce infected damage", cost: { metal: 8, cloth: 6 }, durationMs: 2e4, gear: "armor" },
  { id: "backpack", name: "Backpack", description: "Increase carrying capacity", cost: { cloth: 6, wood: 2 }, durationMs: 15e3, gear: "backpack" },
  { id: "boots", name: "Boots", description: "Faster movement", cost: { cloth: 4, metal: 2 }, durationMs: 15e3, gear: "boots" },
  { id: "workbench", name: "Workbench", description: "A base crafting facility", cost: { wood: 8, metal: 4 }, durationMs: 2e4, facility: "workbench" },
  { id: "storage", name: "Storage", description: "Improve supply capacity", cost: { wood: 8, metal: 2 }, durationMs: 18e3, facility: "storage" },
  { id: "barricade", name: "Barricade", description: "Reinforce shelter defense", cost: { wood: 10, metal: 4 }, durationMs: 2e4, facility: "barricade" },
  { id: "rain_collector", name: "Rain collector", description: "Produce water at your shelter", cost: { wood: 6, metal: 6, cloth: 2 }, durationMs: 22e3, facility: "rain_collector" }
];
var UPGRADE_RULES = {
  weapon: { cost: { metal: 4, electronics: 1, cloth: 1 }, durationMs: 15e3 },
  gear: { cost: { cloth: 3, metal: 2 }, durationMs: 15e3 },
  survivor: { cost: { food: 2, medicine: 1 }, durationMs: 2e4 },
  facility: { cost: { wood: 4, metal: 3 }, durationMs: 2e4 },
  shelter: { cost: { wood: 12, metal: 8, electronics: 2 }, durationMs: 3e4 }
};

// src/shared/protocol.ts
var settingsSchema = z2.object({
  rounds: z2.number().int().min(3).max(20),
  roundCap: z2.union([z2.literal(15), z2.literal(20)]),
  extensions: z2.boolean(),
  allowSpectators: z2.boolean()
}).strict().refine((s) => s.rounds <= s.roundCap, "Round count exceeds the room cap");
var DEFAULT_SETTINGS = { rounds: 3, roundCap: 20, extensions: true, allowSpectators: true };
var actionSchema = z2.discriminatedUnion("type", [
  ...survivalActions,
  z2.object({ type: z2.literal("ready"), ready: z2.boolean() }).strict(),
  z2.object({ type: z2.literal("settings"), settings: settingsSchema }).strict(),
  z2.object({ type: z2.literal("start") }).strict(),
  z2.object({ type: z2.literal("add_cpu") }).strict(),
  z2.object({ type: z2.literal("decision"), allocation: z2.object({ medical: z2.number().int().min(0).max(3), security: z2.number().int().min(0).max(3), reserve: z2.number().int().min(0).max(3) }).strict() }).strict(),
  z2.object({ type: z2.literal("vote"), targetId: z2.string().max(100).nullable() }).strict(),
  z2.object({ type: z2.literal("chat"), text: z2.string().trim().min(1).max(500) }).strict(),
  z2.object({ type: z2.literal("statement"), text: z2.string().trim().min(1).max(500) }).strict(),
  z2.object({ type: z2.literal("advance") }).strict(),
  z2.object({ type: z2.literal("pause") }).strict(),
  z2.object({ type: z2.literal("resume") }).strict(),
  z2.object({ type: z2.literal("transfer_host"), targetId: z2.string().max(100) }).strict(),
  z2.object({ type: z2.literal("remove"), targetId: z2.string().max(100) }).strict(),
  z2.object({ type: z2.literal("set_role"), targetId: z2.string().max(100), role: z2.enum(["subject", "spectator"]) }).strict(),
  z2.object({ type: z2.literal("mute_chat"), muted: z2.boolean() }).strict(),
  z2.object({ type: z2.literal("end") }).strict(),
  z2.object({ type: z2.literal("extension"), additionalRounds: z2.union([z2.literal(1), z2.literal(2), z2.literal(3), z2.literal(5)]) }).strict(),
  z2.object({ type: z2.literal("extension_vote"), yes: z2.boolean() }).strict(),
  z2.object({ type: z2.literal("continue") }).strict(),
  z2.object({ type: z2.literal("final_choice"), choice: z2.enum(["group", "self"]) }).strict(),
  z2.object({ type: z2.literal("rematch") }).strict()
]);
var commandSchema = z2.object({
  commandId: z2.string().uuid(),
  gameId: z2.string().max(100).nullable(),
  phaseId: z2.string().max(100).nullable(),
  action: actionSchema
}).strict();

// src/server/engine.ts
import { randomUUID as randomUUID4, randomInt } from "node:crypto";

// src/server/survival.ts
import { randomUUID as randomUUID3 } from "node:crypto";

// src/server/shelterGovernance.ts
import { randomUUID } from "node:crypto";
var ShelterGovernanceError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "ShelterGovernanceError";
  }
};
var dayOf = (world) => 1 + Math.floor(world.elapsedMs / world.dayLengthMs + 1 / 3);
var distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var hash = (value) => {
  let n = 2166136261;
  for (const char of value) n = Math.imul(n ^ char.charCodeAt(0), 16777619);
  return n >>> 0;
};
var electionDuration = 3e4;
function event(world, text, kind) {
  world.events.push({ id: randomUUID(), at: world.elapsedMs, text, kind });
  if (world.events.length > 100) world.events.splice(0, world.events.length - 100);
}
function state(world) {
  if (!world.community) initializeCommunity(world);
  return world.community;
}
function addDuties(world, memberId, day = dayOf(world)) {
  const community = world.community;
  const add = (position) => {
    const existing = community.duties.find((duty) => duty.day === day && duty.position === position && (position !== "crew" || duty.memberId === memberId));
    if (existing) {
      if (position !== "crew") existing.memberId = memberId;
      return;
    }
    const definition = position === "crew" ? { duty: "Contribute two points: collect caches, fight infected, finish projects, or heal survivors.", metric: "contribution", target: 2 } : POSITIONS[position];
    community.duties.push({
      id: position === "crew" ? `duty:${day}:${memberId}:crew` : `duty:${day}:${position}`,
      memberId,
      day,
      position,
      title: definition.duty,
      metric: definition.metric,
      target: definition.target,
      progress: 0,
      completed: false
    });
  };
  add("crew");
  for (const position of positions) if (community.officers[position] === memberId) add(position);
}
function initializeCommunity(world) {
  if (world.community) return;
  world.community = {
    officers: { captain: null, defender: null, scout: null, medic: null, engineer: null },
    duties: [],
    elections: [],
    supplies: emptyInventory(),
    lastDay: dayOf(world)
  };
  for (const id of Object.keys(world.players)) addDuties(world, id);
}
function addCommunityPlayer(world, id) {
  state(world);
  if (world.players[id]) addDuties(world, id);
}
function actor(world, id) {
  if (!world.active) throw new ShelterGovernanceError("EXPEDITION_ENDED", "The expedition has ended.");
  if (world.paused) throw new ShelterGovernanceError("PAUSED", "Resume the expedition before acting.");
  const player = world.players[id];
  if (!player) throw new ShelterGovernanceError("SUBJECT_ONLY", "Observers cannot change the shelter community.");
  if (player.hp <= 0) throw new ShelterGovernanceError("DOWNED", "Recover before taking that action.");
  return player;
}
function resolveElection(world, election) {
  const community = state(world);
  const counts = new Map(election.candidates.map((id) => [id, 0]));
  for (const candidate of Object.values(election.votes)) if (counts.has(candidate)) counts.set(candidate, counts.get(candidate) + 1);
  const high = Math.max(0, ...counts.values());
  const leaders = [...counts].filter(([, count]) => count === high && count > 0).map(([id]) => id);
  if (leaders.length === 1) {
    const winner = leaders[0];
    community.officers[election.position] = winner;
    addDuties(world, winner);
    event(world, `${POSITIONS[election.position].name} election complete. The new officer received ${high} ballot${high === 1 ? "" : "s"}.`, "election_result");
  } else {
    event(world, `${POSITIONS[election.position].name} election ended ${leaders.length > 1 ? "in a tie" : "without ballots"}. The existing appointment stays in place.`, "election_result");
  }
  community.elections = community.elections.filter((current) => current.id !== election.id);
}
function applyCommunityAction(world, actorId, action, _now, _hostId, eligibleIds = new Set(Object.keys(world.players))) {
  if (!["survival_election", "survival_ballot", "survival_deposit", "survival_withdraw", "survival_heal"].includes(action.type)) return false;
  if (!survivalActions.some((schema) => schema.safeParse(action).success)) throw new ShelterGovernanceError("BAD_ACTION", "Invalid community action.");
  const player = actor(world, actorId), community = state(world);
  if (!eligibleIds.has(actorId)) throw new ShelterGovernanceError("SUBJECT_ONLY", "Your survivor seat is no longer active.");
  if (action.type === "survival_election") {
    if (community.elections.some((election) => election.position === action.position)) throw new ShelterGovernanceError("ELECTION_ACTIVE", "An election for that position is already open.");
    const eligible = [...eligibleIds].filter((id) => !!world.players[id]);
    community.elections.push({ id: randomUUID(), position: action.position, candidates: [...eligible], eligibleIds: [...eligible], votes: {}, endsAt: world.elapsedMs + electionDuration });
    event(world, `${POSITIONS[action.position].name} election opened. Each survivor has one private ballot; voting closes in 30 seconds.`, "election_start");
    return true;
  }
  if (action.type === "survival_ballot") {
    const election = community.elections.find((current) => current.id === action.electionId);
    if (!election || world.elapsedMs >= election.endsAt) throw new ShelterGovernanceError("ELECTION_CLOSED", "That election is closed.");
    if (!election.eligibleIds.includes(actorId)) throw new ShelterGovernanceError("NOT_ELIGIBLE", "You joined after this election opened. Vote in the next election.");
    if (!election.candidates.includes(action.candidateId)) throw new ShelterGovernanceError("BAD_CANDIDATE", "Choose a candidate in this election.");
    if (Object.hasOwn(election.votes, actorId)) throw new ShelterGovernanceError("BALLOT_LOCKED", "Your ballot is already locked.");
    election.votes[actorId] = action.candidateId;
    if (election.eligibleIds.every((id) => Object.hasOwn(election.votes, id))) resolveElection(world, election);
    return true;
  }
  if (action.type === "survival_deposit" || action.type === "survival_withdraw") {
    if (distance(player, world.shelter) > 200) throw new ShelterGovernanceError("TOO_FAR", "Return within 200 units of the shelter to use communal supplies.");
    const source = action.type === "survival_deposit" ? player.inventory : community.supplies;
    const destination = action.type === "survival_deposit" ? community.supplies : player.inventory;
    if (source[action.item] < action.amount) throw new ShelterGovernanceError("INSUFFICIENT_SUPPLIES", `There is not enough ${action.item} to transfer.`);
    const limit = action.item === "ammo" ? 2e3 : 500;
    if (destination[action.item] + action.amount > limit) throw new ShelterGovernanceError("INVENTORY_FULL", `The destination can hold at most ${limit} ${action.item}.`);
    if (action.type === "survival_withdraw" && action.item !== "ammo") {
      const carried2 = itemIds.reduce((sum, item) => sum + (item === "ammo" ? 0 : player.inventory[item]), 0);
      const backpack = player.gear.find((gear) => gear.id === "backpack")?.level ?? 0;
      const storage = world.facilities.find((facility) => facility.kind === "storage")?.level ?? 0;
      if (carried2 + action.amount > 60 + 20 * backpack + 20 * storage) throw new ShelterGovernanceError("INVENTORY_FULL", "Your pack cannot hold that transfer.");
    }
    source[action.item] -= action.amount;
    destination[action.item] += action.amount;
    return true;
  }
  if (action.type === "survival_heal") {
    const target = world.players[action.targetId] ?? world.survivors.find((survivor) => survivor.id === action.targetId);
    if (!target) throw new ShelterGovernanceError("BAD_TARGET", "Choose a survivor to treat.");
    if (target.hp <= 0) throw new ShelterGovernanceError("DOWNED", "A fallen survivor must recover before treatment.");
    if (distance(player, target) > 100) throw new ShelterGovernanceError("TOO_FAR", "Move within 100 units of the survivor to treat them.");
    if (target.hp >= 100) throw new ShelterGovernanceError("FULL_HEALTH", "That survivor is already healthy.");
    if (player.inventory.medicine < 1) throw new ShelterGovernanceError("INSUFFICIENT_SUPPLIES", "You need one medicine to treat a survivor.");
    const restored = Math.min(40, 100 - target.hp);
    player.inventory.medicine--;
    target.hp += restored;
    recordDuty(world, actorId, "healing", restored);
    event(world, `A survivor received field treatment and recovered ${Math.round(restored)} health.`, "healing");
    return true;
  }
  return false;
}
function recordDuty(world, actorId, metric, amount) {
  if (!world.active || world.paused || !world.players[actorId] || !Number.isFinite(amount) || amount <= 0) return;
  const community = state(world), day = dayOf(world);
  addDuties(world, actorId, day);
  const contribution = metric === "kills" ? amount * 0.5 : metric === "healing" ? amount / 40 : amount;
  for (const duty of community.duties) {
    if (duty.memberId !== actorId || duty.day !== day || duty.completed) continue;
    const advance2 = duty.metric === metric ? amount : duty.metric === "contribution" ? contribution : 0;
    if (advance2 <= 0) continue;
    duty.progress = Math.min(duty.target, duty.progress + advance2);
    if (duty.progress < duty.target) continue;
    duty.completed = true;
    community.supplies.food = Math.min(500, community.supplies.food + 1);
    community.supplies.water = Math.min(500, community.supplies.water + 1);
    community.supplies.ammo = Math.min(2e3, community.supplies.ammo + 6);
    event(world, `${duty.position === "crew" ? "Crew" : POSITIONS[duty.position].name} duty completed. Communal supplies gained one food, one water, and six rounds.`, "duty_complete");
  }
}
function tickCommunity(world, eligibleIds, cpuIds) {
  const wasMissing = !world.community, community = state(world);
  let changed = wasMissing;
  const eligible = new Set([...eligibleIds].filter((id) => !!world.players[id]));
  for (const position of positions) if (community.officers[position] && !eligible.has(community.officers[position])) {
    community.officers[position] = null;
    changed = true;
  }
  const duties = community.duties.filter((duty) => duty.position !== "crew" || eligible.has(duty.memberId));
  if (duties.length !== community.duties.length) {
    community.duties = duties;
    changed = true;
  }
  for (const id of eligible) {
    const before = community.duties.length;
    addDuties(world, id);
    changed ||= before !== community.duties.length;
  }
  for (const election of community.elections) {
    const candidates = election.candidates.filter((id) => eligible.has(id));
    const voters = election.eligibleIds.filter((id) => eligible.has(id));
    if (candidates.length !== election.candidates.length || voters.length !== election.eligibleIds.length) changed = true;
    election.candidates = candidates;
    election.eligibleIds = voters;
    for (const [voter, candidate] of Object.entries(election.votes)) if (!eligible.has(voter) || !candidates.includes(candidate)) {
      delete election.votes[voter];
      changed = true;
    }
  }
  if (!world.active || world.paused) return changed;
  const day = dayOf(world);
  while (community.lastDay < day) {
    const missed = community.duties.filter((duty) => duty.day === community.lastDay && !duty.completed && (duty.position === "crew" || community.officers[duty.position] === duty.memberId));
    if (missed.length) {
      const damage = missed.length * 20;
      world.shelter.hp = Math.max(0, world.shelter.hp - damage);
      event(world, `${missed.length} unfinished day ${community.lastDay} dut${missed.length === 1 ? "y" : "ies"} cost the shelter ${damage} health.`, "duty_missed");
    }
    community.lastDay++;
    for (const id of eligible) addDuties(world, id, community.lastDay);
    changed = true;
  }
  community.duties = community.duties.filter((duty) => duty.day >= day - 2);
  for (const election of [...community.elections]) {
    const candidates = election.candidates, voters = election.eligibleIds;
    if (world.elapsedMs >= election.endsAt - electionDuration + 1500 && world.elapsedMs < election.endsAt && candidates.length) {
      for (const id of voters) if (cpuIds.has(id) && world.players[id].hp > 0 && !Object.hasOwn(election.votes, id)) {
        election.votes[id] = candidates[hash(`${world.id}:${election.id}:${id}`) % candidates.length];
        changed = true;
      }
    }
    if (!candidates.length || world.elapsedMs >= election.endsAt || voters.every((id) => Object.hasOwn(election.votes, id))) {
      resolveElection(world, election);
      changed = true;
    }
  }
  return changed;
}
function projectCommunity(world) {
  const community = state(world);
  return structuredClone({
    officers: community.officers,
    duties: community.duties,
    supplies: community.supplies,
    elections: community.elections.map(({ id, position, candidates, eligibleIds, votes, endsAt }) => ({
      id,
      position,
      candidates,
      eligibleIds,
      ballotsCast: Object.keys(votes).length,
      endsAt
    }))
  });
}
function projectElectionVotes(world, id) {
  return Object.fromEntries(state(world).elections.flatMap((election) => Object.hasOwn(election.votes, id) ? [[election.id, election.votes[id]]] : []));
}

// src/server/survivalProgression.ts
import { randomUUID as randomUUID2 } from "node:crypto";
var SurvivalProgressionError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "SurvivalProgressionError";
  }
};
var MAX_LEVEL = 5;
var MAX_JOBS = 3;
var upgradeRules = UPGRADE_RULES;
function upgradeCost(kind, nextLevel) {
  return Object.fromEntries(Object.entries(upgradeRules[kind].cost).map(([item, amount]) => [item, amount * nextLevel]));
}
function upgradeDurationMs(kind, nextLevel) {
  return upgradeRules[kind].durationMs * nextLevel;
}
function event2(world, text, kind, speakerId) {
  world.events.push({ id: randomUUID2(), at: world.elapsedMs, text, kind, ...speakerId ? { speakerId } : {} });
  if (world.events.length > 100) world.events.splice(0, world.events.length - 100);
}
var distance2 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var survivalCalendarDay = (world) => 1 + Math.floor(world.elapsedMs / world.dayLengthMs + 1 / 3);
function actor2(world, actorId) {
  const player = world.players[actorId];
  if (!world.active) throw new SurvivalProgressionError("survival_inactive", "The survival world is not active.");
  if (world.paused) throw new SurvivalProgressionError("survival_paused", "Resume the world before taking that action.");
  if (!player) throw new SurvivalProgressionError("survival_observer", "Observers cannot change survival equipment.");
  if (player.hp <= 0) throw new SurvivalProgressionError("survival_downed", "Recover before taking that action.");
  return player;
}
function nearBase(world, player) {
  if (distance2(player, world.shelter) > 200) throw new SurvivalProgressionError("survival_base_required", "Return within 200 units of your shelter to build or upgrade.");
}
function pay(player, cost) {
  for (const item of itemIds) if (player.inventory[item] < (cost[item] ?? 0)) {
    throw new SurvivalProgressionError("survival_materials", `Not enough ${item} for this project.`);
  }
  for (const item of itemIds) player.inventory[item] -= cost[item] ?? 0;
}
function hasPending(world, kind, targetId, ownerId) {
  return world.jobs.some((job) => job.kind === kind && job.targetId === targetId && (ownerId === void 0 || job.ownerId === ownerId));
}
function availableQueue(world) {
  if (world.jobs.length >= MAX_JOBS) throw new SurvivalProgressionError("survival_queue_full", "Three projects are already in progress.");
}
function craftSpeed(world) {
  return 1 + 0.2 * (world.facilities.find((facility) => facility.kind === "workbench")?.level ?? 0);
}
function carryingCapacity(world, playerId) {
  const backpack = world.players[playerId]?.gear.find((gear) => gear.id === "backpack")?.level ?? 0;
  const storage = world.facilities.find((facility) => facility.kind === "storage")?.level ?? 0;
  return 60 + backpack * 20 + storage * 20;
}
function carried(player) {
  return itemIds.reduce((total, item) => total + (item === "ammo" ? 0 : player.inventory[item]), 0);
}
function shelterStatistics(world) {
  const shelter = world.shelter;
  const base = SHELTERS[shelter.type];
  const ratio = shelter.maxHp > 0 ? Math.max(0, Math.min(1, shelter.hp / shelter.maxHp)) : 1;
  const maxHp = Math.round(base.health * (1 + 0.25 * (shelter.level - 1)));
  shelter.maxHp = maxHp;
  shelter.hp = Math.round(maxHp * ratio);
  shelter.defense = base.defense + 5 * (shelter.level - 1) + 5 * (world.facilities.find((facility) => facility.kind === "barricade")?.level ?? 0);
  shelter.capacity = base.capacity + Math.floor((shelter.level - 1) / 2);
}
var goalTemplates = {
  daily: [
    { title: "Supply run: open 4 caches", metric: "loot", target: 4, reward: { food: 3, water: 3 } },
    { title: "Clear the perimeter: defeat 8 infected", metric: "kills", target: 8, reward: { ammo: 18, medicine: 1 } },
    { title: "Invest in survival: finish an upgrade", metric: "upgrades", target: 1, reward: { wood: 4, metal: 4 } }
  ],
  weekly: [
    { title: "Hold the line: survive 3 horde waves", metric: "waves", target: 3, reward: { metal: 10, ammo: 36 } },
    { title: "Bring them home: rescue 2 survivors", metric: "rescues", target: 2, reward: { food: 6, medicine: 3 } },
    { title: "Make it through: survive 5 days", metric: "days", target: 5, reward: { wood: 12, water: 8 } }
  ],
  monthly: [
    { title: "Keep the community alive for 20 days", metric: "days", target: 20, reward: { food: 20, medicine: 8 } },
    { title: "Build a future: finish 12 upgrades", metric: "upgrades", target: 12, reward: { electronics: 12, metal: 20 } },
    { title: "Reclaim the district: defeat 100 infected", metric: "kills", target: 100, reward: { ammo: 100, cloth: 20 } }
  ]
};
function remainingUpgradePotential(world) {
  const remainingLevels = (level) => Math.max(0, MAX_LEVEL - level);
  let remaining = remainingLevels(world.shelter.level);
  for (const kind of ["workbench", "storage", "barricade", "rain_collector"]) {
    remaining += remainingLevels(world.facilities.find((facility) => facility.kind === kind)?.level ?? 1);
  }
  for (const player of Object.values(world.players)) {
    for (const id of Object.keys(WEAPONS)) remaining += remainingLevels(player.weapons.find((weapon) => weapon.id === id)?.level ?? 1);
    for (const id of ["armor", "backpack", "boots"]) remaining += remainingLevels(player.gear.find((gear) => gear.id === id)?.level ?? 1);
  }
  for (const survivor of world.survivors) remaining += remainingLevels(survivor.level);
  remaining += world.rescues.filter((rescue) => !rescue.rescued).length * (MAX_LEVEL - 1);
  return remaining;
}
function templatesFor(world, period) {
  return goalTemplates[period].map((template) => {
    if (template.metric === "rescues" && world.rescues.filter((rescue) => !rescue.rescued).length < template.target) {
      return { ...template, title: "Restock the community: open 12 caches", metric: "loot", target: 12 };
    }
    if (template.metric === "upgrades" && remainingUpgradePotential(world) < template.target) {
      return period === "daily" ? { ...template, title: "Keep supplies flowing: open 6 caches", metric: "loot", target: 6 } : { ...template, title: "Protect the community: survive 5 horde waves", metric: "waves", target: 5 };
    }
    return template;
  });
}
function periodStart(day, period) {
  const length = period === "daily" ? 1 : period === "weekly" ? 7 : 30;
  return 1 + Math.floor((day - 1) / length) * length;
}
function refreshGoals(world, day) {
  let changed = false;
  for (const period of ["daily", "weekly", "monthly"]) {
    const start = periodStart(day, period);
    const length = period === "daily" ? 1 : period === "weekly" ? 7 : 30;
    if (world.goals.some((goal) => goal.period === period && goal.expiresDay === start + length)) continue;
    world.goals = world.goals.filter((goal) => goal.period !== period);
    world.goals.push(...templatesFor(world, period).map((template, index) => ({
      ...template,
      reward: { ...template.reward },
      id: `${period}-${start}-${index}`,
      period,
      progress: 0,
      claimed: false,
      expiresDay: start + length
    })));
    changed = true;
  }
  return changed;
}
function initializeProgression(world) {
  shelterStatistics(world);
  refreshGoals(world, survivalCalendarDay(world));
  if (!world.lastDay || world.lastDay < 1) world.lastDay = survivalCalendarDay(world);
}
function recordProgress(world, actorId, metric, amount = 1) {
  if (!Number.isFinite(amount) || amount <= 0) return;
  amount = Math.min(1e6, Math.floor(amount));
  const player = world.players[actorId];
  if (player) {
    player.stats[metric] += amount;
    if (metric === "kills" || metric === "loot") recordDuty(world, actorId, metric, amount);
  }
  for (const goal of world.goals) if (goal.metric === metric && !goal.claimed) goal.progress = Math.min(goal.target, goal.progress + amount);
}
function queueCraft(world, player, recipeId) {
  nearBase(world, player);
  const recipe = RECIPES.find((candidate) => candidate.id === recipeId);
  if (!recipe) throw new SurvivalProgressionError("survival_recipe", "That recipe is not available.");
  availableQueue(world);
  if (recipe.weapon && (player.weapons.some((weapon) => weapon.id === recipe.weapon) || hasPending(world, "craft", recipeId, player.id))) {
    throw new SurvivalProgressionError("survival_owned", "You already own or are building this weapon.");
  }
  if (recipe.gear && (player.gear.some((gear) => gear.id === recipe.gear) || hasPending(world, "craft", recipeId, player.id))) {
    throw new SurvivalProgressionError("survival_owned", "You already own or are building this gear.");
  }
  if (recipe.facility && (world.facilities.some((facility) => facility.kind === recipe.facility) || hasPending(world, "craft", recipeId))) {
    throw new SurvivalProgressionError("survival_owned", "This shelter facility already exists or is being built.");
  }
  if (recipe.repairShelterHp && world.shelter.hp >= world.shelter.maxHp) throw new SurvivalProgressionError("survival_full", "Your shelter does not need repairs.");
  pay(player, recipe.cost);
  world.jobs.push({
    id: randomUUID2(),
    ownerId: player.id,
    kind: "craft",
    targetId: recipe.id,
    level: 1,
    finishAt: world.elapsedMs + Math.ceil(recipe.durationMs / craftSpeed(world)),
    label: recipe.name
  });
  event2(world, `${recipe.name} construction started.`, "project");
}
function queueUpgrade(world, player, kind, targetId) {
  nearBase(world, player);
  availableQueue(world);
  const personal = kind === "weapon" || kind === "gear";
  if (hasPending(world, kind, kind === "shelter" ? "shelter" : targetId, personal ? player.id : void 0)) throw new SurvivalProgressionError("survival_project_duplicate", "That upgrade is already in progress.");
  const target = kind === "weapon" ? player.weapons.find((weapon) => weapon.id === targetId) : kind === "gear" ? player.gear.find((gear) => gear.id === targetId) : kind === "survivor" ? world.survivors.find((survivor) => survivor.id === targetId) : kind === "facility" ? world.facilities.find((facility) => facility.id === targetId) : targetId === world.shelter.siteId || targetId === "shelter" ? world.shelter : void 0;
  if (!target) throw new SurvivalProgressionError("survival_target", "That upgrade target is not owned or available.");
  if (target.level >= MAX_LEVEL) throw new SurvivalProgressionError("survival_level_cap", "This is already at maximum level 5.");
  const level = target.level + 1;
  pay(player, upgradeCost(kind, level));
  world.jobs.push({
    id: randomUUID2(),
    ownerId: player.id,
    kind,
    targetId: kind === "shelter" ? "shelter" : targetId,
    level,
    finishAt: world.elapsedMs + Math.ceil(upgradeDurationMs(kind, level) / craftSpeed(world)),
    label: `${kind.charAt(0).toUpperCase() + kind.slice(1)} level ${level}`
  });
  event2(world, `${kind.charAt(0).toUpperCase() + kind.slice(1)} level ${level} upgrade started.`, "project");
}
function finishJob(world, job) {
  const owner = world.players[job.ownerId];
  if (job.kind === "craft") {
    const recipe = RECIPES.find((candidate) => candidate.id === job.targetId);
    if (!recipe) return;
    if (recipe.output && owner) owner.inventory[recipe.output.item] += recipe.output.amount;
    if (recipe.weapon && owner && !owner.weapons.some((weapon) => weapon.id === recipe.weapon)) owner.weapons.push({ id: recipe.weapon, level: 1, magazine: 0 });
    if (recipe.gear && owner && !owner.gear.some((gear) => gear.id === recipe.gear)) owner.gear.push({ id: recipe.gear, level: 1 });
    if (recipe.facility && !world.facilities.some((facility) => facility.kind === recipe.facility)) world.facilities.push({ id: recipe.facility, kind: recipe.facility, level: 1 });
    if (recipe.repairShelterHp) world.shelter.hp = Math.min(world.shelter.maxHp, world.shelter.hp + recipe.repairShelterHp);
    if (recipe.facility) shelterStatistics(world);
  } else {
    const target = job.kind === "weapon" ? owner?.weapons.find((weapon) => weapon.id === job.targetId) : job.kind === "gear" ? owner?.gear.find((gear) => gear.id === job.targetId) : job.kind === "survivor" ? world.survivors.find((survivor) => survivor.id === job.targetId) : job.kind === "facility" ? world.facilities.find((facility) => facility.id === job.targetId) : world.shelter;
    if (!target) return;
    target.level = job.level;
    if (job.kind === "shelter" || job.kind === "facility") shelterStatistics(world);
    recordProgress(world, job.ownerId, "upgrades");
  }
  recordDuty(world, job.ownerId, "projects", 1);
  event2(world, `${job.label} completed.`, "project_complete");
}
function supplyRecipient(world, activeIds2) {
  return Object.values(world.players).filter((player) => (!activeIds2 || activeIds2.has(player.id)) && player.hp > 0 && distance2(player, world.shelter) <= 300 && carried(player) < carryingCapacity(world, player.id)).sort((a, b) => distance2(a, world.shelter) - distance2(b, world.shelter) || a.id.localeCompare(b.id))[0];
}
function addSupply(world, item, amount, activeIds2) {
  const recipient = supplyRecipient(world, activeIds2);
  if (!recipient) return;
  const space = carryingCapacity(world, recipient.id) - carried(recipient);
  recipient.inventory[item] += Math.max(0, Math.min(space, amount));
}
function supportSurvivor(world, survivor, activeIds2) {
  if (survivor.hp <= 0 || survivor.role === "guardian" || world.elapsedMs < survivor.nextActionAt) return;
  if (survivor.role === "medic") {
    survivor.nextActionAt = world.elapsedMs + 15e3;
    const patient = Object.values(world.players).filter((player) => (!activeIds2 || activeIds2.has(player.id)) && player.hp > 0 && player.hp < 100 && distance2(player, world.shelter) <= 200).sort((a, b) => a.hp - b.hp || a.id.localeCompare(b.id))[0];
    if (patient) patient.hp = Math.min(100, patient.hp + 8 + survivor.level * 4);
  } else if (survivor.role === "engineer") {
    survivor.nextActionAt = world.elapsedMs + 3e4;
    if (world.shelter.hp > 0) world.shelter.hp = Math.min(world.shelter.maxHp, world.shelter.hp + survivor.level * 8);
  } else {
    survivor.nextActionAt = world.elapsedMs + 45e3;
    const resources = ["wood", "metal", "food"];
    const seed = [...survivor.id].reduce((sum, character) => sum + character.charCodeAt(0), Math.floor(world.elapsedMs / 45e3));
    addSupply(world, resources[seed % resources.length], survivor.level, activeIds2);
  }
}
function tickProgression(world, deltaMs, activeIds2) {
  if (!world.active || world.paused || deltaMs <= 0) return false;
  let changed = false;
  const day = survivalCalendarDay(world);
  if (day !== world.lastDay) {
    const elapsedDays = Math.max(0, day - world.lastDay);
    changed = refreshGoals(world, day) || changed;
    for (const player of Object.values(world.players)) if (!activeIds2 || activeIds2.has(player.id)) player.stats.days += elapsedDays;
    recordProgress(world, "", "days", elapsedDays);
    world.lastDay = day;
    event2(world, `Day ${day} begins. Daily objectives refreshed.`, "new_day");
    changed = true;
  }
  const readyJobs = world.jobs.filter((job) => job.finishAt <= world.elapsedMs);
  if (readyJobs.length) {
    world.jobs = world.jobs.filter((job) => job.finishAt > world.elapsedMs);
    for (const job of readyJobs) finishJob(world, job);
    changed = true;
  }
  for (const survivor of world.survivors) if (survivor.role !== "guardian" && survivor.hp > 0 && survivor.nextActionAt <= world.elapsedMs) {
    supportSurvivor(world, survivor, activeIds2);
    changed = true;
  }
  const collector = world.facilities.find((facility) => facility.kind === "rain_collector");
  const previousElapsed = Math.max(0, world.elapsedMs - deltaMs);
  const waterCycles = Math.floor(world.elapsedMs / 45e3) - Math.floor(previousElapsed / 45e3);
  if (collector && waterCycles > 0) {
    addSupply(world, "water", Math.min(waterCycles, 20) * collector.level, activeIds2);
    changed = true;
  }
  return changed;
}
function applyProgressionAction(world, actorId, action, _now, hostId) {
  if (!["survival_craft", "survival_upgrade", "survival_equip", "survival_consume", "survival_shelter", "survival_claim", "survival_interact"].includes(action.type)) return false;
  const rescue = action.type === "survival_interact" ? world.rescues.find((site) => site.id === action.targetId) : void 0;
  if (action.type === "survival_interact" && !rescue) return false;
  const player = actor2(world, actorId);
  if (action.type === "survival_craft") queueCraft(world, player, action.recipeId);
  else if (action.type === "survival_upgrade") queueUpgrade(world, player, action.kind, action.targetId);
  else if (action.type === "survival_equip") {
    if (action.kind === "weapon") {
      const weapon = player.weapons.find((candidate) => candidate.id === action.targetId);
      if (!weapon) throw new SurvivalProgressionError("survival_equipment", "You do not own that weapon.");
      if (player.equippedWeapon !== weapon.id) {
        player.equippedWeapon = weapon.id;
        player.reloadUntil = 0;
      }
    } else if (!player.gear.some((gear) => gear.id === action.targetId)) throw new SurvivalProgressionError("survival_equipment", "You do not own that gear.");
  } else if (action.type === "survival_consume") {
    const stat = action.item === "food" ? "hunger" : action.item === "water" ? "thirst" : "hp";
    if (player[stat] >= 100) throw new SurvivalProgressionError("survival_full", `Your ${stat === "hp" ? "health" : stat} is already full.`);
    if (player.inventory[action.item] <= 0) throw new SurvivalProgressionError("survival_materials", `You have no ${action.item}.`);
    player.inventory[action.item]--;
    player[stat] = Math.min(100, player[stat] + (action.item === "food" ? 35 : action.item === "water" ? 45 : 40));
  } else if (action.type === "survival_shelter") {
    if (actorId !== hostId) throw new SurvivalProgressionError("host_required", "Only the host can move the shared shelter.");
    if (world.wave.active) throw new SurvivalProgressionError("survival_horde", "Defeat the active horde before moving shelter.");
    const site = world.sites.find((candidate) => candidate.id === action.siteId);
    if (!site?.discovered) throw new SurvivalProgressionError("survival_undiscovered", "Discover this shelter site first.");
    if (site.id === world.shelter.siteId) throw new SurvivalProgressionError("survival_current_shelter", "This is already your active shelter.");
    if (distance2(player, site) > 120) throw new SurvivalProgressionError("survival_proximity", "Travel within 120 units of the new shelter before moving.");
    const capacity = SHELTERS[site.type].capacity + Math.floor((world.shelter.level - 1) / 2);
    if (world.survivors.length > capacity) throw new SurvivalProgressionError("survival_capacity", "This shelter does not have room for your recruited survivors.");
    world.shelter.siteId = site.id;
    world.shelter.type = site.type;
    world.shelter.x = site.x;
    world.shelter.y = site.y;
    shelterStatistics(world);
    for (const [index, survivor] of world.survivors.entries()) {
      survivor.x = site.x + Math.cos(index * 2) * 60;
      survivor.y = site.y + Math.sin(index * 2) * 60;
    }
    event2(world, `The community moved into the ${SHELTERS[site.type].name}. Improvements and crew relocated.`, "shelter_move");
  } else if (action.type === "survival_claim") {
    const goal = world.goals.find((candidate) => candidate.id === action.goalId);
    if (!goal || goal.expiresDay <= survivalCalendarDay(world)) throw new SurvivalProgressionError("survival_goal", "This objective is no longer available.");
    if (goal.claimed) throw new SurvivalProgressionError("survival_goal_claimed", "The room has already claimed this reward.");
    if (goal.progress < goal.target) throw new SurvivalProgressionError("survival_goal_incomplete", "Complete the objective before claiming its reward.");
    goal.claimed = true;
    recordDuty(world, actorId, "goals", 1);
    for (const item of itemIds) player.inventory[item] += goal.reward[item] ?? 0;
    event2(world, `${goal.title} completed. Its shared-room reward was claimed by one player.`, "goal_claim");
  } else if (rescue) {
    if (rescue.rescued) throw new SurvivalProgressionError("survival_rescued", "This survivor has already joined your shelter.");
    if (distance2(player, rescue) > 100) throw new SurvivalProgressionError("survival_proximity", "Move within 100 units to recruit this survivor.");
    if (world.survivors.length >= world.shelter.capacity) throw new SurvivalProgressionError("survival_capacity", "Your shelter has no more room for survivors.");
    pay(player, { food: 2, medicine: 1 });
    rescue.rescued = true;
    world.survivors.push({
      id: rescue.id,
      name: rescue.name,
      role: rescue.role,
      level: 1,
      hp: 100,
      x: world.shelter.x + 50,
      y: world.shelter.y + 50,
      nextActionAt: world.elapsedMs + 5e3
    });
    recordProgress(world, actorId, "rescues");
    event2(world, `${rescue.name}, a ${rescue.role}, joined the shelter.`, "rescue");
    const greeting = {
      guardian: "I'll hold the perimeter. Keep ammunition coming.",
      medic: "Bring the injured back to the shelter. I'll patch them up.",
      scavenger: "I'll search for supplies. Leave a little room in your pack.",
      engineer: "I'll keep these walls standing. Let's build something that lasts."
    }[rescue.role];
    event2(world, greeting, "survivor_dialogue", rescue.id);
  }
  return true;
}

// src/server/survival.ts
var SurvivalError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "SurvivalError";
  }
};
function fail(code, message) {
  throw new SurvivalError(code, message);
}
var distance3 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var clamp = (n, low, high) => Math.min(high, Math.max(low, n));
var SAFE_RADIUS = 95;
var MAX_ENEMIES = 64;
var hash2 = (value) => {
  let n = 2166136261;
  for (const char of value) n = Math.imul(n ^ char.charCodeAt(0), 16777619);
  return n >>> 0;
};
function event3(world, text, kind) {
  world.events.push({ id: randomUUID3(), at: world.elapsedMs, text, kind });
  if (world.events.length > 60) world.events.splice(0, world.events.length - 60);
}
var calendar = (world) => {
  const total = world.elapsedMs / world.dayLengthMs + 1 / 3;
  const day = 1 + Math.floor(total);
  const hour = total % 1 * 24;
  return { day, hour, week: 1 + Math.floor((day - 1) / 7), month: 1 + Math.floor((day - 1) / 30), night: hour >= 20 || hour < 6 };
};
function addSurvivalPlayer(world, id, now = world.lastTickAt) {
  if (world.players[id]) return;
  const angle = Object.keys(world.players).length * 2.399;
  world.players[id] = {
    id,
    x: world.shelter.x + Math.cos(angle) * 54,
    y: world.shelter.y + Math.sin(angle) * 54,
    aim: angle,
    hp: 100,
    hunger: 100,
    thirst: 100,
    stamina: 100,
    inventory: { ...emptyInventory(), wood: 8, metal: 6, cloth: 4, electronics: 1, ammo: 60, food: 5, water: 5, medicine: 2 },
    weapons: [{ id: "pistol", level: 1, magazine: 12 }],
    gear: [],
    equippedWeapon: "pistol",
    stats: { kills: 0, loot: 0, rescues: 0, upgrades: 0, waves: 0, days: 0 },
    input: { moveX: 0, moveY: 0, aim: angle, fire: false, receivedAt: now },
    nextShotAt: 0,
    reloadUntil: 0,
    downUntil: 0,
    lastDamageAt: 0
  };
  if (world.community) addCommunityPlayer(world, id);
}
function createSurvivalWorld(memberIds, shelterType, dayLengthMinutes, now) {
  if (!SHELTERS[shelterType] || ![60, 120, 240].includes(dayLengthMinutes)) fail("BAD_SETTINGS", "Choose a shelter and a 1, 2, or 4 hour survival day.");
  const sites = [
    { id: "site-farmhouse", type: "farmhouse", x: 1500, y: 1100, discovered: false },
    { id: "site-bunker", type: "bunker", x: 970, y: 780, discovered: false },
    { id: "site-warehouse", type: "warehouse", x: 2110, y: 940, discovered: false },
    { id: "site-apartment", type: "apartment", x: 1860, y: 1650, discovered: false },
    { id: "site-ranger-station", type: "ranger_station", x: 810, y: 1510, discovered: false }
  ];
  const chosen = sites.find((site) => site.type === shelterType);
  chosen.discovered = true;
  const info = SHELTERS[shelterType];
  const world = {
    id: randomUUID3(),
    active: true,
    paused: false,
    elapsedMs: 0,
    dayLengthMs: dayLengthMinutes * 6e4,
    lastTickAt: now,
    tickNumber: 0,
    width: 3e3,
    height: 2200,
    players: {},
    shelter: { siteId: chosen.id, type: shelterType, x: chosen.x, y: chosen.y, level: 1, hp: info.health, maxHp: info.health, defense: info.defense, capacity: info.capacity },
    sites,
    containers: [],
    enemies: [],
    rescues: [],
    survivors: [],
    facilities: [],
    jobs: [],
    goals: [],
    events: [],
    wave: { active: false, number: 0, completed: 0, nextAt: 9e4, remainingSpawns: 0, nextSpawnAt: 0 },
    nextRoamerAt: 12e3,
    lastDay: 1
  };
  for (const id of [...new Set(memberIds)]) addSurvivalPlayer(world, id, now);
  const labels = ["Abandoned supply crate", "Emergency medical case", "Workshop cache", "Sealed ammunition box", "Evacuation baggage", "Ration locker"];
  for (let i = 0; i < 26; i++) {
    const angle = i * 2.399;
    const radius = i < 5 ? 170 + i * 36 : 370 + i % 7 * 90;
    world.containers.push({
      id: `loot-${i + 1}`,
      x: clamp(chosen.x + Math.cos(angle) * radius, 65, world.width - 65),
      y: clamp(chosen.y + Math.sin(angle) * radius, 65, world.height - 65),
      label: labels[i % labels.length],
      opened: false,
      contents: i % 3 === 0 ? { metal: 5, cloth: 3, ammo: 24, medicine: 1 } : i % 3 === 1 ? { wood: 7, metal: 3, electronics: 2, food: 2 } : { food: 3, water: 4, cloth: 4, ammo: 18 },
      ...i === 1 || i === 16 ? { weapon: "rifle" } : i === 6 ? { weapon: "shotgun" } : {},
      ...i === 3 ? { gear: "armor" } : i === 8 ? { gear: "backpack" } : i === 10 ? { gear: "boots" } : {},
      respawnDay: 3
    });
  }
  const rescueRoles = ["guardian", "medic", "scavenger", "engineer"];
  const names = ["Mara", "Luis", "Sana", "Drew", "Imani", "Owen", "Vera", "Ezra", "Talia", "Rafael", "Noor", "Cole"];
  for (let i = 0; i < 12; i++) {
    const angle = i < 4 ? 0.8 + i * 1.5 : 0.8 + i * 2.399;
    const radius = i < 4 ? 330 + i * 80 : 720 + (i - 4) * 85;
    world.rescues.push({ id: `rescue-${i + 1}`, name: names[i], role: rescueRoles[i % 4], x: clamp(chosen.x + Math.cos(angle) * radius, 65, 2935), y: clamp(chosen.y + Math.sin(angle) * radius, 65, 2135), rescued: false });
  }
  for (let i = 0; i < 4; i++) spawnEnemy(world, false, i * 1.55 + 0.1, 310 + i * 35);
  initializeProgression(world);
  initializeCommunity(world);
  event3(world, "Day 1 \xB7 08:00. Your shelter is secure for now. Explore, collect supplies, recruit survivors, and prepare for the first night.", "start");
  return world;
}
function spawnEnemy(world, horde, angle, radius) {
  if (world.enemies.length >= MAX_ENEMIES) return;
  const seed = hash2(`${world.id}:${world.tickNumber}:${world.enemies.length}:${world.wave.number}`);
  const a = angle ?? seed % 6283 / 1e3;
  const r = radius ?? (horde ? 610 + seed % 180 : 460 + seed % 360);
  const brute = horde && world.wave.number >= 2 && seed % 5 === 0;
  const hp = brute ? 145 + world.wave.number * 8 : 58 + Math.min(38, world.wave.number * 3);
  world.enemies.push({ id: randomUUID3(), x: clamp(world.shelter.x + Math.cos(a) * r, 30, world.width - 30), y: clamp(world.shelter.y + Math.sin(a) * r, 30, world.height - 30), hp, maxHp: hp, kind: brute ? "brute" : "infected", horde, attackAt: world.elapsedMs + 700 });
}
function inventoryLoad(player) {
  return itemIds.reduce((sum, item) => sum + (item === "ammo" ? 0 : player.inventory[item]), 0);
}
function loot(world, player, targetId) {
  const container = world.containers.find((c) => c.id === targetId);
  if (!container) fail("BAD_TARGET", "That object cannot be collected.");
  if (distance3(player, container) > 100) fail("TOO_FAR", "Move closer to the supply crate to collect it.");
  if (container.opened) fail("ALREADY_COLLECTED", "These supplies have already been collected.");
  let room = Math.max(0, carryingCapacity(world, player.id) - inventoryLoad(player));
  let transferred = 0;
  for (const item of itemIds) {
    const available = container.contents[item] ?? 0;
    const amount = Math.min(available, item === "ammo" ? 2e3 - player.inventory.ammo : Math.min(room, 500 - player.inventory[item]));
    if (amount <= 0) continue;
    player.inventory[item] += amount;
    container.contents[item] = available - amount;
    transferred += amount;
    if (item !== "ammo") room -= amount;
  }
  if (container.weapon && !player.weapons.some((w) => w.id === container.weapon)) {
    player.weapons.push({ id: container.weapon, level: 1, magazine: WEAPONS[container.weapon].magazine });
    delete container.weapon;
    transferred++;
  }
  if (container.gear && !player.gear.some((g) => g.id === container.gear)) {
    player.gear.push({ id: container.gear, level: 1 });
    delete container.gear;
    transferred++;
  }
  if (!transferred) fail("INVENTORY_FULL", "Your pack is full. Spend supplies or upgrade your backpack before collecting more.");
  if (itemIds.every((item) => (container.contents[item] ?? 0) === 0) && !container.weapon && !container.gear) {
    container.opened = true;
    container.respawnDay = calendar(world).day + 2;
    container.respawnAt = world.elapsedMs + 12 * 6e4;
    recordProgress(world, player.id, "loot");
  }
  event3(world, `${container.label} scavenged. Supplies are stored in the collector\u2019s pack.`, "loot");
}
function beginReload(world, player) {
  const weapon = player.weapons.find((w) => w.id === player.equippedWeapon);
  if (player.reloadUntil > 0) return;
  if (weapon.magazine >= WEAPONS[weapon.id].magazine || player.inventory.ammo < 1) return;
  player.reloadUntil = world.elapsedMs + (weapon.id === "shotgun" ? 1900 : 1300);
}
function killEnemy(world, enemy, playerId) {
  world.enemies = world.enemies.filter((e) => e.id !== enemy.id);
  if (playerId) recordProgress(world, playerId, "kills");
  if (hash2(enemy.id) % 3 === 0 && world.containers.length < 80) world.containers.push({ id: `drop-${enemy.id}`, x: enemy.x, y: enemy.y, label: "Infected supply drop", opened: false, contents: { ammo: 8, metal: 1 }, respawnDay: calendar(world).day + 2 });
}
function fire(world, player) {
  if (player.hp <= 0 || player.reloadUntil > world.elapsedMs || player.nextShotAt > world.elapsedMs) return;
  const owned = player.weapons.find((w) => w.id === player.equippedWeapon);
  const weapon = WEAPONS[owned.id];
  if (owned.magazine <= 0) {
    beginReload(world, player);
    return;
  }
  owned.magazine--;
  player.nextShotAt = world.elapsedMs + weapon.cooldownMs;
  const dx = Math.cos(player.aim), dy = Math.sin(player.aim);
  const targets = world.enemies.map((enemy) => {
    const ex = enemy.x - player.x, ey = enemy.y - player.y;
    return { enemy, along: ex * dx + ey * dy, lateral: Math.abs(ex * dy - ey * dx) };
  }).filter((hit) => hit.along >= -14 && hit.along <= weapon.range && hit.lateral <= 19 + hit.along * weapon.spread).sort((a, b) => a.along - b.along);
  const count = owned.id === "shotgun" ? 3 : 1;
  for (const { enemy } of targets.slice(0, count)) {
    enemy.hp -= weapon.damage * (1 + (owned.level - 1) * 0.2);
    if (enemy.hp <= 0) killEnemy(world, enemy, player.id);
  }
}
function down(world, player) {
  if (player.downUntil > world.elapsedMs) return;
  player.hp = 0;
  player.downUntil = world.elapsedMs + 2e4;
  player.input.moveX = player.input.moveY = 0;
  player.input.fire = false;
  player.reloadUntil = 0;
  event3(world, "A survivor has fallen. Shelter recovery becomes available after 20 seconds.", "downed");
}
function applySurvivalAction(world, actorId, action, now, hostId, eligibleIds = new Set(Object.keys(world.players))) {
  if (!survivalActions.some((schema) => schema.safeParse(action).success)) fail("BAD_ACTION", "Invalid survival action.");
  if (action.type === "survival_pause") {
    if (actorId !== hostId) fail("HOST_ONLY", "Only the host can pause the expedition.");
    world.paused = action.paused;
    world.lastTickAt = now;
    for (const p of Object.values(world.players)) {
      p.input.fire = false;
      p.input.moveX = p.input.moveY = 0;
    }
    event3(world, action.paused ? "The expedition is paused." : "The expedition has resumed.", "pause");
    return;
  }
  const player = world.players[actorId];
  if (!player) fail("SUBJECT_ONLY", "Join an active survivor seat to play.");
  if (!world.active) fail("EXPEDITION_ENDED", "The shelter has fallen. Start a new expedition to continue.");
  if (world.paused) fail("PAUSED", "The expedition is paused.");
  if (action.type === "survival_start") fail("BAD_STATE", "This expedition is already running.");
  if (action.type === "survival_respawn") {
    if (player.hp > 0) fail("NOT_DOWNED", "You are already standing.");
    if (world.elapsedMs < player.downUntil) fail("RECOVERY_PENDING", "Shelter recovery is not ready yet.");
    player.x = world.shelter.x;
    player.y = world.shelter.y;
    player.hp = 75;
    player.hunger = Math.max(40, player.hunger);
    player.thirst = Math.max(40, player.thirst);
    player.downUntil = 0;
    player.lastDamageAt = world.elapsedMs;
    event3(world, "A fallen survivor recovered at the shelter.", "recovered");
    return;
  }
  if (player.hp <= 0) fail("DOWNED", "Recover at your shelter before acting.");
  if (action.type === "survival_input") {
    const length = Math.hypot(action.moveX, action.moveY);
    player.input = { ...action, moveX: length > 1 ? action.moveX / length : action.moveX, moveY: length > 1 ? action.moveY / length : action.moveY, aim: Math.atan2(Math.sin(action.aim), Math.cos(action.aim)), receivedAt: now };
    return;
  }
  if (action.type === "survival_reload") {
    beginReload(world, player);
    return;
  }
  if (action.type === "survival_equip") {
    if (action.kind === "weapon") {
      const weapon = player.weapons.find((w) => w.id === action.targetId);
      if (!weapon) fail("NOT_OWNED", "You do not own that weapon.");
      if (player.reloadUntil > world.elapsedMs) fail("RELOADING", "Finish reloading before changing weapons.");
      player.equippedWeapon = weapon.id;
    } else if (!player.gear.some((g) => g.id === action.targetId)) fail("NOT_OWNED", "You do not own that gear.");
    return;
  }
  if (action.type === "survival_consume") {
    if (player.inventory[action.item] < 1) fail("INSUFFICIENT_SUPPLIES", `You have no ${action.item}.`);
    if (action.item === "medicine") {
      if (player.hp >= 100) fail("FULL_HEALTH", "You are already at full health.");
      const restored = Math.min(45, 100 - player.hp);
      player.hp += restored;
      recordDuty(world, actorId, "healing", restored);
    }
    if (action.item === "food") {
      if (player.hunger >= 100) fail("FULL_HUNGER", "You do not need food yet.");
      player.hunger = Math.min(100, player.hunger + 35);
    }
    if (action.item === "water") {
      if (player.thirst >= 100) fail("FULL_THIRST", "You do not need water yet.");
      player.thirst = Math.min(100, player.thirst + 40);
    }
    player.inventory[action.item]--;
    return;
  }
  try {
    if (applyCommunityAction(world, actorId, action, now, hostId, eligibleIds)) return;
    if (applyProgressionAction(world, actorId, action, now, hostId)) return;
  } catch (error) {
    if (error instanceof Error && "code" in error && typeof error.code === "string") fail(error.code, error.message);
    throw error;
  }
  if (action.type === "survival_interact") {
    const site = world.sites.find((s) => s.id === action.targetId);
    if (site) {
      if (distance3(player, site) > 180) fail("TOO_FAR", "Explore closer to discover this shelter.");
      site.discovered = true;
      event3(world, `${SHELTERS[site.type].name} discovered. The host may move the whole community here.`, "discovery");
      return;
    }
    loot(world, player, action.targetId);
    return;
  }
  fail("BAD_ACTION", "This survival action is not available.");
}
function cpuControls(world, player, now) {
  if (player.hp <= 0) {
    if (world.elapsedMs >= player.downUntil) {
      player.x = world.shelter.x;
      player.y = world.shelter.y;
      player.hp = 75;
      player.downUntil = 0;
    }
    return;
  }
  const nearestEnemy = world.enemies.filter((e) => distance3(player, e) < 490).sort((a, b) => distance3(player, a) - distance3(player, b))[0];
  let target;
  let fighting = false;
  if (nearestEnemy && distance3(player, nearestEnemy) < WEAPONS[player.equippedWeapon].range) {
    player.aim = Math.atan2(nearestEnemy.y - player.y, nearestEnemy.x - player.x);
    fighting = true;
    if (distance3(player, nearestEnemy) < 95 && distance3(player, world.shelter) > SAFE_RADIUS) {
      target = { x: player.x + (player.x - nearestEnemy.x) * 3, y: player.y + (player.y - nearestEnemy.y) * 3 };
    }
  } else {
    const rescue = player.inventory.food >= 2 && player.inventory.medicine >= 1 && world.survivors.length < world.shelter.capacity ? world.rescues.filter((site) => !site.rescued && distance3(player, site) < 430).sort((a, b) => distance3(player, a) - distance3(player, b))[0] : void 0;
    const supplies = world.containers.filter((c) => !c.opened).sort((a, b) => distance3(player, a) - distance3(player, b));
    const container = supplies[hash2(player.id) % Math.min(3, supplies.length)];
    if (rescue) {
      target = rescue;
      if (distance3(player, rescue) <= 85) {
        try {
          applyProgressionAction(world, player.id, { type: "survival_interact", targetId: rescue.id }, now, "");
        } catch (error) {
          if (!(error instanceof SurvivalProgressionError)) throw error;
        }
      }
    } else if (container) {
      target = container;
      if (distance3(player, container) <= 85) {
        try {
          loot(world, player, container.id);
        } catch (error) {
          if (!(error instanceof SurvivalError)) throw error;
        }
      }
    } else target = world.shelter;
    if (nearestEnemy) player.aim = Math.atan2(nearestEnemy.y - player.y, nearestEnemy.x - player.x);
  }
  if (world.wave.active || world.shelter.hp < world.shelter.maxHp * 0.75 || player.hp < 40) {
    const guardAngle = hash2(player.id) % 6283 / 1e3;
    target = { x: world.shelter.x + Math.cos(guardAngle) * 65, y: world.shelter.y + Math.sin(guardAngle) * 65 };
  }
  if (player.hp < 55 && player.inventory.medicine) {
    player.inventory.medicine--;
    player.hp = Math.min(100, player.hp + 45);
  }
  if (player.hunger < 60 && player.inventory.food) {
    player.inventory.food--;
    player.hunger = Math.min(100, player.hunger + 35);
  }
  if (player.thirst < 60 && player.inventory.water) {
    player.inventory.water--;
    player.thirst = Math.min(100, player.thirst + 40);
  }
  const owned = player.weapons.find((w) => w.id === player.equippedWeapon);
  if (owned.magazine === 0) beginReload(world, player);
  const length = target ? Math.hypot(target.x - player.x, target.y - player.y) : 0;
  player.input = { moveX: target && length > 15 ? (target.x - player.x) / length : 0, moveY: target && length > 15 ? (target.y - player.y) / length : 0, aim: player.aim, fire: fighting, receivedAt: now };
}
function stepPlayer(world, player, deltaMs, now) {
  if (player.hp <= 0) return;
  if (now - player.input.receivedAt > 450) {
    player.input.moveX = player.input.moveY = 0;
    player.input.fire = false;
  }
  const boots = player.gear.find((g) => g.id === "boots")?.level ?? 0;
  const speed = 155 * (1 + boots * 0.06) * (player.stamina < 15 ? 0.75 : 1);
  player.x = clamp(player.x + player.input.moveX * speed * deltaMs / 1e3, 22, world.width - 22);
  player.y = clamp(player.y + player.input.moveY * speed * deltaMs / 1e3, 22, world.height - 22);
  player.aim = player.input.aim;
  const dayFraction = deltaMs / world.dayLengthMs;
  player.hunger = Math.max(0, player.hunger - dayFraction * 55);
  player.thirst = Math.max(0, player.thirst - dayFraction * 75);
  player.stamina = clamp(player.stamina + (Math.abs(player.input.moveX) + Math.abs(player.input.moveY) > 0 ? -3 : 8) * deltaMs / 1e3, 0, 100);
  if (player.hunger === 0 || player.thirst === 0) {
    player.hp = Math.max(0, player.hp - deltaMs / 1e3 * 0.8);
    if (!player.hp) down(world, player);
  }
  if (player.reloadUntil > 0 && player.reloadUntil <= world.elapsedMs) {
    const owned = player.weapons.find((w) => w.id === player.equippedWeapon);
    const amount = Math.min(WEAPONS[owned.id].magazine - owned.magazine, player.inventory.ammo);
    owned.magazine += amount;
    player.inventory.ammo -= amount;
    player.reloadUntil = 0;
  }
  if (player.input.fire) fire(world, player);
}
function stepEnemy(world, enemy, players, deltaMs) {
  const candidates = players.filter((p) => p.hp > 0 && distance3(p, world.shelter) > SAFE_RADIUS);
  const target = candidates.sort((a, b) => distance3(enemy, a) - distance3(enemy, b))[0];
  const attackingPlayer = target && distance3(enemy, target) < 550;
  const destination = attackingPlayer ? target : world.shelter;
  const d = distance3(enemy, destination);
  const reach = attackingPlayer ? 28 : 124;
  if (d > reach) {
    const speed = enemy.kind === "brute" ? 47 : enemy.horde ? 74 : 55;
    const amount = Math.min(d - reach, speed * deltaMs / 1e3);
    enemy.x += (destination.x - enemy.x) / d * amount;
    enemy.y += (destination.y - enemy.y) / d * amount;
  }
  if (distance3(enemy, destination) <= reach + 1 && world.elapsedMs >= enemy.attackAt) {
    enemy.attackAt = world.elapsedMs + (enemy.kind === "brute" ? 1400 : 1050);
    if (attackingPlayer) {
      const armor = target.gear.find((g) => g.id === "armor")?.level ?? 0;
      target.hp = Math.max(0, target.hp - Math.max(3, (enemy.kind === "brute" ? 20 : 10) - armor * 3));
      target.lastDamageAt = world.elapsedMs;
      if (target.hp === 0) down(world, target);
    } else {
      world.shelter.hp = Math.max(0, world.shelter.hp - Math.max(2, (enemy.kind === "brute" ? 34 : 15) - world.shelter.defense * 0.35));
    }
  }
}
function stepGuardians(world) {
  for (const survivor of world.survivors) {
    if (survivor.role !== "guardian" || survivor.hp <= 0 || survivor.nextActionAt > world.elapsedMs) continue;
    survivor.x = world.shelter.x + 85;
    survivor.y = world.shelter.y - 18;
    const target = world.enemies.filter((e) => distance3(e, survivor) < 340).sort((a, b) => distance3(a, survivor) - distance3(b, survivor))[0];
    if (target) {
      target.hp -= 22 + survivor.level * 8;
      survivor.nextActionAt = world.elapsedMs + 800;
      if (target.hp <= 0) killEnemy(world, target);
    }
  }
}
function tickSurvivalWorld(world, now, activeIds2, cpuIds, eligibleIds = new Set(Object.keys(world.players))) {
  const wallDelta = Math.max(0, now - world.lastTickAt);
  world.lastTickAt = now;
  const communityChanged = tickCommunity(world, eligibleIds, cpuIds);
  const humanConnected = [...activeIds2].some((id) => world.players[id] && !cpuIds.has(id));
  if (!world.active || world.paused || !humanConnected || wallDelta <= 0) {
    if (!humanConnected || world.paused) for (const player of Object.values(world.players)) {
      player.input.fire = false;
      player.input.moveX = player.input.moveY = 0;
    }
    return communityChanged;
  }
  const deltaMs = Math.min(200, wallDelta);
  world.elapsedMs += deltaMs;
  world.tickNumber++;
  const players = Object.values(world.players).filter((p) => activeIds2.has(p.id) || cpuIds.has(p.id));
  for (const player of Object.values(world.players)) if (!activeIds2.has(player.id) && !cpuIds.has(player.id)) {
    player.input.fire = false;
    player.input.moveX = player.input.moveY = 0;
  }
  for (const player of players) {
    if (cpuIds.has(player.id)) cpuControls(world, player, now);
    stepPlayer(world, player, deltaMs, now);
  }
  if (!world.wave.active && world.elapsedMs >= world.wave.nextAt) {
    world.wave.active = true;
    world.wave.number++;
    world.wave.remainingSpawns = Math.min(36, 7 + world.wave.number * 3 + players.length * 2);
    world.wave.nextSpawnAt = world.elapsedMs;
    event3(world, `${calendar(world).night ? "Night horde" : "Horde"} ${world.wave.number} incoming. Defend the shelter.`, "horde-start");
  }
  if (world.wave.active && world.wave.remainingSpawns > 0 && world.elapsedMs >= world.wave.nextSpawnAt && world.enemies.length < MAX_ENEMIES) {
    spawnEnemy(world, true);
    world.wave.remainingSpawns--;
    world.wave.nextSpawnAt = world.elapsedMs + 850;
  }
  if (world.elapsedMs >= world.nextRoamerAt && world.enemies.length < 16) {
    const groupSize = 2 + hash2(`${world.id}:${world.tickNumber}`) % 2;
    for (let i = 0; i < groupSize; i++) spawnEnemy(world, false);
    world.nextRoamerAt = world.elapsedMs + 16e3;
  }
  for (const enemy of [...world.enemies]) stepEnemy(world, enemy, players, deltaMs);
  stepGuardians(world);
  if (world.wave.active && world.wave.remainingSpawns === 0 && !world.enemies.some((e) => e.horde)) {
    world.wave.active = false;
    world.wave.completed++;
    const firstNight = world.dayLengthMs / 2;
    world.wave.nextAt = world.elapsedMs < firstNight ? firstNight : firstNight + (Math.floor((world.elapsedMs - firstNight) / world.dayLengthMs) + 1) * world.dayLengthMs;
    const ids = players.map((p) => p.id);
    if (ids[0]) {
      recordProgress(world, ids[0], "waves");
      for (const id of ids.slice(1)) world.players[id].stats.waves++;
    }
    event3(world, `Horde ${world.wave.number} defeated. Repair, restock, and explore before the next night.`, "horde-complete");
  }
  tickCommunity(world, eligibleIds, cpuIds);
  tickProgression(world, deltaMs, new Set(players.map((player) => player.id)));
  const today = calendar(world).day;
  let cachesRefilled = 0;
  for (const container of world.containers) if (container.opened && !container.id.startsWith("drop-") && (today >= container.respawnDay || container.respawnAt !== void 0 && world.elapsedMs >= container.respawnAt)) {
    const seed = hash2(container.id);
    container.contents = seed % 3 === 0 ? { metal: 5, cloth: 3, ammo: 24, medicine: 1 } : seed % 3 === 1 ? { wood: 7, metal: 3, electronics: 2, food: 2 } : { food: 3, water: 4, cloth: 4, ammo: 18 };
    container.opened = false;
    container.respawnDay = today + 2;
    delete container.respawnAt;
    cachesRefilled++;
  }
  world.containers = world.containers.filter((container) => !container.id.startsWith("drop-") || !container.opened);
  if (cachesRefilled) event3(world, `${cachesRefilled} supply caches are ready to scavenge again.`, "supplies-refreshed");
  if (world.shelter.hp <= 0) {
    world.active = false;
    event3(world, "The shelter has fallen. This expedition has ended. Your community can start a new journey.", "survival-ended");
  }
  return true;
}
function projectSurvivalWorld(world) {
  const { day, hour, week, month, night } = calendar(world);
  return structuredClone({
    id: world.id,
    active: world.active,
    paused: world.paused,
    elapsedMs: world.elapsedMs,
    dayLengthMs: world.dayLengthMs,
    day,
    hour,
    week,
    month,
    night,
    width: world.width,
    height: world.height,
    community: projectCommunity(world),
    players: Object.values(world.players).map((p) => ({ id: p.id, x: p.x, y: p.y, aim: p.aim, hp: p.hp, downed: p.hp <= 0, weapon: p.equippedWeapon, weaponLevel: p.weapons.find((w) => w.id === p.equippedWeapon).level, firing: p.hp > 0 && p.input.fire && p.nextShotAt > world.elapsedMs })),
    shelter: world.shelter,
    sites: world.sites,
    containers: world.containers.map(({ id, x, y, label, opened }) => ({ id, x, y, label, opened })),
    enemies: world.enemies.map(({ id, x, y, hp, maxHp, kind, horde }) => ({ id, x, y, hp, maxHp, kind, horde })),
    rescues: world.rescues,
    survivors: world.survivors.map(({ id, name, role, level, x, y, hp }) => ({ id, name, role, level, x, y, hp })),
    facilities: world.facilities,
    jobs: world.jobs,
    goals: world.goals,
    events: world.events,
    wave: { active: world.wave.active, number: world.wave.number, completed: world.wave.completed, nextAt: world.wave.nextAt, remainingSpawns: world.wave.remainingSpawns }
  });
}
function projectSurvivalPlayer(world, id) {
  const p = world.players[id];
  if (!p) return null;
  return structuredClone({ electionVotes: projectElectionVotes(world, id), hp: p.hp, hunger: p.hunger, thirst: p.thirst, stamina: p.stamina, inventory: p.inventory, weapons: p.weapons, gear: p.gear, equippedWeapon: p.equippedWeapon, stats: p.stats, reloadRemainingMs: Math.max(0, p.reloadUntil - world.elapsedMs), respawnRemainingMs: p.hp <= 0 ? Math.max(0, p.downUntil - world.elapsedMs) : 0 });
}

// src/server/engine.ts
var EngineError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "EngineError";
  }
};
var PHASE_DURATION = { crisis: 8e3, directive: 15e3, discussion: 45e3, decision: 3e4, reveal: 12e3, vote: 3e4, consequences: 8e3, dossier: 15e3, extension_offer: 2e4, extension_vote: 3e4, final_directive: 15e3, final_choice: 3e4, final_resolution: 8e3, personal_results: 15e3 };
var CRISES = [
  { title: "Containment Breach", description: "The medical wing is losing pressure. Reinforce Medical and Security before the breach spreads." },
  { title: "Blackout Protocol", description: "Emergency power is scarce. Medical support and secure infrastructure each need the group\u2019s resources." },
  { title: "Quarantine Threshold", description: "Protect the patients and secure the perimeter. Resources held in Reserve cannot prevent this crisis." },
  { title: "Oxygen Debt", description: "Medical ventilation and Security containment compete for the remaining emergency supplies." },
  { title: "Signal Failure", description: "Restore Medical monitoring and Security relays. Both systems must reach the required threshold." },
  { title: "Pressure Test", description: "Medical and Security systems are close to failure. The Experiment is watching what you keep back." }
];
var DIRECTIVES = [
  { kind: "medical2", title: "Medical Priority", instruction: "Allocate at least 2 units to Medical.", reward: 2 },
  { kind: "security2", title: "Containment Order", instruction: "Allocate at least 2 units to Security.", reward: 2 },
  { kind: "reserve2", title: "Personal Reserve", instruction: "Keep at least 2 units in Reserve.", reward: 3 },
  { kind: "medical0", title: "Withhold Treatment", instruction: "Allocate no units to Medical.", reward: 3 },
  { kind: "security0", title: "Open Perimeter", instruction: "Allocate no units to Security.", reward: 3 },
  { kind: "reserve3", title: "Total Retention", instruction: "Keep all 3 units in Reserve.", reward: 3 },
  { kind: "balanced", title: "Equal Distribution", instruction: "Allocate exactly 1 unit to each system.", reward: 2 },
  { kind: "both", title: "Group Benchmark", instruction: "Submit an allocation and have both Medical and Security reach their thresholds.", reward: 2 }
];
function fail2(code, message) {
  throw new EngineError(code, message);
}
function isCpuMember(m) {
  return m.controller === "cpu";
}
function member(room, id) {
  return room.members.find((m) => m.id === id && !m.removed) ?? fail2("NOT_MEMBER", "This membership is unavailable.");
}
function host(room, id) {
  if (room.hostId !== id) fail2("HOST_ONLY", "Only the current host can do that.");
}
function game(room) {
  return room.game ?? fail2("NO_GAME", "There is no current Experiment.");
}
function subject(room, id) {
  const s = game(room).subjects[id];
  if (!s || s.withdrawn) fail2("SUBJECT_ONLY", "Only an active Subject can do that.");
  return s;
}
function activeIds(g) {
  return Object.values(g.subjects).filter((s) => !s.withdrawn).map((s) => s.id);
}
function publish(room, kind, text, now, data) {
  const event4 = { id: randomUUID4(), round: room.game?.round ?? 0, kind, text, at: now, ...data ? { data } : {} };
  room.events.push({ ...event4, visibility: "public" });
  room.game?.publicEvents.push(event4);
}
function dossier(room, s, kind, text, now, data) {
  const entry = { id: randomUUID4(), round: game(room).round, kind, text, at: now, ...data ? { data } : {} };
  s.dossier.push(entry);
  room.events.push({ ...entry, visibility: "private", ownerId: s.id });
}
function phase(room, type, now, eligibleIds = activeIds(game(room))) {
  const g = game(room);
  const duration = type === "final_interrogation" ? 2e4 : PHASE_DURATION[type];
  g.phase = { id: randomUUID4(), type, openedAt: now, deadline: duration == null ? null : now + duration, eligibleIds: [...eligibleIds], remainingMs: null, speakerId: type === "final_interrogation" ? eligibleIds[0] ?? null : null };
  if (g.paused) {
    g.phase.remainingMs = duration ?? null;
    g.phase.deadline = null;
  }
}
function validSettings(settings) {
  const s = settings;
  if (!Number.isInteger(s.rounds) || s.rounds < 3 || s.rounds > 20 || ![15, 20].includes(s.roundCap) || s.rounds > s.roundCap) fail2("BAD_SETTINGS", "Choose 3\u201320 rounds within a cap of 15 or 20.");
}
function createRoom(code, initial, settings, now) {
  validSettings(settings);
  return { id: randomUUID4(), code, hostId: initial.id, settings: structuredClone(settings), status: "lobby", members: [{ ...initial, joinedAt: now, role: "subject", ready: false, removed: false, controller: "human" }], game: null, pastGames: [], chat: [], events: [], chatMuted: false };
}
function addMember(room, joining, now) {
  if (room.status === "closed") fail2("ROOM_CLOSED", "This room is closed.");
  const previous = room.members.find((m) => m.sessionId === joining.sessionId);
  if (previous && !previous.removed) return previous.id;
  if (previous?.removed) fail2("REMOVED", "This session has been removed from the room.");
  const availableCpu = room.members.find((m) => !m.removed && m.role === "subject" && isCpuMember(m) && (room.status === "lobby" || room.status === "running" && (room.survival?.active && room.survival.players[m.id] || room.game && !room.game.outcome && room.game.subjects[m.id] && !room.game.subjects[m.id].withdrawn)));
  if (availableCpu) {
    const previousNickname = availableCpu.nickname;
    availableCpu.controller = "human";
    availableCpu.sessionId = joining.sessionId;
    availableCpu.nickname = joining.nickname;
    availableCpu.ready = false;
    availableCpu.joinedAt = now;
    const survivalPlayer = room.survival?.players[availableCpu.id];
    if (survivalPlayer) survivalPlayer.input = { moveX: 0, moveY: 0, aim: survivalPlayer.aim, fire: false, receivedAt: now };
    publish(room, "cpu_takeover", room.survival ? `${joining.nickname} replaced ${previousNickname}. Position, equipment, supplies and progress are retained.` : `${joining.nickname} replaced ${previousNickname}. The same Subject, score and dossier are retained. Any already locked actions remain in force.`, now, { playerId: availableCpu.id, previousNickname, nickname: joining.nickname });
    const inheritedSubject = room.game?.subjects[availableCpu.id];
    if (inheritedSubject) dossier(room, inheritedSubject, "cpu_seat_inherited", `You now control ${previousNickname}'s Subject. You inherit its private directive, score and dossier. Already locked choices remain locked; this handover does not change game mechanics.`, now);
    return availableCpu.id;
  }
  const settings = room.settings;
  const count = room.members.filter((m) => !m.removed && m.role === "subject").length;
  const isSpectator = count >= 8 || room.status !== "lobby" && !(room.status === "running" && room.survival?.active);
  if (isSpectator && !settings.allowSpectators) fail2("SPECTATORS_DISABLED", "Spectator admission is disabled.");
  room.members.push({ ...joining, joinedAt: now, role: isSpectator ? "spectator" : "subject", ready: false, removed: false, controller: "human" });
  if (!isSpectator && room.survival) addSurvivalPlayer(room.survival, joining.id, now);
  publish(room, "joined", `${joining.nickname} joined as ${isSpectator ? "a spectator" : "a Subject"}.`, now);
  return joining.id;
}
function addCpuMember(room, now) {
  const count = room.members.filter((m) => !m.removed && m.role === "subject").length;
  if (count >= 8) fail2("ROOM_FULL", "At most 8 Subjects can participate.");
  let number = 1;
  while (room.members.some((m) => !m.removed && m.nickname === `CPU ${number.toString().padStart(2, "0")}`)) number++;
  const cpu = { id: randomUUID4(), sessionId: `cpu:${randomUUID4()}`, nickname: `CPU ${number.toString().padStart(2, "0")}`, joinedAt: now, role: "subject", ready: true, removed: false, controller: "cpu" };
  room.members.push(cpu);
  publish(room, "cpu_added", `${cpu.nickname} joined as a CPU Subject. A joining player can take over this seat.`, now, { playerId: cpu.id });
  return cpu;
}
function shuffle(items) {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function ballotFor(round, planned) {
  if (round === planned - 1) return "trust";
  if (planned === 3) return "exposure";
  if (planned === 5) return ["exposure", "restriction", "exposure", "trust"][round - 1];
  if (planned === 7) return ["exposure", "restriction", "trust", "restriction", "exposure", "trust"][round - 1];
  return ["exposure", "restriction", "trust"][(round - 1) % 3];
}
function startTrial(room, now) {
  const g = game(room);
  const ids = activeIds(g);
  const content = CRISES[(g.round - 1) % CRISES.length];
  g.trial = { id: randomUUID4(), ...content, threshold: ids.length, voteType: ballotFor(g.round, g.plannedTotalRounds), totals: null, delta: null, met: null, votes: {}, voteWinner: null, voteTied: false, voteResolved: false, exposure: null };
  g.extension = null;
  for (const id of ids) {
    const s = g.subjects[id];
    s.medicalMinimum = s.pendingRestriction ? 1 : 0;
    s.pendingRestriction = false;
    s.directive = null;
    s.allocation = null;
    s.ballot = void 0;
  }
  phase(room, "crisis", now, ids);
  publish(room, "crisis", `Trial ${g.round}: ${content.title}`, now, { threshold: ids.length, voteType: g.trial.voteType });
}
function begin(room, now) {
  if (room.status !== "lobby") fail2("BAD_STATE", "Return to the lobby before starting an Experiment.");
  validSettings(room.settings);
  const players = room.members.filter((m) => !m.removed && m.role === "subject");
  const humans = players.filter((m) => !isCpuMember(m));
  if (!humans.length || players.length > 8) fail2("PLAYER_COUNT", "An Experiment requires at least one human Subject, with 4\u20138 total Subjects including CPUs.");
  if (humans.some((m) => !m.ready)) fail2("NOT_READY", "Every human Subject must be ready.");
  while (players.length < 4) players.push(addCpuMember(room, now));
  players.forEach((m) => {
    if (isCpuMember(m)) m.ready = true;
  });
  const settings = room.settings;
  const subjects = {};
  players.forEach((m, i) => {
    subjects[m.id] = { id: m.id, number: i + 1, compliance: 0, requirement: Math.ceil(settings.rounds * 1.5), completedDirectives: 0, trustVotes: 0, withdrawn: false, pendingRestriction: false, medicalMinimum: 0, directive: null, allocation: null, ballot: void 0, finalChoice: null, dossier: [], history: [], statement: null };
  });
  room.game = { id: randomUUID4(), initialRoundCount: settings.rounds, plannedTotalRounds: settings.rounds, maxRounds: settings.roundCap, extensionsEnabled: settings.extensions, round: 1, startingSubjectCount: players.length, stabilityTicks: 60 * players.length, phase: { id: "", type: "crisis", openedAt: now, deadline: null, eligibleIds: [], remainingMs: null, speakerId: null }, paused: false, pauseReason: null, subjects, trial: null, extension: null, extensionHistory: [], outcome: null, results: [], finalCounts: null, publicEvents: [] };
  room.status = "running";
  publish(room, "started", "THE EXPERIMENT has begun. There is no designated villain.", now);
  startTrial(room, now);
}
function assignDirectives(room, now) {
  const g = game(room);
  const bundle = shuffle(DIRECTIVES);
  for (const [index, id] of shuffle(activeIds(g)).entries()) {
    const s = g.subjects[id];
    let d = bundle[index % bundle.length];
    if (s.medicalMinimum > 0 && (d.kind === "medical0" || d.kind === "reserve3")) d = DIRECTIVES.find((x) => x.kind === "security0");
    s.directive = { ...d, id: randomUUID4() };
    dossier(room, s, "directive", d.instruction, now, { directive: s.directive });
  }
  phase(room, "directive", now, g.phase.eligibleIds);
}
function completes(d, a, met) {
  switch (d.kind) {
    case "medical2":
      return a.medical >= 2;
    case "security2":
      return a.security >= 2;
    case "reserve2":
      return a.reserve >= 2;
    case "medical0":
      return a.medical === 0;
    case "security0":
      return a.security === 0;
    case "reserve3":
      return a.reserve === 3;
    case "balanced":
      return a.medical === 1 && a.security === 1 && a.reserve === 1;
    case "both":
      return met.medical && met.security;
    default:
      return false;
  }
}
function finishResource(room, now) {
  const g = game(room), t = g.trial;
  const totals = { medical: 0, security: 0, reserve: 0 };
  for (const id of g.phase.eligibleIds) {
    const a = g.subjects[id].allocation;
    if (a) {
      totals.medical += a.medical;
      totals.security += a.security;
      totals.reserve += a.reserve;
    }
  }
  const met = { medical: totals.medical >= t.threshold, security: totals.security >= t.threshold };
  const delta = (met.medical ? 10 : -15) + (met.security ? 10 : -15);
  t.totals = totals;
  t.met = met;
  t.delta = delta;
  const beforeStability = g.stabilityTicks / g.startingSubjectCount;
  g.stabilityTicks = Math.max(0, Math.min(100 * g.startingSubjectCount, g.stabilityTicks + delta * g.startingSubjectCount));
  for (const id of g.phase.eligibleIds) {
    const s = g.subjects[id];
    const completed = s.allocation != null && s.directive != null && completes(s.directive, s.allocation, met);
    if (completed) {
      s.compliance += s.directive.reward;
      s.completedDirectives++;
    }
    if (s.directive) s.history.push({ round: g.round, directive: structuredClone(s.directive), allocation: s.allocation ? { ...s.allocation } : null, completed, complianceAfter: s.compliance, medicalMinimum: s.medicalMinimum });
    const responseText = s.allocation ? `Your allocation: Medical ${s.allocation.medical}, Security ${s.allocation.security}, Reserve ${s.allocation.reserve}. ${completed ? `Directive complete: +${s.directive.reward} Compliance.` : "Directive incomplete: no Compliance earned."}` : "No response: zero resources contributed, no Compliance earned.";
    dossier(room, s, "resolution", `${responseText} Group Stability: ${beforeStability} \u2192 ${g.stabilityTicks / g.startingSubjectCount} (crisis rule ${delta >= 0 ? "+" : ""}${delta}, maximum 100).`, now, { allocation: s.allocation, completed, compliance: s.compliance, stabilityDelta: delta, complianceDelta: completed ? s.directive.reward : 0 });
  }
  publish(room, "resource_resolution", `Medical ${totals.medical}/${t.threshold}; Security ${totals.security}/${t.threshold}. Stability ${delta >= 0 ? "+" : ""}${delta}.`, now, { totals, met, delta });
  if (g.stabilityTicks <= 0) {
    finishGame(room, "failed", now);
    return;
  }
  phase(room, "reveal", now);
}
function finishVote(room, now) {
  const g = game(room), t = g.trial;
  for (const voter of g.phase.eligibleIds) if (!Object.hasOwn(t.votes, voter)) t.votes[voter] = null;
  const counts = {};
  for (const target of Object.values(t.votes)) if (target) counts[target] = (counts[target] ?? 0) + 1;
  const best = Math.max(0, ...Object.values(counts));
  const leaders = Object.keys(counts).filter((id) => counts[id] === best);
  const winner = leaders.length === 1 ? leaders[0] : null;
  t.voteWinner = winner;
  t.voteTied = leaders.length > 1;
  t.voteResolved = true;
  if (t.voteType === "trust") for (const [id, count] of Object.entries(counts)) g.subjects[id].trustVotes += count;
  if (winner && !g.subjects[winner].withdrawn) {
    const s = g.subjects[winner];
    if (t.voteType === "trust") {
      s.compliance++;
      dossier(room, s, "trust", "Trust vote awarded +1 Compliance.", now, { compliance: s.compliance, complianceDelta: 1 });
    }
    if (t.voteType === "restriction") {
      s.pendingRestriction = true;
      dossier(room, s, "restriction", "Next ordinary Trial: allocate at least 1 unit to Medical.", now);
    }
  }
  if (winner && t.voteType === "exposure" && g.subjects[winner].directive) t.exposure = { playerId: winner, directive: structuredClone(g.subjects[winner].directive) };
  const outcomeText = winner ? `${t.voteType.toUpperCase()} selected Subject ${g.subjects[winner].number.toString().padStart(2, "0")}${g.subjects[winner].withdrawn ? " (removed; no future reward or restriction)" : ""}.` : "The ballot has no unique winner. No mechanical effect.";
  const ballotText = Object.entries(t.votes).map(([voter, target]) => `Subject ${g.subjects[voter].number.toString().padStart(2, "0")} \u2192 ${target ? `Subject ${g.subjects[target].number.toString().padStart(2, "0")}` : "abstain"}`).join("; ");
  const countsText = Object.entries(counts).map(([id, count]) => `Subject ${g.subjects[id].number.toString().padStart(2, "0")}: ${count}`).join("; ");
  const exposureText = t.exposure ? ` Exposed directive: ${t.exposure.directive.instruction} (${t.exposure.directive.reward} Compliance).` : "";
  publish(room, "vote_resolution", `${outcomeText}${exposureText} Ballots: ${ballotText}. Totals: ${countsText || "no target received votes"}.`, now, { voteType: t.voteType, votes: { ...t.votes }, counts, winner, tied: t.voteTied, ...t.exposure ? { exposure: t.exposure } : {} });
  phase(room, "consequences", now);
}
function beginFinale(room, now) {
  const g = game(room);
  g.round = g.plannedTotalRounds;
  g.trial = null;
  g.extension = null;
  for (const s of Object.values(g.subjects)) {
    s.directive = null;
    s.finalChoice = null;
    s.statement = null;
    s.allocation = null;
    s.ballot = void 0;
    s.medicalMinimum = 0;
  }
  phase(room, "final_interrogation", now);
  publish(room, "finale", "Final Interrogation. Make your final statement before the private Final Directive.", now);
}
function assignFinalDirectives(room, now) {
  const g = game(room), shuffled = shuffle(activeIds(g));
  for (const [i, id] of shuffled.entries()) {
    const s = g.subjects[id], kind = i % 2 === 0 ? "group" : "self";
    s.directive = { id: randomUUID4(), kind, title: kind === "group" ? "Final Loyalty" : "Final Self-Preservation", instruction: kind === "group" ? "Choose Protect the Group." : "Choose Protect Yourself.", reward: 3 };
    dossier(room, s, "final_directive", s.directive.instruction, now, { directive: s.directive });
  }
  phase(room, "final_directive", now);
}
function advanceInterrogation(room, now) {
  const g = game(room), old = g.phase;
  const index = old.eligibleIds.indexOf(old.speakerId ?? "");
  const next = old.eligibleIds.slice(index + 1).find((id) => !g.subjects[id].withdrawn);
  if (!next) {
    assignFinalDirectives(room, now);
    return;
  }
  phase(room, "final_interrogation", now, old.eligibleIds);
  g.phase.speakerId = next;
}
function finishFinalChoices(room, now) {
  const g = game(room);
  const protectors = Object.values(g.subjects).filter((s) => s.finalChoice === "group").length;
  const selfProtectors = Object.values(g.subjects).filter((s) => s.finalChoice === "self").length;
  const deltaTicks = 40 * protectors - 120 * selfProtectors;
  const beforeStability = g.stabilityTicks / g.startingSubjectCount;
  const afterTicks = Math.max(0, Math.min(g.startingSubjectCount * 100, g.stabilityTicks + deltaTicks));
  for (const s of Object.values(g.subjects)) {
    if (!s.finalChoice) continue;
    const completed = s.directive?.kind === s.finalChoice;
    if (completed) {
      s.compliance += 3;
      s.completedDirectives++;
    }
    if (s.directive) s.history.push({ round: g.round, directive: structuredClone(s.directive), allocation: null, completed, complianceAfter: s.compliance, medicalMinimum: 0, finalChoice: s.finalChoice });
    dossier(room, s, "final_resolution", `You chose ${s.finalChoice === "group" ? "Protect the Group" : "Protect Yourself"}. ${completed ? "+3 Compliance." : "Final Directive incomplete."} Group Stability: ${beforeStability} \u2192 ${afterTicks / g.startingSubjectCount}.`, now, { finalChoice: s.finalChoice, completed, compliance: s.compliance, complianceDelta: completed ? 3 : 0 });
  }
  g.stabilityTicks = afterTicks;
  g.finalCounts = { group: protectors, self: selfProtectors, delta: deltaTicks / g.startingSubjectCount };
  g.outcome = g.stabilityTicks > 0 ? "survived" : "failed";
  makeResults(g);
  publish(room, "final_resolution", `Protect the Group: ${protectors}. Protect Yourself: ${selfProtectors}. Group ${g.outcome.toUpperCase()}.`, now, { ...g.finalCounts, outcome: g.outcome });
  phase(room, "final_resolution", now);
}
function makeResults(g) {
  const scores = Object.values(g.subjects).map((s) => s.trustVotes);
  g.results = Object.values(g.subjects).map((s) => ({ playerId: s.id, subjectNumber: s.number, compliance: s.compliance, requirement: s.requirement, qualified: g.outcome === "survived" && !s.withdrawn && s.compliance >= s.requirement, completedDirectives: s.completedDirectives, trustVotes: s.trustVotes, trustRank: 1 + scores.filter((n) => n > s.trustVotes).length, classification: s.withdrawn ? "WITHDRAWN" : s.finalChoice === "self" && s.trustVotes > 0 ? "LOYAL OPPORTUNIST" : s.finalChoice === "self" ? "SELF-PRESERVATIONIST" : s.trustVotes > 0 ? "TRUSTED GUARDIAN" : "GROUP PROTECTOR", withdrawn: s.withdrawn }));
}
function finishGame(room, outcome, now) {
  const g = game(room);
  g.outcome = outcome;
  g.paused = false;
  g.pauseReason = null;
  makeResults(g);
  publish(room, outcome, outcome === "aborted" ? "The host ended this Experiment. No winners; unrevealed secrets remain private." : "Group Stability has collapsed. No Subject qualifies.", now);
  if (outcome === "aborted") {
    phase(room, "aborted", now);
    room.status = "postgame";
  } else phase(room, "personal_results", now);
}
function checkpoint(room, now) {
  const g = game(room);
  if (g.extensionsEnabled && g.plannedTotalRounds < g.maxRounds) phase(room, "extension_offer", now);
  else beginFinale(room, now);
}
function finishExtension(room, now) {
  const g = game(room), ext = g.extension;
  const yes = Object.values(ext.ballots).filter(Boolean).length;
  const no = ext.eligibleIds.length - yes;
  const accepted = yes > ext.eligibleIds.length / 2;
  ext.yes = yes;
  ext.no = no;
  ext.accepted = accepted;
  g.extensionHistory.push(structuredClone(ext));
  publish(room, "extension_resolution", `Extra Trials ${accepted ? "approved" : "declined"}: ${yes} yes, ${no} no.`, now, { yes, no, accepted, addedRounds: ext.addedRounds });
  if (accepted) {
    g.plannedTotalRounds = ext.toRounds;
    g.round++;
    startTrial(room, now);
  } else beginFinale(room, now);
}
function advance(room, now) {
  const g = game(room);
  switch (g.phase.type) {
    case "crisis":
      assignDirectives(room, now);
      break;
    case "directive":
      phase(room, "discussion", now, g.phase.eligibleIds);
      break;
    case "discussion":
      phase(room, "decision", now, g.phase.eligibleIds);
      break;
    case "decision":
      finishResource(room, now);
      break;
    case "reveal":
      phase(room, "vote", now);
      break;
    case "vote":
      finishVote(room, now);
      break;
    case "consequences":
      phase(room, "dossier", now);
      break;
    case "dossier":
      if (g.round < g.plannedTotalRounds - 1) {
        g.round++;
        startTrial(room, now);
      } else checkpoint(room, now);
      break;
    case "extension_offer":
      beginFinale(room, now);
      break;
    case "extension_vote":
      finishExtension(room, now);
      break;
    case "final_interrogation":
      advanceInterrogation(room, now);
      break;
    case "final_directive":
      phase(room, "final_choice", now);
      break;
    case "final_choice": {
      if (g.phase.eligibleIds.every((id) => g.subjects[id].finalChoice !== null || g.subjects[id].withdrawn)) finishFinalChoices(room, now);
      else fail2("FINALE_WAITING", "Final choices require every eligible Subject to lock in. Reconnect, pause, remove an absent Subject, or end the Experiment.");
      break;
    }
    case "final_resolution":
      phase(room, "personal_results", now);
      break;
    case "personal_results":
      phase(room, "full_reveal", now);
      room.status = "postgame";
      publish(room, "full_reveal", "The Experiment\u2019s hidden record is now open.", now);
      break;
    case "aborted":
    case "full_reveal":
      fail2("FINISHED", "This Experiment has finished.");
  }
}
function tick(room, now) {
  const g = room.game;
  if (room.status !== "running" || !g || g.paused || g.phase.deadline === null || now < g.phase.deadline || g.phase.type === "final_choice") return false;
  advance(room, now);
  return true;
}
function applyCommand(room, actorId, command, now) {
  const actor3 = member(room, actorId);
  const envelope = { gameId: command.gameId, phaseId: command.phaseId, type: command.action.type };
  const payload = command.action;
  if (envelope.type.startsWith("survival_")) {
    if (envelope.type === "survival_start") {
      host(room, actorId);
      if (room.status !== "lobby" || room.survival) fail2("BAD_STATE", "Return to the lobby before starting a new survival world.");
      if (envelope.gameId !== null || envelope.phaseId !== null) fail2("STALE_WORLD", "This start command belongs to an earlier world.");
      const players = room.members.filter((m) => !m.removed && m.role === "subject");
      const humans = players.filter((m) => !isCpuMember(m));
      if (!humans.length || players.length > 8) fail2("PLAYER_COUNT", "A survival world needs at least one human survivor and supports up to eight players.");
      if (humans.some((m) => !m.ready)) fail2("NOT_READY", "Every human survivor must be ready.");
      const action = command.action;
      room.game = null;
      room.survival = createSurvivalWorld(players.map((m) => m.id), action.shelterType, action.dayLengthMinutes, now);
      room.status = "running";
      publish(room, "survival_started", "The survival world is open. Scavenge, rescue survivors, improve your shelter and defend against the infected.", now);
      return;
    }
    const world = room.survival;
    if (!world || room.status !== "running") fail2("BAD_STATE", "There is no active survival world.");
    if (envelope.gameId !== world.id || envelope.phaseId !== null) fail2("STALE_WORLD", "This action belongs to an earlier survival world. Refresh your room state.");
    if (envelope.type === "survival_pause") host(room, actorId);
    else if (actor3.role !== "subject" || !world.players[actorId]) fail2("SURVIVOR_ONLY", "Only a survivor in this world can do that.");
    try {
      applySurvivalAction(world, actorId, command.action, now, room.hostId, new Set(room.members.filter((m) => !m.removed && m.role === "subject").map((m) => m.id)));
    } catch (error) {
      if (error instanceof SurvivalError) fail2(error.code, error.message);
      throw error;
    }
    return;
  }
  if (room.survival && room.status === "running") {
    if (["transfer_host", "remove", "mute_chat", "pause", "resume", "end"].includes(envelope.type) && (envelope.gameId !== room.survival.id || envelope.phaseId !== null)) fail2("STALE_WORLD", "This host action belongs to an earlier survival world.");
    if (["pause", "resume"].includes(envelope.type)) {
      host(room, actorId);
      try {
        applySurvivalAction(room.survival, actorId, { type: "survival_pause", paused: envelope.type === "pause" }, now, room.hostId);
      } catch (error) {
        if (error instanceof SurvivalError) fail2(error.code, error.message);
        throw error;
      }
      return;
    }
    if (envelope.type === "end") {
      host(room, actorId);
      room.survival.active = false;
      room.status = "postgame";
      publish(room, "survival_ended", "The host ended this survival world. Its final state is retained until a new world is started.", now);
      return;
    }
    if (["start", "decision", "vote", "final_choice", "statement", "extension", "extension_vote", "continue", "advance"].includes(envelope.type)) fail2("SURVIVAL_MODE", "This world uses continuous survival, with rounds only for infected hordes.");
  }
  const g = room.game;
  const gameCommands = ["decision", "vote", "final_choice", "statement", "extension", "extension_vote", "continue", "pause", "resume", "advance", "end"];
  if (gameCommands.includes(envelope.type)) {
    if (!g || room.status !== "running") fail2("BAD_STATE", "There is no active Experiment.");
    if (envelope.gameId !== g.id || envelope.phaseId !== g.phase.id) fail2("STALE_PHASE", "This action belongs to an earlier game or phase. Refresh your room state.");
  }
  if (room.status === "running" && g && ["transfer_host", "remove", "mute_chat"].includes(envelope.type) && (envelope.gameId !== g.id || envelope.phaseId !== g.phase.id)) fail2("STALE_PHASE", "This host action belongs to an earlier game or phase.");
  const actions = ["decision", "vote", "final_choice", "statement", "extension", "extension_vote", "continue", "advance"];
  if (g?.paused && actions.includes(envelope.type)) fail2("PAUSED", "The Experiment is paused.");
  switch (envelope.type) {
    case "ready": {
      if (room.status !== "lobby" || actor3.role !== "subject") fail2("BAD_STATE", "Ready is available to Subjects in the lobby.");
      actor3.ready = Boolean(payload.ready);
      break;
    }
    case "settings": {
      host(room, actorId);
      if (room.status !== "lobby" && room.status !== "postgame") fail2("BAD_STATE", "Settings cannot change during an Experiment.");
      const next = payload.settings;
      validSettings(next);
      room.settings = structuredClone(next);
      room.members.forEach((m) => {
        m.ready = isCpuMember(m);
      });
      break;
    }
    case "add_cpu": {
      host(room, actorId);
      if (room.status !== "lobby") fail2("BAD_STATE", "CPU Subjects can be added in the lobby.");
      addCpuMember(room, now);
      break;
    }
    case "start":
      host(room, actorId);
      begin(room, now);
      break;
    case "rematch": {
      host(room, actorId);
      if (room.status !== "postgame") fail2("BAD_STATE", "Finish the current Experiment before a rematch.");
      if (room.game) (room.pastGames ??= []).push(structuredClone(room.game));
      room.game = null;
      delete room.survival;
      room.status = "lobby";
      room.members.forEach((m) => {
        m.ready = isCpuMember(m);
      });
      publish(room, "rematch", "The room is ready for a fresh Experiment.", now);
      break;
    }
    case "set_role": {
      host(room, actorId);
      if (room.status !== "lobby" && room.status !== "postgame") fail2("BAD_STATE", "Membership roles can change between games.");
      const target = member(room, String(payload.targetId));
      if (payload.role !== "subject" && payload.role !== "spectator") fail2("BAD_ROLE", "Unknown membership role.");
      if (isCpuMember(target) && payload.role === "spectator") fail2("CPU_ROLE", "CPU players remain Subjects. Remove their seat to make space.");
      if (payload.role === "subject" && target.role !== "subject" && room.members.filter((m) => !m.removed && m.role === "subject").length >= 8) fail2("ROOM_FULL", "At most 8 Subjects can participate.");
      target.role = payload.role;
      target.ready = isCpuMember(target);
      break;
    }
    case "chat": {
      if (room.chatMuted && actorId !== room.hostId) fail2("CHAT_MUTED", "The host has muted public chat.");
      const text = String(payload.text ?? "").trim();
      if (!text || text.length > 500) fail2("BAD_CHAT", "Chat messages must contain 1\u2013500 characters.");
      room.chat.push({ id: randomUUID4(), senderId: actorId, nickname: actor3.nickname, text, at: now, type: "chat" });
      if (room.chat.length > 200) room.chat.shift();
      break;
    }
    case "transfer_host": {
      host(room, actorId);
      const target = member(room, String(payload.targetId));
      if (isCpuMember(target)) fail2("CPU_HOST", "Only a human player can host the room.");
      room.hostId = target.id;
      publish(room, "host_transfer", `${target.nickname} is now the host.`, now);
      break;
    }
    case "mute_chat":
      host(room, actorId);
      room.chatMuted = Boolean(payload.muted);
      break;
    case "remove": {
      host(room, actorId);
      const target = member(room, String(payload.targetId));
      if (target.id === actorId) fail2("SELF_REMOVE", "Transfer host before leaving your room.");
      target.removed = true;
      target.ready = false;
      const survivor = room.survival?.players[target.id];
      if (survivor) survivor.input = { moveX: 0, moveY: 0, aim: survivor.aim, fire: false, receivedAt: now };
      if (g?.subjects[target.id] && !g.outcome) g.subjects[target.id].withdrawn = true;
      publish(room, "removed", `${target.nickname} was removed by the host. Committed history is retained.`, now);
      if (room.status === "running" && g && !g.outcome) {
        if (activeIds(g).length < 4) {
          if (!g.paused) pauseGame(g, now);
          g.pauseReason = "Fewer than four Subjects remain. End this Experiment and restart with a full group.";
        } else if (g.phase.type === "final_interrogation" && g.phase.speakerId === target.id) advanceInterrogation(room, now);
        else checkAllLocked(room, now);
      }
      break;
    }
    case "pause":
      host(room, actorId);
      if (g.paused) fail2("ALREADY_PAUSED", "The Experiment is already paused.");
      pauseGame(g, now);
      break;
    case "resume": {
      host(room, actorId);
      if (!g.paused) fail2("NOT_PAUSED", "The Experiment is not paused.");
      if (activeIds(g).length < 4) fail2("PLAYER_COUNT", "Fewer than four Subjects remain. End and restart the Experiment.");
      g.paused = false;
      g.pauseReason = null;
      g.phase.deadline = g.phase.remainingMs === null ? null : now + g.phase.remainingMs;
      g.phase.remainingMs = null;
      break;
    }
    case "advance": {
      host(room, actorId);
      const priorPhase = g.phase.type;
      advance(room, now);
      publish(room, "host_advance", `The host advanced ${priorPhase} using the documented timeout rules.`, now);
      break;
    }
    case "end":
      host(room, actorId);
      finishGame(room, "aborted", now);
      break;
    case "decision": {
      const s = subject(room, actorId);
      if (g.phase.type !== "decision" || !g.phase.eligibleIds.includes(actorId)) fail2("BAD_PHASE", "Resource allocation is unavailable in this phase.");
      if (s.allocation) fail2("ALREADY_LOCKED", "Your decision is already locked.");
      const a = payload.allocation;
      if (!a || ![a.medical, a.security, a.reserve].every((n) => Number.isInteger(n) && n >= 0 && n <= 3) || a.medical + a.security + a.reserve !== 3 || a.medical < s.medicalMinimum) fail2("BAD_ALLOCATION", `Allocate exactly 3 units, including at least ${s.medicalMinimum} Medical.`);
      s.allocation = { medical: a.medical, security: a.security, reserve: a.reserve };
      checkAllLocked(room, now);
      break;
    }
    case "vote": {
      const s = subject(room, actorId);
      if (g.phase.type !== "vote" || !g.phase.eligibleIds.includes(actorId)) fail2("BAD_PHASE", "Voting is unavailable in this phase.");
      if (s.ballot !== void 0) fail2("ALREADY_LOCKED", "Your ballot is already locked.");
      const target = payload.targetId == null ? null : String(payload.targetId);
      if (target === actorId || target && !g.phase.eligibleIds.includes(target)) fail2("BAD_TARGET", "Select another eligible Subject or abstain.");
      s.ballot = target;
      g.trial.votes[actorId] = target;
      checkAllLocked(room, now);
      break;
    }
    case "statement": {
      const s = subject(room, actorId);
      if (g.phase.type !== "final_interrogation") fail2("BAD_PHASE", "Final statements are unavailable in this phase.");
      if (g.phase.speakerId !== actorId) fail2("NOT_YOUR_TURN", "Wait for your 20-second final statement turn.");
      if (s.statement !== null) fail2("ALREADY_LOCKED", "Your final statement is already recorded.");
      const text = String(payload.text ?? "").trim();
      if (!text || text.length > 500) fail2("BAD_STATEMENT", "A final statement must contain 1\u2013500 characters.");
      s.statement = text;
      room.chat.push({ id: randomUUID4(), senderId: actorId, nickname: actor3.nickname, text, at: now, type: "statement" });
      if (room.chat.length > 200) room.chat.shift();
      publish(room, "final_statement", text, now, { playerId: actorId });
      advanceInterrogation(room, now);
      break;
    }
    case "final_choice": {
      const s = subject(room, actorId);
      if (g.phase.type !== "final_choice" || !g.phase.eligibleIds.includes(actorId)) fail2("BAD_PHASE", "Final choices are unavailable in this phase.");
      if (s.finalChoice !== null) fail2("ALREADY_LOCKED", "Your final choice is already locked.");
      if (payload.choice !== "group" && payload.choice !== "self") fail2("BAD_CHOICE", "Choose Protect the Group or Protect Yourself.");
      s.finalChoice = payload.choice;
      checkAllLocked(room, now);
      break;
    }
    case "extension": {
      host(room, actorId);
      if (g.phase.type !== "extension_offer") fail2("BAD_PHASE", "Additional rounds can only be proposed before the finale.");
      const added = Number(payload.additionalRounds);
      if (![1, 2, 3, 5].includes(added) || g.plannedTotalRounds + added > g.maxRounds) fail2("BAD_EXTENSION", "Choose an allowed addition within this game\u2019s cap.");
      const ids = activeIds(g);
      g.extension = { id: randomUUID4(), addedRounds: added, fromRounds: g.plannedTotalRounds, toRounds: g.plannedTotalRounds + added, eligibleIds: [...ids], ballots: {}, yes: null, no: null, accepted: null };
      phase(room, "extension_vote", now, ids);
      publish(room, "extension_proposal", `The host proposes ${added} additional ordinary Trial${added === 1 ? "" : "s"}, for ${g.extension.toRounds} total rounds including the finale.`, now);
      break;
    }
    case "extension_vote": {
      subject(room, actorId);
      if (g.phase.type !== "extension_vote" || !g.extension.eligibleIds.includes(actorId)) fail2("BAD_PHASE", "Continuation voting is unavailable.");
      if (Object.hasOwn(g.extension.ballots, actorId)) fail2("ALREADY_LOCKED", "Your consent ballot is already locked.");
      if (typeof payload.yes !== "boolean") fail2("BAD_BALLOT", "Choose yes or no.");
      g.extension.ballots[actorId] = payload.yes;
      checkAllLocked(room, now);
      break;
    }
    case "continue":
      host(room, actorId);
      if (g.phase.type !== "extension_offer") fail2("BAD_PHASE", "This checkpoint has already closed.");
      beginFinale(room, now);
      break;
    default:
      fail2("UNKNOWN_COMMAND", "Unknown command.");
  }
}
function pauseGame(g, now) {
  g.paused = true;
  g.pauseReason = "Paused by the host.";
  g.phase.remainingMs = g.phase.deadline === null ? null : Math.max(0, g.phase.deadline - now);
  g.phase.deadline = null;
}
function checkAllLocked(room, now) {
  const g = game(room);
  if (g.paused) return;
  const ids = g.phase.eligibleIds;
  if (g.phase.type === "decision" && ids.every((id) => g.subjects[id].allocation !== null || g.subjects[id].withdrawn)) finishResource(room, now);
  else if (g.phase.type === "vote" && ids.every((id) => g.subjects[id].ballot !== void 0 || g.subjects[id].withdrawn)) finishVote(room, now);
  else if (g.phase.type === "extension_vote" && g.extension.eligibleIds.every((id) => Object.hasOwn(g.extension.ballots, id) || g.subjects[id].withdrawn)) finishExtension(room, now);
  else if (g.phase.type === "final_choice" && ids.every((id) => g.subjects[id].finalChoice !== null || g.subjects[id].withdrawn)) finishFinalChoices(room, now);
}
function resultView(room, result) {
  return { memberId: result.playerId, nickname: room.members.find((m) => m.id === result.playerId)?.nickname ?? "Removed Subject", subjectNumber: result.subjectNumber, compliance: result.compliance, requirement: result.requirement, qualified: result.qualified, directivesCompleted: result.completedDirectives, trustVotes: result.trustVotes, trustRank: result.trustRank, classification: result.classification, removed: result.withdrawn };
}
function directiveView(d) {
  return d ? { id: d.id, text: d.instruction, reward: d.reward } : null;
}
function titleOf(kind) {
  return kind === "cpu_seat_inherited" ? "CPU seat inherited" : kind.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
function projectRoom(room, viewerId, onlineIds = /* @__PURE__ */ new Set()) {
  member(room, viewerId);
  if (room.status === "closed") fail2("ROOM_CLOSED", "This room is closed.");
  const g = room.game;
  const self = g?.subjects[viewerId];
  const showFull = g?.phase.type === "full_reveal" && g.outcome !== "aborted";
  const showPersonal = g && ["personal_results", "full_reveal", "aborted"].includes(g.phase.type);
  const ownResult = showPersonal ? g.results.find((r) => r.playerId === viewerId) ?? null : null;
  const fullReveal = [];
  if (g && showFull) {
    for (const s of Object.values(g.subjects)) {
      for (const h of s.history) {
        const choice = h.finalChoice ? h.finalChoice === "group" ? "Protect the Group" : "Protect Yourself" : h.allocation ? `Medical ${h.allocation.medical}, Security ${h.allocation.security}, Reserve ${h.allocation.reserve}` : "No response";
        fullReveal.push({ id: `${s.id}:${h.round}`, round: h.round, memberId: s.id, title: `Subject ${s.number.toString().padStart(2, "0")} \u2014 ${h.directive.title}`, detail: `Directive: ${h.directive.instruction} (${h.directive.reward} Compliance). Decision: ${choice}. ${h.completed ? "Completed" : "Not completed"}. Compliance after decision: ${h.complianceAfter}.` });
      }
      if (s.directive && !s.history.some((h) => h.directive.id === s.directive.id)) fullReveal.push({ id: `${s.id}:unfinished`, round: g.round, memberId: s.id, title: `Subject ${s.number.toString().padStart(2, "0")} \u2014 unfinished directive`, detail: s.directive.instruction });
    }
  }
  const privateDirective = self?.directive ?? null;
  const isFinal = privateDirective?.kind === "group" || privateDirective?.kind === "self";
  const survival = room.survival ? projectSurvivalWorld(room.survival) : null;
  if (survival) survival.players = survival.players.filter((player) => room.members.some((m) => m.id === player.id && !m.removed && m.role === "subject"));
  const viewer = room.members.find((m) => m.id === viewerId);
  const survivorNumbers = room.survival ? Object.keys(room.survival.players) : [];
  return {
    id: room.id,
    code: room.code,
    hostId: room.hostId,
    settings: { ...room.settings },
    status: room.status,
    chatMuted: room.chatMuted,
    selfId: viewerId,
    members: room.members.map((m) => ({ id: m.id, nickname: m.nickname, role: m.role, ready: m.ready, removed: m.removed, controller: isCpuMember(m) ? "cpu" : "human", connected: !m.removed && (isCpuMember(m) || onlineIds.has(m.id)), subjectNumber: g?.subjects[m.id]?.number ?? (survivorNumbers.includes(m.id) ? survivorNumbers.indexOf(m.id) + 1 : null) })),
    chat: room.chat.map((m) => ({ id: m.id, senderId: m.senderId, nickname: m.nickname ?? room.members.find((p) => p.id === m.senderId)?.nickname ?? "Removed Subject", text: m.text, at: m.at, type: m.type ?? "chat" })),
    events: (g ? g.publicEvents : room.events.filter((e) => e.visibility === "public")).map((e) => ({ id: e.id, at: e.at, round: e.round, type: e.kind, title: titleOf(e.kind), detail: e.text })),
    game: g ? {
      id: g.id,
      round: g.round,
      initialRounds: g.initialRoundCount,
      totalRounds: g.plannedTotalRounds,
      roundCap: g.maxRounds,
      stability: g.stabilityTicks / g.startingSubjectCount,
      maxStability: 100,
      outcome: g.outcome ?? "active",
      phase: { id: g.phase.id, type: g.phase.type, deadline: g.phase.deadline, paused: g.paused, pauseReason: g.pauseReason, remainingMs: g.phase.remainingMs, eligibleIds: [...g.phase.eligibleIds], speakerId: g.phase.speakerId },
      trial: g.trial ? { id: g.trial.id, title: g.trial.title, narrative: g.trial.description, medicalTarget: g.trial.threshold, securityTarget: g.trial.threshold } : null,
      voteType: g.trial?.voteType ?? null,
      voteTargets: g.phase.type === "vote" ? [...g.phase.eligibleIds] : [],
      allocationTotals: g.trial?.totals ? { ...g.trial.totals } : null,
      extension: g.extension ? { additionalRounds: g.extension.addedRounds, proposedTotal: g.extension.toRounds } : null,
      results: showFull ? g.results.map((r) => resultView(room, r)) : [],
      fullReveal
    } : null,
    me: self ? {
      compliance: self.compliance,
      requirement: self.requirement,
      directive: !isFinal ? directiveView(privateDirective) : null,
      finalDirective: isFinal ? directiveView(privateDirective) : null,
      restriction: self.medicalMinimum > 0 || self.pendingRestriction,
      decision: self.allocation ? { ...self.allocation } : null,
      decisionSubmitted: self.allocation !== null,
      voteSubmitted: self.ballot !== void 0,
      finalChoice: self.finalChoice,
      extensionVote: g?.extension && Object.hasOwn(g.extension.ballots, viewerId) ? g.extension.ballots[viewerId] : null,
      dossier: self.dossier.map((e) => ({ id: e.id, round: e.round, title: titleOf(e.kind), text: e.text, complianceDelta: Number(e.data?.complianceDelta ?? 0), at: e.at })),
      result: ownResult ? resultView(room, ownResult) : null
    } : null,
    ...room.survival && survival ? { survival, survivorMe: viewer.role === "subject" ? projectSurvivalPlayer(room.survival, viewerId) : null } : {}
  };
}

// src/server/cpu.ts
import { randomUUID as randomUUID5 } from "node:crypto";
function hash3(text) {
  let value = 2166136261;
  for (const char of text) {
    value ^= char.charCodeAt(0);
    value = Math.imul(value, 16777619);
  }
  return value >>> 0;
}
function personality(view) {
  return hash3(view.selfId) % 3;
}
function pick(view, key, lines) {
  return lines[hash3(`${view.selfId}:${view.game.round}:${key}`) % lines.length];
}
function publicRequests(view) {
  const me = view.members.find((member2) => member2.id === view.selfId);
  const prefix = `@${me.nickname.toLocaleLowerCase()}`;
  const currentCrisis = view.events.findLast((event4) => event4.type === "crisis" && event4.round === view.game.round);
  const currentFinale = view.events.findLast((event4) => event4.type === "finale");
  const roundStart = currentCrisis?.at ?? currentFinale?.at ?? Infinity;
  return view.chat.flatMap((message) => {
    const sender = view.members.find((member2) => member2.id === message.senderId);
    if (message.type !== "chat" || message.at < roundStart || !sender || sender.removed || sender.controller !== "human" || sender.role !== "subject" || !view.game.phase.eligibleIds.includes(sender.id)) return [];
    const text = message.text.toLocaleLowerCase();
    if (!text.startsWith(prefix) || !/^[\s—,:-]/.test(text.slice(prefix.length))) return [];
    const request = text.slice(prefix.length);
    const intent = /medical/.test(request) ? "medical" : /security/.test(request) ? "security" : /protect.*group|surviv|protect.*everyone/.test(request) ? "group" : "explanation";
    return [{ message, intent }];
  });
}
function latestAppeal(view) {
  return publicRequests(view).findLast((request) => request.intent !== "explanation");
}
function directiveMatches(text, allocation) {
  switch (text) {
    case "Allocate at least 2 units to Medical.":
      return allocation.medical >= 2;
    case "Allocate at least 2 units to Security.":
      return allocation.security >= 2;
    case "Keep at least 2 units in Reserve.":
      return allocation.reserve >= 2;
    case "Allocate no units to Medical.":
      return allocation.medical === 0;
    case "Allocate no units to Security.":
      return allocation.security === 0;
    case "Keep all 3 units in Reserve.":
      return allocation.reserve === 3;
    case "Allocate exactly 1 unit to each system.":
      return allocation.medical === 1 && allocation.security === 1 && allocation.reserve === 1;
    // Other players' locked choices are unavailable. Treat the shared benchmark
    // as a reason to contribute to both systems, never as knowledge it was met.
    case "Submit an allocation and have both Medical and Security reach their thresholds.":
      return allocation.medical >= 1 && allocation.security >= 1;
    default:
      return false;
  }
}
function allocationFor(view) {
  const game2 = view.game, me = view.me;
  if (game2.stability <= 40) return { medical: 1, security: 1, reserve: 1 };
  const profile = hash3(view.selfId) % 3;
  const deficit = Math.max(0, me.requirement - me.compliance);
  const survivalWeight = game2.stability <= 35 ? 5 : game2.stability <= 55 ? 3 : game2.stability <= 75 ? 1.8 : 1;
  const directiveWeight = deficit === 0 ? 0.5 : 2.15 + profile * 0.25;
  const appeal = latestAppeal(view);
  let best = { medical: 1, security: 2, reserve: 0 }, bestScore = -Infinity;
  for (let medical = me.restriction ? 1 : 0; medical <= 3; medical++) {
    for (let security = 0; security <= 3 - medical; security++) {
      const allocation = { medical, security, reserve: 3 - medical - security };
      const bothSystems = medical > 0 && security > 0;
      const contribution = medical + security + (bothSystems ? 0.8 : 0);
      const reward = me.directive && directiveMatches(me.directive.text, allocation) ? me.directive.reward : 0;
      const preference = hash3(`${view.selfId}:${game2.phase.id}:${medical}:${security}`) % 100 / 500;
      const persuasion = appeal?.intent === "medical" || appeal?.intent === "security" ? Math.min(2, allocation[appeal.intent]) * (profile === 0 ? 1.8 : profile === 1 ? 1.5 : 1.1) : appeal?.intent === "group" && bothSystems ? 1.5 : 0;
      const score = contribution * survivalWeight + reward * directiveWeight + preference + persuasion;
      if (score > bestScore) {
        bestScore = score;
        best = allocation;
      }
    }
  }
  return best;
}
function ballotFor2(view) {
  const game2 = view.game;
  const candidates = game2.voteTargets.filter((id) => id !== view.selfId && view.members.some((m) => m.id === id && !m.removed && m.role === "subject"));
  let best = null, bestScore = -Infinity;
  for (const id of candidates) {
    const candidate = view.members.find((m) => m.id === id);
    const messages = view.chat.filter((m) => m.senderId === id).map((m) => m.text.toLowerCase());
    const supportive = messages.filter((text) => /protect the group|both systems|medical and security|survival comes first/.test(text)).length;
    const selfish = messages.filter((text) => /keep.*reserve|protect myself|protect yourself/.test(text)).length;
    const subjectLabel = `Subject ${String(candidate.subjectNumber).padStart(2, "0")}`;
    const exposed = view.events.filter((event4) => event4.type === "vote_resolution" && event4.detail.includes(`EXPOSURE selected ${subjectLabel}`));
    const riskyExposure = exposed.filter((event4) => /Exposed directive: (Keep|Allocate no)/.test(event4.detail)).length;
    const publicReputation = supportive - selfish - riskyExposure;
    const reputationScore = game2.voteType === "trust" ? publicReputation : -publicReputation;
    const score = reputationScore + hash3(`${view.selfId}:${game2.phase.id}:${id}`) % 1e3 / 1e3;
    if (score > bestScore) {
      bestScore = score;
      best = id;
    }
  }
  return best;
}
function finalChoiceFor(view) {
  const game2 = view.game, me = view.me;
  if (game2.stability <= 55 || me.compliance >= me.requirement) return "group";
  if (latestAppeal(view)?.intent === "group" && personality(view) !== 2) return "group";
  return me.finalDirective?.text === "Choose Protect Yourself." ? "self" : "group";
}
function publicOutcome(view) {
  return view.events.findLast((event4) => event4.type === "resource_resolution")?.detail ?? null;
}
function discussionLine(view) {
  const game2 = view.game, voice = personality(view), outcome = publicOutcome(view);
  if (game2.stability <= 40) return pick(view, "danger", [
    "One unit to Medical, one to Security. Survival comes first now; nobody qualifies if this room collapses.",
    `Stability is ${game2.stability}. We are running out of room for selfish moves. I intend to support both systems.`,
    "We are close to losing the whole experiment. Medical and Security need all of us this time."
  ]);
  if (outcome && /Stability -/.test(outcome)) return pick(view, "recovery", [
    "That last Trial cost us Stability. The public totals show the shortage; they do not tell us who held back.",
    `We took a hit last round. Stability is ${game2.stability}; ask me for Medical or Security before I decide.`,
    "I want a better plan than blame this round. Tell me which system you can cover, and I will consider the other."
  ]);
  const lines = [
    [
      `I want this room to survive. ${game2.trial?.title ?? "This Trial"} needs both systems; ask me where help is needed.`,
      "We have three units each, and two systems to save. I would rather coordinate than guess what you will do.",
      "Medical and Security both matter. I am listening if someone has a plan that keeps the group alive."
    ],
    [
      `Each system needs ${game2.trial?.medicalTarget ?? game2.phase.eligibleIds.length} units. A pile of Reserve will not stop the crisis.`,
      "The totals will expose whether our plan worked, not every private choice. Tell me what you want me to cover.",
      `Stability is ${game2.stability}. We have options, but my directive makes this less simple than it looks.`
    ],
    [
      "I want to qualify, and I need this room alive to do it. Give me a reason to help your plan.",
      "My directive and your survival plan may not agree. Ask me before assuming I am on your side.",
      "I can negotiate. I cannot promise my private instructions will make cooperation painless."
    ]
  ];
  return pick(view, "discussion", lines[voice]);
}
function revealLine(view) {
  const game2 = view.game, totals = game2.allocationTotals, trial = game2.trial;
  if (!totals || !trial) return "The public result is in. We can judge the shared outcome, not guess every private choice.";
  const medicalMet = totals.medical >= trial.medicalTarget, securityMet = totals.security >= trial.securityTarget;
  if (medicalMet && securityMet) return pick(view, "both-saved", [
    `Both systems held. Medical ${totals.medical}, Security ${totals.security}. Now the question is who you trust.`,
    "We made it through that crisis. A successful group result does not mean everyone followed their directive.",
    `The room survived. Stability is ${game2.stability}; do not let the next vote tear apart a working plan.`
  ]);
  const failed = !medicalMet && !securityMet ? "Medical and Security" : medicalMet ? "Security" : "Medical";
  return pick(view, "shortage", [
    `${failed} fell short. I saw the same totals you did; they do not prove which Subject caused it.`,
    `That hurt. Stability is ${game2.stability}. We need answers, but an accusation is not evidence.`,
    `${totals.reserve} units went to Reserve. ${failed} needed more help than the group delivered.`
  ]);
}
function finalStatement(view) {
  const game2 = view.game, voice = personality(view), outcome = publicOutcome(view);
  const opening = voice === 0 ? "I want all of us to leave this room." : voice === 1 ? `We reach the finale with ${game2.stability} Stability.` : "I came here to qualify, not to be a hero.";
  const evidence = outcome ? ` Our last public resource result was: ${outcome}` : "";
  const ending = game2.stability <= 55 ? " Protect the group. Another betrayal could finish us." : voice === 2 ? " I will weigh my last directive, but collapse rewards nobody. Ask me if you want my support." : " I intend to protect the group. Private instructions may pull us apart; the final decision is still ours.";
  return `${opening}${evidence}${ending}`;
}
function replyLine(view, request) {
  const human = request.message.nickname, me = view.me, game2 = view.game;
  const address = `@${human} \u2014 `;
  if (request.intent === "medical" || request.intent === "security") {
    if (!game2.trial) return `${address}Resource allocation is over. The final choice is about protecting the group or yourself.`;
    if (me.decisionSubmitted) return `${address}I have already locked my allocation. I can hear your argument, but I cannot change that choice.`;
    const allocation = allocationFor(view), units = allocation[request.intent], system = request.intent === "medical" ? "Medical" : "Security";
    if (game2.stability <= 40) return `${address}I intend one unit for Medical and one for Security. At ${game2.stability} Stability, we need both to hold.`;
    if (units >= 2) return `${address}I can aim ${units} units at ${system}. Keep the other system covered; this is my current plan, not a binding deal.`;
    if (units === 1) return `${address}I can aim one unit at ${system}, but my own directive pulls me elsewhere. Do not build your whole plan around me.`;
    return `${address}I cannot honestly promise ${system} support. My directive conflicts with that request; you may want to ask another Subject.`;
  }
  if (request.intent === "group") {
    if (me.finalChoice !== null) return `${address}My final choice is locked. The reveal will show whether you were right to trust me.`;
    if (game2.phase.type === "final_choice") return finalChoiceFor(view) === "group" ? `${address}You have persuaded me to protect the group. That is my intention; the final reveal will test it.` : `${address}I want to survive, but I cannot promise I will sacrifice my own qualification. My final directive is pulling the other way.`;
    if (!game2.trial) return `${address}I am leaning toward protecting the group. We have not received the final directives yet, so I will not make an easy promise.`;
    const allocation = me.decision ?? allocationFor(view);
    return allocation.medical > 0 && allocation.security > 0 ? `${address}I intend to support both Medical and Security. Survival comes first, but you will have to judge me by what is revealed.` : `${address}I want the group alive, but my directive does not make this easy. I cannot promise support for both systems.`;
  }
  if (/why|what happened|result|last trial/.test(request.message.text.toLocaleLowerCase())) {
    const outcome = publicOutcome(view);
    return `${address}${outcome ? `The latest public resource record says: ${outcome}` : `Stability is ${game2.stability}. We have no resolved resource totals yet.`} It does not identify every private action.`;
  }
  return `${address}${pick(view, `answer:${request.message.id}`, [
    "Ask me to help Medical, Security, or protect the group. I will answer before I lock a choice, if I can.",
    "I am listening. Tell me which public problem you want us to solve; I cannot see anyone else\u2019s private orders.",
    "You can question me, but judge accusations against the public record. My promises are not official contracts."
  ])}`;
}
function actionFor(view) {
  const game2 = view.game, me = view.me;
  switch (game2.phase.type) {
    case "decision":
      return me.decisionSubmitted ? null : { type: "decision", allocation: allocationFor(view) };
    case "vote":
      return me.voteSubmitted ? null : { type: "vote", targetId: ballotFor2(view) };
    case "extension_vote": {
      if (me.extensionVote !== null || !game2.extension) return null;
      const manageableLength = game2.extension.proposedTotal <= Math.min(game2.roundCap, Math.max(7, game2.initialRounds + 5));
      return { type: "extension_vote", yes: game2.stability > 25 && manageableLength && (me.compliance < me.requirement || game2.extension.proposedTotal <= 5) };
    }
    case "final_choice":
      return me.finalChoice === null ? { type: "final_choice", choice: finalChoiceFor(view) } : null;
    case "final_interrogation": {
      if (game2.phase.speakerId !== view.selfId) return null;
      return { type: "statement", text: finalStatement(view) };
    }
    default:
      return null;
  }
}
function runCpuPlayers(room, now) {
  const game2 = room.game;
  if (room.status !== "running" || !game2 || game2.paused || game2.outcome !== null) return false;
  const phaseId = game2.phase.id;
  const phaseType = game2.phase.type;
  if (!["discussion", "decision", "reveal", "vote", "extension_vote", "final_interrogation", "final_choice"].includes(phaseType)) return false;
  if (phaseType !== "final_choice" && game2.phase.deadline !== null && now >= game2.phase.deadline) return false;
  let changed = false;
  for (const candidate of room.members) {
    if (room.game?.phase.id !== phaseId || room.game.paused || room.game.outcome !== null) break;
    if (candidate.controller !== "cpu" || candidate.removed || candidate.role !== "subject" || !game2.phase.eligibleIds.includes(candidate.id) || game2.subjects[candidate.id]?.withdrawn) continue;
    const view = projectRoom(room, candidate.id);
    if (!view.me) continue;
    if (!room.chatMuted && ["discussion", "decision", "final_interrogation", "final_choice"].includes(phaseType)) {
      const previous = candidate.cpuReplyState;
      const count = previous?.phaseId === phaseId ? previous.count : 0;
      const latestRequest = publicRequests(view).at(-1);
      const request = count < 2 && latestRequest && !previous?.repliedIds.includes(latestRequest.message.id) ? latestRequest : void 0;
      if (request && now >= request.message.at + 1e3 + hash3(`${candidate.id}:${request.message.id}`) % 2001) {
        applyCommand(room, candidate.id, { commandId: randomUUID5(), gameId: game2.id, phaseId, action: { type: "chat", text: replyLine(view, request) } }, now);
        candidate.cpuReplyState = { phaseId, count: count + 1, repliedIds: [...previous?.repliedIds ?? [], request.message.id].slice(-16) };
        if (phaseType === "discussion") candidate.cpuLastDiscussionPhase = phaseId;
        changed = true;
        continue;
      }
    }
    const due = game2.phase.openedAt + 2e3 + hash3(`${candidate.id}:${phaseId}`) % 3001;
    if (now < due) continue;
    let action;
    if (phaseType === "discussion" || phaseType === "reveal") {
      if (room.chatMuted || candidate.cpuLastDiscussionPhase === phaseId) continue;
      action = { type: "chat", text: phaseType === "reveal" ? revealLine(view) : discussionLine(view) };
    } else action = actionFor(view);
    if (!action) continue;
    applyCommand(room, candidate.id, { commandId: randomUUID5(), gameId: game2.id, phaseId, action }, now);
    if (phaseType === "discussion" || phaseType === "reveal") candidate.cpuLastDiscussionPhase = phaseId;
    changed = true;
  }
  return changed;
}

// src/server/store.ts
import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
var Store = class {
  database;
  commitsSinceCleanup = /* @__PURE__ */ new Map();
  constructor(path) {
    if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
    this.database = new DatabaseSync(path);
    this.database.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = FULL;
      PRAGMA foreign_keys = ON;
      PRAGMA busy_timeout = 5000;
      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        token_digest TEXT NOT NULL UNIQUE,
        expires_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS rooms (
        code TEXT PRIMARY KEY,
        snapshot TEXT NOT NULL,
        updated_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS room_events (
        sequence INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT NOT NULL REFERENCES rooms(code),
        at INTEGER NOT NULL,
        event TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS command_receipts (
        actor_id TEXT NOT NULL,
        command_id TEXT NOT NULL,
        payload_hash TEXT NOT NULL,
        ack TEXT NOT NULL,
        room_code TEXT NOT NULL REFERENCES rooms(code),
        at INTEGER NOT NULL,
        volatile INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (actor_id, command_id)
      );
      CREATE TABLE IF NOT EXISTS host_presence (
        room_code TEXT PRIMARY KEY REFERENCES rooms(code),
        host_id TEXT NOT NULL,
        disconnected_at INTEGER
      );
    `);
    if (!this.database.prepare("PRAGMA table_info(command_receipts)").all().some((column) => column.name === "volatile")) {
      this.database.exec("ALTER TABLE command_receipts ADD COLUMN volatile INTEGER NOT NULL DEFAULT 0");
    }
    this.database.exec("CREATE INDEX IF NOT EXISTS room_events_room_sequence ON room_events(room_code, sequence); CREATE INDEX IF NOT EXISTS command_receipts_actor_volatile_at ON command_receipts(actor_id, volatile, at);");
  }
  loadRooms() {
    return this.database.prepare("SELECT snapshot FROM rooms").all().map((row) => JSON.parse(String(row.snapshot)));
  }
  sessionId(tokenDigest, now) {
    const row = this.database.prepare("SELECT id FROM sessions WHERE token_digest = ? AND expires_at > ?").get(tokenDigest, now);
    return row ? String(row.id) : null;
  }
  createSession(id, tokenDigest, expiresAt) {
    this.database.prepare("INSERT INTO sessions(id, token_digest, expires_at) VALUES (?, ?, ?)").run(id, tokenDigest, expiresAt);
  }
  receipt(actorId, commandId) {
    const row = this.database.prepare("SELECT payload_hash, ack FROM command_receipts WHERE actor_id = ? AND command_id = ?").get(actorId, commandId);
    return row ? { actorId, commandId, payloadHash: String(row.payload_hash), ack: JSON.parse(String(row.ack)) } : null;
  }
  /** Snapshot, audit event, and receipt commit together before acknowledgement. */
  commit(room, at, event4, receipt) {
    this.database.exec("BEGIN IMMEDIATE");
    try {
      this.database.prepare("INSERT INTO rooms(code, snapshot, updated_at) VALUES (?, ?, ?) ON CONFLICT(code) DO UPDATE SET snapshot = excluded.snapshot, updated_at = excluded.updated_at").run(room.code, JSON.stringify(room), at);
      this.database.prepare("INSERT INTO room_events(room_code, at, event) VALUES (?, ?, ?)").run(room.code, at, JSON.stringify(event4));
      if (receipt) {
        this.database.prepare("INSERT INTO command_receipts(actor_id, command_id, payload_hash, ack, room_code, at, volatile) VALUES (?, ?, ?, ?, ?, ?, ?)").run(receipt.actorId, receipt.commandId, receipt.payloadHash, JSON.stringify(receipt.ack), room.code, at, receipt.volatile ? 1 : 0);
        if (receipt.volatile) {
          this.database.prepare("DELETE FROM command_receipts WHERE rowid IN (SELECT rowid FROM command_receipts WHERE actor_id = ? AND volatile = 1 ORDER BY at DESC, rowid DESC LIMIT -1 OFFSET 300)").run(receipt.actorId);
        }
      }
      if (room.survival) {
        const cleanup = (this.commitsSinceCleanup.get(room.code) ?? 199) + 1;
        this.commitsSinceCleanup.set(room.code, cleanup % 200);
        if (cleanup >= 200) {
          this.database.prepare("DELETE FROM room_events WHERE sequence IN (SELECT sequence FROM room_events WHERE room_code = ? ORDER BY sequence DESC LIMIT -1 OFFSET 2000)").run(room.code);
        }
      }
      this.database.exec("COMMIT");
    } catch (error) {
      this.database.exec("ROLLBACK");
      throw error;
    }
  }
  hostPresence(code) {
    const row = this.database.prepare("SELECT host_id, disconnected_at FROM host_presence WHERE room_code = ?").get(code);
    return row ? { hostId: String(row.host_id), disconnectedAt: row.disconnected_at === null ? null : Number(row.disconnected_at) } : null;
  }
  setHostPresence(code, hostId, disconnectedAt) {
    this.database.prepare("INSERT INTO host_presence(room_code, host_id, disconnected_at) VALUES (?, ?, ?) ON CONFLICT(room_code) DO UPDATE SET host_id = excluded.host_id, disconnected_at = excluded.disconnected_at").run(code, hostId, disconnectedAt);
  }
  close() {
    this.database.close();
  }
};

// src/server/app.ts
var SESSION_COOKIE = "experiment_session";
var SESSION_AGE_MS = 30 * 24 * 60 * 60 * 1e3;
var HOST_GRACE_MS = 6e4;
var nicknameSchema = z3.string().trim().min(1).max(24).refine((value) => !/[\p{Cc}\p{Cf}]/u.test(value));
var createSchema = z3.object({ nickname: nicknameSchema, settings: settingsSchema.optional() }).strict();
var joinSchema = z3.object({ nickname: nicknameSchema }).strict();
var HttpError = class extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
function digest(value) {
  return createHash("sha256").update(value).digest("hex");
}
function stableJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(",")}}`;
}
async function createApp(options = {}) {
  const now = options.now ?? Date.now;
  const app2 = Fastify({ logger: { level: "error" }, logController: new LogController({ disableRequestLogging: true }), bodyLimit: 16384, trustProxy: process.env.TRUST_PROXY === "true" });
  const store = new Store(options.databasePath ?? process.env.DATABASE_PATH ?? resolve("data/experiment.sqlite"));
  const degradedRooms = /* @__PURE__ */ new Set();
  const commit = (room, at, event4, receipt) => {
    try {
      store.commit(room, at, event4, receipt);
      degradedRooms.delete(room.code);
    } catch (error) {
      if (!degradedRooms.has(room.code)) app2.log.error({ event: "persistence_failure", room: room.code }, "Room state could not be committed.");
      degradedRooms.add(room.code);
      throw error;
    }
  };
  const rooms = new Map(store.loadRooms().map((room) => [room.code, room]));
  for (const room of rooms.values()) if (room.survival) {
    room.survival.lastTickAt = now();
    for (const player of Object.values(room.survival.players)) player.input = { moveX: 0, moveY: 0, aim: player.aim, fire: false, receivedAt: now() };
  }
  const connections = /* @__PURE__ */ new Map();
  const queues = /* @__PURE__ */ new Map();
  const rateWindows = /* @__PURE__ */ new Map();
  const websocketContext = /* @__PURE__ */ new WeakMap();
  let shuttingDown = false;
  const publicOrigin = options.publicOrigin ?? process.env.PUBLIC_ORIGIN;
  if (publicOrigin && new URL(publicOrigin).origin !== publicOrigin) throw new Error("PUBLIC_ORIGIN must be an origin without a path");
  const rateLimit = (key, limit, duration) => {
    const time = now();
    const current = rateWindows.get(key);
    if (!current || time - current.start >= duration) {
      rateWindows.set(key, { start: time, count: 1 });
      return true;
    }
    current.count += 1;
    return current.count <= limit;
  };
  const enqueue = (code, work) => {
    const previous = queues.get(code) ?? Promise.resolve();
    const result = previous.then(work);
    queues.set(code, result.then(() => void 0, () => void 0));
    return result;
  };
  const online = (code) => new Set(connections.get(code)?.keys() ?? []);
  const send = (connection, message) => {
    if (connection.socket.readyState === 1) connection.socket.send(JSON.stringify(message));
  };
  const updateHostPresence = (room) => {
    const existing = store.hostPresence(room.code);
    const hostOnline = online(room.code).has(room.hostId);
    const disconnectedAt = hostOnline ? null : existing && existing.hostId === room.hostId && existing.disconnectedAt !== null ? existing.disconnectedAt : now();
    if (!existing || existing.hostId !== room.hostId || existing.disconnectedAt !== disconnectedAt) store.setHostPresence(room.code, room.hostId, disconnectedAt);
  };
  const broadcast = (code) => {
    const room = rooms.get(code);
    if (!room) return;
    const onlineIds = online(code);
    for (const connection of connections.get(code)?.values() ?? []) {
      const member2 = room.members.find((candidate) => candidate.id === connection.actorId);
      if (!member2 || member2.removed) {
        send(connection, { type: "error", message: "You have been removed from this room." });
        connection.socket.close(4003, "Membership removed");
        continue;
      }
      const view = projectRoom(room, connection.actorId, onlineIds);
      const serialized = JSON.stringify(view);
      if (connection.lastView === serialized) continue;
      connection.lastView = serialized;
      connection.viewVersion += 1;
      send(connection, { type: "snapshot", view, serverTime: now(), viewVersion: connection.viewVersion });
    }
    updateHostPresence(room);
  };
  const sessionId = (request) => {
    const token = request.cookies[SESSION_COOKIE];
    if (!token || !/^[A-Za-z0-9_-]{43}$/.test(token)) return null;
    return store.sessionId(digest(token), now());
  };
  const ensureSession = (request, reply) => {
    const existing = sessionId(request);
    if (existing) return existing;
    const token = randomBytes(32).toString("base64url");
    const id = randomUUID6();
    store.createSession(id, digest(token), now() + SESSION_AGE_MS);
    reply.setCookie(SESSION_COOKIE, token, { path: "/", httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production" || publicOrigin?.startsWith("https://") === true, maxAge: SESSION_AGE_MS / 1e3 });
    return id;
  };
  const assertOrigin = (request, required) => {
    const origin = request.headers.origin;
    if (!origin && !required) return;
    const expected = publicOrigin ?? `${request.protocol}://${request.headers.host}`;
    if (typeof origin !== "string" || origin !== expected) throw new HttpError(403, "ORIGIN", "Use the same website origin to access this room.");
  };
  const roomCode = (request) => {
    const code = request.params.code.toUpperCase();
    if (!/^[A-Z2-9]{6}$/.test(code)) throw new HttpError(404, "ROOM_NOT_FOUND", "Room not found. Check the six-character code.");
    return code;
  };
  const getRoom = (code) => {
    const room = rooms.get(code);
    if (!room) throw new HttpError(404, "ROOM_NOT_FOUND", "Room not found. Check the six-character code.");
    return room;
  };
  await app2.register(cookie);
  await app2.register(websocket, { options: { maxPayload: 16384 } });
  app2.addHook("onSend", async (request, reply) => {
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("X-Frame-Options", "DENY");
    reply.header("Referrer-Policy", "same-origin");
    reply.header("Content-Security-Policy", "frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
    if (request.url.startsWith("/api/")) reply.header("Cache-Control", "no-store");
  });
  app2.setErrorHandler((error, _request, reply) => {
    if (error instanceof HttpError) return reply.code(error.status).send({ error: { code: error.code, message: error.message } });
    if (error instanceof EngineError) return reply.code(409).send({ error: { code: error.code, message: error.message } });
    if (error instanceof z3.ZodError) return reply.code(400).send({ error: { code: "INVALID_REQUEST", message: "Check the nickname and room settings." } });
    if (typeof error === "object" && error !== null && "statusCode" in error && typeof error.statusCode === "number" && error.statusCode < 500) return reply.code(error.statusCode).send({ error: { code: "INVALID_REQUEST", message: "The request could not be accepted." } });
    return reply.code(500).send({ error: { code: "SERVER_ERROR", message: "The server could not save this action. Please try again." } });
  });
  app2.get("/api/health", async (_request, reply) => reply.code(degradedRooms.size ? 503 : 200).send({ ok: degradedRooms.size === 0 }));
  app2.get("/api/session", async (request) => {
    const id = sessionId(request);
    return { rooms: id ? [...rooms.values()].flatMap((room) => {
      const member2 = room.members.find((candidate) => candidate.sessionId === id && !candidate.removed);
      return member2 ? [{ code: room.code, nickname: member2.nickname, role: member2.role }] : [];
    }) : [] };
  });
  app2.post("/api/rooms", async (request, reply) => {
    assertOrigin(request, false);
    if (!rateLimit(`create:${request.ip}`, 12, 6e4)) throw new HttpError(429, "RATE_LIMIT", "Too many rooms created. Please wait a minute.");
    const body = createSchema.parse(request.body);
    const id = ensureSession(request, reply);
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code;
    do {
      code = Array.from({ length: 6 }, () => alphabet[randomInt2(alphabet.length)]).join("");
    } while (rooms.has(code));
    const memberId = randomUUID6();
    const room = createRoom(code, { id: memberId, sessionId: id, nickname: body.nickname }, body.settings ?? DEFAULT_SETTINGS, now());
    commit(room, now(), { type: "room_created", actorId: memberId });
    rooms.set(code, room);
    updateHostPresence(room);
    return reply.code(201).send({ code, memberId });
  });
  app2.post("/api/rooms/:code/join", async (request, reply) => {
    assertOrigin(request, false);
    if (!rateLimit(`join:${request.ip}`, 40, 6e4)) throw new HttpError(429, "RATE_LIMIT", "Too many join attempts. Please wait a minute.");
    const code = roomCode(request);
    const body = joinSchema.parse(request.body);
    getRoom(code);
    const id = ensureSession(request, reply);
    return enqueue(code, () => {
      processTimers(code);
      const current = getRoom(code);
      const existing = current.members.find((member2) => member2.sessionId === id);
      if (existing?.removed) throw new HttpError(403, "REMOVED", "Your Subject has been removed from this room.");
      if (existing) return { code, memberId: existing.id };
      const room = structuredClone(current);
      const memberId = addMember(room, { id: randomUUID6(), sessionId: id, nickname: body.nickname }, now());
      commit(room, now(), { type: "member_joined", actorId: memberId });
      rooms.set(code, room);
      broadcast(code);
      return { code, memberId };
    });
  });
  const rejectAck = (commandId, code, message) => ({ type: "ack", commandId, ok: false, error: { code, message } });
  const execute = (connection, command) => {
    if (connections.get(connection.code)?.get(connection.actorId) !== connection) {
      send(connection, { type: "superseded" });
      return;
    }
    processTimers(connection.code);
    const room = getRoom(connection.code);
    const member2 = room.members.find((candidate2) => candidate2.id === connection.actorId);
    if (!member2 || member2.removed) {
      send(connection, rejectAck(command.commandId, "REMOVED", "You no longer have access to this room."));
      return;
    }
    const payloadHash = digest(stableJson(command));
    const previous = store.receipt(connection.actorId, command.commandId);
    if (previous) {
      send(connection, previous.payloadHash === payloadHash ? previous.ack : rejectAck(command.commandId, "COMMAND_REUSED", "This command ID was already used for a different action."));
      return;
    }
    const candidate = structuredClone(room);
    let ack = { type: "ack", commandId: command.commandId, ok: true };
    try {
      applyCommand(candidate, connection.actorId, command, now());
    } catch (error) {
      if (!(error instanceof EngineError)) throw error;
      ack = rejectAck(command.commandId, error.code, error.message);
    }
    const receipt = { actorId: connection.actorId, commandId: command.commandId, payloadHash, ack, volatile: command.action.type === "survival_input" };
    commit(ack.ok ? candidate : room, now(), { type: ack.ok ? "command_accepted" : "command_rejected", actorId: connection.actorId, command, errorCode: ack.error?.code ?? null }, receipt);
    if (ack.ok) rooms.set(connection.code, candidate);
    send(connection, ack);
    if (ack.ok) broadcast(connection.code);
  };
  app2.get("/api/rooms/:code/socket", {
    websocket: true,
    preValidation: async (request) => {
      assertOrigin(request, true);
      if (!rateLimit(`connect:${request.ip}`, 80, 6e4)) throw new HttpError(429, "RATE_LIMIT", "Too many connection attempts. Please wait a minute.");
      const code = roomCode(request);
      const id = sessionId(request);
      if (!id) throw new HttpError(401, "SESSION_REQUIRED", "Join the room before connecting.");
      const member2 = getRoom(code).members.find((candidate) => candidate.sessionId === id && !candidate.removed);
      if (!member2) throw new HttpError(403, "MEMBERSHIP_REQUIRED", "Join the room before connecting.");
      websocketContext.set(request, { code, actorId: member2.id });
    }
  }, (socket, request) => {
    const context = websocketContext.get(request);
    const connection = { socket, ...context, alive: true, lastView: null, viewVersion: 0 };
    const controls = connections.get(context.code) ?? /* @__PURE__ */ new Map();
    const old = controls.get(context.actorId);
    controls.set(context.actorId, connection);
    connections.set(context.code, controls);
    if (old) {
      send(old, { type: "superseded" });
      old.socket.close(4001, "Another tab controls this Subject");
    }
    socket.on("pong", () => {
      connection.alive = true;
    });
    socket.on("error", () => {
    });
    socket.on("message", (data, binary) => {
      if (shuttingDown) return;
      if (!rateLimit(`raw:${connection.actorId}`, 200, 1e3)) {
        send(connection, { type: "error", message: "Too many messages. Wait a moment before trying again." });
        return;
      }
      let parsed;
      try {
        if (binary) throw new Error("Binary commands are not supported");
        parsed = JSON.parse(data.toString());
      } catch {
        send(connection, { type: "error", message: "Send a valid JSON game command." });
        return;
      }
      const result = commandSchema.safeParse(parsed);
      if (!result.success) {
        const id = typeof parsed === "object" && parsed !== null && "commandId" in parsed && typeof parsed.commandId === "string" && z3.string().uuid().safeParse(parsed.commandId).success ? parsed.commandId : null;
        send(connection, id ? rejectAck(id, "INVALID_COMMAND", "This action has an invalid format.") : { type: "error", message: "This action has an invalid format." });
        return;
      }
      const input = result.data.action.type === "survival_input";
      if (!rateLimit(`${input ? "input" : "command"}:${connection.actorId}`, input ? 25 : 100, input ? 1e3 : 1e4)) {
        send(connection, rejectAck(result.data.commandId, "RATE_LIMIT", "Too many actions. Wait a moment before trying again."));
        return;
      }
      void enqueue(context.code, () => execute(connection, result.data)).catch(() => {
        send(connection, rejectAck(result.data.commandId, "SERVER_ERROR", "This action could not be saved. Reconnect and retry."));
      });
    });
    socket.on("close", () => {
      if (controls.get(connection.actorId) !== connection) return;
      controls.delete(connection.actorId);
      if (!shuttingDown) void enqueue(context.code, () => {
        const current = getRoom(context.code);
        if (current.survival?.players[connection.actorId]) {
          const room = structuredClone(current);
          const player = room.survival.players[connection.actorId];
          player.input = { moveX: 0, moveY: 0, aim: player.aim, fire: false, receivedAt: now() };
          if (!online(context.code).size) room.survival.lastTickAt = now();
          commit(room, now(), { type: "survival_controller_disconnected", actorId: connection.actorId });
          rooms.set(context.code, room);
        }
        broadcast(context.code);
      }).catch(() => void 0);
    });
    void enqueue(context.code, () => broadcast(context.code)).catch(() => {
      socket.close(1011, "Room unavailable");
    });
  });
  const processTimers = (code) => {
    const current = getRoom(code);
    let room = structuredClone(current);
    let changed = false;
    if (room.survival && room.status === "running") {
      const onlineIds = online(code);
      const eligible = room.members.filter((member2) => !member2.removed && member2.role === "subject");
      const humanIds = new Set(eligible.filter((member2) => !isCpuMember(member2) && onlineIds.has(member2.id)).map((member2) => member2.id));
      const cpuIds = new Set(eligible.filter(isCpuMember).map((member2) => member2.id));
      changed = tickSurvivalWorld(room.survival, now(), humanIds, cpuIds, new Set(room.members.filter((member2) => member2.role === "subject" && !member2.removed).map((member2) => member2.id)));
      if (!room.survival.active) {
        room.status = "postgame";
        changed = true;
      }
      if (!changed && current.survival) current.survival.lastTickAt = room.survival.lastTickAt;
    } else {
      changed = tick(room, now());
      changed = runCpuPlayers(room, now()) || changed;
    }
    const presence = store.hostPresence(code);
    if (presence && presence.hostId === room.hostId && presence.disconnectedAt !== null && now() - presence.disconnectedAt >= HOST_GRACE_MS && !online(code).has(room.hostId)) {
      const successor = room.members.filter((member2) => !isCpuMember(member2) && member2.role === "subject" && !member2.removed && online(code).has(member2.id)).sort((a, b) => a.joinedAt - b.joinedAt)[0];
      if (successor) {
        const command = { commandId: randomUUID6(), gameId: room.survival?.id ?? room.game?.id ?? null, phaseId: room.game?.phase.id ?? null, action: { type: "transfer_host", targetId: successor.id } };
        try {
          applyCommand(room, room.hostId, command, now());
          changed = true;
        } catch (error) {
          if (!(error instanceof EngineError)) throw error;
        }
      }
    }
    if (changed) {
      commit(room, now(), { type: "server_transition", previousHostId: current.hostId, hostId: room.hostId });
      rooms.set(code, room);
      broadcast(code);
    }
    updateHostPresence(rooms.get(code));
  };
  for (const room of rooms.values()) {
    updateHostPresence(room);
    processTimers(room.code);
  }
  const lastLegacySweep = /* @__PURE__ */ new Map();
  const timer = setInterval(() => {
    if (shuttingDown) return;
    for (const [code, room] of rooms) {
      if (options.timerIntervalMs === void 0 && !room.survival && now() - (lastLegacySweep.get(code) ?? 0) < 500) continue;
      if (!room.survival) lastLegacySweep.set(code, now());
      void enqueue(code, () => processTimers(code)).catch(() => {
        if (!degradedRooms.has(code)) app2.log.error({ event: "timer_transition_failure", room: code }, "Room deadline could not be advanced.");
        degradedRooms.add(code);
      });
    }
    const time = now();
    for (const [key, value] of rateWindows) if (time - value.start > 6e4) rateWindows.delete(key);
  }, options.timerIntervalMs ?? 100);
  timer.unref();
  const heartbeat = setInterval(() => {
    for (const controls of connections.values()) for (const connection of controls.values()) {
      if (!connection.alive) {
        connection.socket.terminate();
        continue;
      }
      connection.alive = false;
      if (connection.socket.readyState === 1) connection.socket.ping();
    }
  }, 15e3);
  heartbeat.unref();
  const staticRoot = options.staticRoot ?? resolve("dist");
  if (existsSync(resolve(staticRoot, "index.html"))) {
    await app2.register(staticFiles, { root: staticRoot });
    app2.setNotFoundHandler((request, reply) => {
      if (request.url.startsWith("/api/")) return reply.code(404).send({ error: { code: "NOT_FOUND", message: "API endpoint not found." } });
      if (request.method !== "GET") return reply.code(404).send();
      return reply.sendFile("index.html");
    });
  }
  app2.addHook("preClose", async () => {
    shuttingDown = true;
    clearInterval(timer);
    clearInterval(heartbeat);
    for (const controls of connections.values()) for (const connection of controls.values()) connection.socket.close(1001, "Server restarting");
    await Promise.all(queues.values());
  });
  app2.addHook("onClose", async () => {
    store.close();
  });
  await app2.ready();
  return app2;
}

// src/server/index.ts
var port = Number(process.env.PORT ?? 3e3);
var host2 = process.env.HOST ?? "0.0.0.0";
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("PORT must be an integer between 1 and 65535");
var app = await createApp();
await app.listen({ port, host: host2 });
console.info(`THE EXPERIMENT server listening on ${host2}:${port}`);
var shutdown = async () => {
  await app.close();
  process.exit(0);
};
process.once("SIGINT", () => {
  void shutdown();
});
process.once("SIGTERM", () => {
  void shutdown();
});
